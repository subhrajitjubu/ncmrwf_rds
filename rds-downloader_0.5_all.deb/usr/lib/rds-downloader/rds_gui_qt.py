#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rds_gui_qt.py — NCMRWF RDS Downloader (Windows / Qt build)

PySide6 port of rds_gui3.py. Same feature set as rds_gui_tk.py, with:
  * a month-grid calendar for date ranges plus season presets
  * a compact two-column layout that fits a 14" laptop (1366x768) screen
  * the original GTK stylesheets re-used verbatim as Qt Style Sheets

The download engine runs IN-PROCESS via rds_engine (pure Python) — no bash,
curl or jq required.
"""

from __future__ import annotations

import os
import subprocess
import sys
from datetime import date
from pathlib import Path

from PySide6.QtCore import QThread, QTimer, Qt, Signal
from PySide6.QtGui import QTextCursor
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog,
    QDialogButtonBox, QFileDialog, QFrame, QGridLayout, QGroupBox, QHBoxLayout,
    QInputDialog, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton,
    QScrollArea, QSizePolicy, QTabWidget, QTextEdit, QVBoxLayout, QWidget,
)

sys.path.insert(0, str(Path(__file__).resolve().parent))

from rds_engine import (  # noqa: E402
    DATASETS,
    FORECAST_DAYS,
    INIT_DAYS,
    PRESSURE_LEVELS_BY_DATASET,
    SEASON_PRESETS,
    TIME_ALL,
    VARIABLES_BY_DATASET,
    JobLog,
    PresetManager,
    RDSClient,
    build_payload,
    build_request_text,
    config_dir,
    dates_to_months_days,
    job_display,
    months_to_dates_anchor,
    parse_years,
    validate_target_template,
    read_credentials,
    write_credentials,
)

from rds_themes import (  # noqa: E402
    DEFAULT_FONT_STEP,
    DEFAULT_THEME,
    FONT_STEPS,
    MONO_FAMILY,
    THEMES,
    THEME_ORDER,
    palette,
    scaled,
)

APP_TITLE = "NCMRWF Data Downloader v0.5"
APP_SUBTITLE = "IMDAA / NGFS Reanalysis  |  rds.ncmrwf.gov.in"

MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"]
MONTHS = [(f"{m:02d}", name) for m, name in enumerate(MONTH_NAMES, start=1)]
DAYS = [f"{d:02d}" for d in range(1, 32)]

REGION_PRESETS = {
    "India": (45, -15, 120, 30),
    "Asia": (60, -10, 150, 20),
    "Global": (90, -90, 180, -180),
}

DS_KEYS = list(DATASETS)


# ═════════════════════════════════════════════════════════════
#  STYLESHEET GENERATOR  (was hardcoded QSS_LIGHT / QSS_DARK)
# ═════════════════════════════════════════════════════════════
#  STYLESHEET GENERATOR
#
#  Both GUI builds now read their palettes from rds_themes so the same 15
#  themes drive either toolkit. The old QSS_LIGHT/QSS_DARK pair hardcoded
#  colours and font sizes, which meant adding a theme meant writing a whole
#  second stylesheet. See UI-WORKLOG.md D-21.
# ═════════════════════════════════════════════════════════════
def _px(base: float, scale: float) -> int:
    return max(6, int(round(base * scale)))


def build_qss(pal, scale: float = 1.0) -> str:
    """Build the full Qt stylesheet for one palette at one font scale.

    Accepts a theme name or a palette dict; either way it is normalised by
    palette() first, so a hand-built theme missing `accent_text` cannot
    raise KeyError here.
    """
    pal = palette(pal)
    body   = _px(11, scale)
    hint   = _px(10, scale)
    sub    = _px(9,  scale)
    title  = _px(15, scale)
    action = _px(12, scale)
    calday = _px(10, scale)
    log    = _px(11, scale)
    prew   = _px(10, scale)

    bg, card, fg = pal["bg"], pal["card"], pal["fg"]
    line, muted, acc = pal["line"], pal["muted"], pal["accent_text"]
    afg = pal["accent_fg"]

    return f"""
QWidget {{ background-color: {bg}; color: {fg}; font-size: {body}px; }}
/* QWidget's background cascades onto every child, so without this QLabel
   paints a filled box behind its text -- on the title bar that puts white
   type on a white rectangle and hides the subtitle entirely. */
QLabel {{ background: transparent; }}
#titleBar {{ background-color: {pal['accent']}; }}
#titleLabel {{ color: {afg}; font-size: {title}px; font-weight: 600; }}
#subtitleLabel {{ color: {afg}; font-size: {sub}px; }}

QGroupBox {{
    border: 1px solid {line}; border-radius: 8px;
    background: {card}; margin-top: 10px; padding: 9px;
    font-size: {body}px;
}}
QGroupBox::title {{
    subcontrol-origin: margin; left: 10px; padding: 0 5px;
    color: {acc}; font-weight: 600; font-size: {body}px;
}}

QLineEdit, QComboBox {{
    border: 1px solid {line}; border-radius: 4px; padding: 4px 7px;
    background: {card}; color: {fg}; font-size: {body}px;
}}
QLineEdit:focus, QComboBox:focus {{ border-color: {pal['accent']}; }}
QLineEdit:disabled, QComboBox:disabled {{
    background: {pal['bg']}; color: {pal['disabled']}; border-color: {line};
}}
QComboBox::drop-down {{ border: none; width: 20px; }}
QComboBox QLineEdit {{ border: none; background: transparent; }}

/* D-11 equivalent: the popup list must carry the theme, not fall back to
   the system palette, or dark themes get an unreadable white popup. */
QComboBox QAbstractItemView {{
    background: {card}; color: {fg}; border: 1px solid {line};
    selection-background-color: {pal['cal']['bg_in']};
    selection-color: {pal['cal']['fg_in']};
    outline: none; font-size: {body}px;
}}

QPushButton {{
    background: {pal['disabled']}; color: {fg}; border: none;
    border-radius: 5px; padding: 6px 12px; font-size: {body}px;
}}
QPushButton:hover {{ background: {muted}; }}
QPushButton:disabled {{ background: {pal['bg']}; color: {pal['disabled']}; }}
QPushButton#runButton {{
    background: {pal['accent']}; color: {afg};
    padding: 8px 22px; font-size: {action}px; font-weight: 600;
}}
QPushButton#runButton:hover {{ background: {pal['accent_text']}; }}
QPushButton#stopButton {{
    background: {pal['stop']}; color: {afg};
    padding: 8px 18px; font-size: {action}px; font-weight: 600;
}}
QPushButton#existingButton {{ background: {pal['exist']}; color: {afg}; }}
QPushButton#toggleButton {{
    background: {card}; color: {acc}; border: 1px solid {line};
    border-radius: 14px; padding: 5px 14px; font-size: {hint}px;
}}
QPushButton#toggleButton:hover {{ background: {line}; }}
QPushButton#panelButton {{
    background: transparent; color: {acc}; border: none;
    border-radius: 4px; padding: 3px 4px; text-align: left;
    font-weight: 600; font-size: {body}px;
}}
QPushButton#panelButton:hover {{ background: {card}; }}

QTextEdit#logView {{
    font-family: {MONO_FAMILY}, monospace; font-size: {log}px;
    background-color: {pal['log_bg']}; color: {pal['log_fg']};
    border: 1px solid {pal['log_line']}; border-radius: 5px; padding: 6px;
}}
QTextEdit#previewView {{
    font-family: {MONO_FAMILY}, monospace; font-size: {prew}px;
    background-color: {pal['pv_bg']}; color: {pal['pv_fg']};
    border: 1px solid {line}; border-radius: 5px; padding: 6px;
}}

QTabWidget::pane {{ border: 1px solid {line}; border-radius: 5px; }}
QTabBar::tab {{
    padding: 8px 18px; background: {card}; border-radius: 4px;
    color: {muted}; font-size: {body}px;
}}
QTabBar::tab:selected {{ background: {bg}; color: {acc}; font-weight: 600; }}

QLabel#hint {{ color: {muted}; font-size: {hint}px; }}
QLabel#sectionTitle {{ color: {acc}; font-size: {body}px; font-weight: 600; }}
QCheckBox {{ background: transparent; font-size: {body}px; }}
QCheckBox:disabled {{ color: {pal['disabled']}; }}
QScrollArea {{ border: none; }}

QScrollBar:vertical {{
    background: {bg}; width: 13px; margin: 0; border: none;
}}
QScrollBar::handle:vertical {{
    background: {pal['accent']}; min-height: 28px;
    border-radius: 6px; margin: 2px;
}}
QScrollBar::handle:vertical:hover {{ background: {pal['accent_text']}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0; background: transparent;
}}
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
    background: transparent;
}}
QScrollBar:horizontal {{
    background: {bg}; height: 13px; margin: 0; border: none;
}}
QScrollBar::handle:horizontal {{
    background: {pal['accent']}; min-width: 28px;
    border-radius: 6px; margin: 2px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{
    width: 0; background: transparent;
}}
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
    background: transparent;
}}
"""


# ═════════════════════════════════════════════════════════════
#  SELECT-ALL DIALOG
# ═════════════════════════════════════════════════════════════
class SelectAllDialog(QDialog):
    def __init__(self, parent, title, items, selected=None, columns=3, labels=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.resize(430, 500)
        self._columns = columns
        self.items = list(items)
        self.labels = labels or {}
        self.checks: dict[str, QCheckBox] = {}

        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search...")
        self.search.textChanged.connect(self._filter)
        lay.addWidget(self.search)

        bar = QHBoxLayout()
        self.count_lbl = QLabel(f"Total: {len(items)}")
        bar.addWidget(self.count_lbl)
        bar.addStretch(1)
        for text, slot in (("Invert", self._invert),
                           ("Clear All", lambda: self._set_all(False)),
                           ("Select All", lambda: self._set_all(True))):
            b = QPushButton(text)
            b.clicked.connect(slot)
            bar.addWidget(b)
        lay.addLayout(bar)

        self.host = QWidget()
        self.grid = QGridLayout(self.host)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.host)
        lay.addWidget(scroll, 1)

        sel = set(selected or [])
        for item in self.items:
            cb = QCheckBox(self.labels.get(item, item))
            cb.setChecked(item in sel)
            self.checks[item] = cb
        self._filter()

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def _visible(self):
        q = self.search.text().strip().lower()
        return [i for i in self.items if not q or q in i.lower()]

    def _filter(self, *_):
        while self.grid.count():
            it = self.grid.takeAt(0)
            if it.widget():
                it.widget().setParent(None)
        vis = self._visible()
        for i, item in enumerate(vis):
            self.grid.addWidget(self.checks[item],
                                i // self._columns, i % self._columns)
        self.count_lbl.setText(f"Showing {len(vis)} / {len(self.items)}")

    def _set_all(self, active):
        for item in self._visible():
            self.checks[item].setChecked(active)

    def _invert(self):
        for item in self._visible():
            self.checks[item].setChecked(not self.checks[item].isChecked())

    def selected(self):
        return [k for k, v in self.checks.items() if v.isChecked()]

    @staticmethod
    def ask(parent, title, items, selected=None, columns=3, labels=None):
        dlg = SelectAllDialog(parent, title, items, selected, columns, labels)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            return dlg.selected()
        return None


# ═════════════════════════════════════════════════════════════
#  YEAR PICKER
# ═════════════════════════════════════════════════════════════
class YearPicker(QDialog):
    def __init__(self, parent, years, current=""):
        super().__init__(parent)
        self.setWindowTitle("Select Years")
        self.setModal(True)
        self.resize(320, 450)
        self.years = list(years)
        self.result_text = None

        cur = {y.strip() for y in str(current).split(",") if y.strip()}
        cur |= set(parse_years(str(current)))

        lay = QVBoxLayout(self)
        self.host = QWidget()
        self.grid = QGridLayout(self.host)
        self.checks = {}
        for i, y in enumerate(self.years):
            cb = QCheckBox(str(y))
            cb.setChecked(str(y) in cur)
            self.checks[y] = cb
            self.grid.addWidget(cb, i // 4, i % 4)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.host)
        lay.addWidget(scroll, 1)

        bar = QHBoxLayout()
        for text, slot in (("All", lambda: self._set_all(True)),
                           ("None", lambda: self._set_all(False)),
                           ("Range...", self._range)):
            b = QPushButton(text)
            b.clicked.connect(slot)
            bar.addWidget(b)
        lay.addLayout(bar)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._ok)
        buttons.rejected.connect(self.reject)
        lay.addWidget(buttons)

    def _set_all(self, active):
        for cb in self.checks.values():
            cb.setChecked(active)

    def _range(self):
        nums = sorted(self.years)
        dlg = QDialog(self)
        dlg.setWindowTitle("Select Year Range")
        from PySide6.QtWidgets import QFormLayout
        form = QFormLayout(dlg)
        start, end = QComboBox(), QComboBox()
        for n in nums:
            start.addItem(str(n))
            end.addItem(str(n))
        start.setCurrentIndex(0)
        end.setCurrentIndex(len(nums) - 1)
        form.addRow("Start Year:", start)
        form.addRow("End Year:", end)
        bb = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        form.addRow(bb)
        if dlg.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            a, b = int(start.currentText()), int(end.currentText())
        except ValueError:
            return
        if a > b:
            a, b = b, a
        for y, cb in self.checks.items():
            cb.setChecked(a <= y <= b)

    def _ok(self):
        sel = [str(y) for y, v in self.checks.items() if v.isChecked()]
        if not sel:
            self.result_text = ""
        elif all(int(sel[i]) + 1 == int(sel[i + 1]) for i in range(len(sel) - 1)):
            self.result_text = f"{sel[0]}-{sel[-1]}"
        else:
            self.result_text = ",".join(sel)
        self.accept()


# ═════════════════════════════════════════════════════════════
#  MONTH-GRID CALENDAR  (range selection)
#
#  PySide6 6.12 does not expose QCalendarWidget.SelectionMode.DateRangeSelection,
#  so this uses the same compact month grid as the tkinter build — identical
#  look in both executables, and a smaller vertical footprint.
# ═════════════════════════════════════════════════════════════
class MonthCalendar(QWidget):
    _pal = palette(DEFAULT_THEME)
    _day_px = 10

    def __init__(self, parent=None, year=2005):
        super().__init__(parent)
        self.year = year
        self.month = 1
        self.start = None
        self.end = None
        self.min_year, self.max_year = 1979, 2020
        self.on_change = None
        self._cells = {}
        self._build()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(2)

        head = QHBoxLayout()
        head.setSpacing(4)
        prev = QPushButton("\u2039")
        prev.setFixedWidth(26)
        prev.clicked.connect(lambda: self.shift(-1))
        nxt = QPushButton("\u203a")
        nxt.setFixedWidth(26)
        nxt.clicked.connect(lambda: self.shift(1))
        self.title = QLabel("")
        self.title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.title.setStyleSheet("font-weight:600;")
        head.addWidget(prev)
        head.addWidget(self.title, 1)
        head.addWidget(nxt)
        lay.addLayout(head)

        grid = QGridLayout()
        grid.setSpacing(1)
        grid.setColumnMinimumWidth(0, 28)
        self._head_labels = []
        for c, name in enumerate(["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"]):
            lbl = QLabel(name)
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            # Fixed width must match the day buttons, or the grid distributes
            # the 232px container unevenly and columns visibly misalign.
            lbl.setFixedWidth(28)
            lbl.setStyleSheet("font-size:9px;")
            self._head_labels.append(lbl)
            grid.addWidget(lbl, 0, c)
        self.grid_host = QWidget()
        self.grid = QGridLayout(self.grid_host)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(1)
        grid.addWidget(self.grid_host, 1, 0, 1, 7)
        lay.addLayout(grid)

        self.render()

    def set_year_range(self, lo, hi):
        self.min_year, self.max_year = lo, hi
        self.year = max(lo, min(hi, self.year))
        self.render()

    def shift(self, delta):
        m, y = self.month + delta, self.year
        while m < 1:
            m += 12
            y -= 1
        while m > 12:
            m -= 12
            y += 1
        self.year = max(self.min_year, min(self.max_year, y))
        self.month = m
        self.render()

    def get_range(self):
        if self.start and self.end:
            return tuple(sorted((self.start, self.end)))
        if self.start:
            return self.start, self.start
        return None, None

    def set_range(self, a, b=None):
        if a is None:
            self.start = self.end = None
        else:
            self.start, self.end = a, (b or a)
            self.year, self.month = a.year, a.month
        self.render()

    def clear(self):
        self.set_range(None)

    def render(self):
        import calendar as _cal
        while self.grid.count():
            it = self.grid.takeAt(0)
            if it.widget():
                it.widget().setParent(None)
        self._cells.clear()

        self.title.setText(f"{MONTH_NAMES[self.month - 1][:3]} {self.year}")
        weeks = _cal.monthcalendar(self.year, self.month)
        a, b = self.get_range()
        today = date.today()
        # Palette-driven, so all 15 themes render correctly (was a dark flag).
        cal = self._pal["cal"]
        hov_bg = self._pal["accent_text"]

        for r, week in enumerate(weeks):
            for c, day in enumerate(week):
                if day == 0:
                    sp = QLabel("")
                    sp.setFixedSize(28, 21)
                    self.grid.addWidget(sp, r, c)
                    continue
                d = date(self.year, self.month, day)
                in_range = bool(a and b and a <= d <= b)
                edge = d in (a, b)
                if in_range:
                    bg, fg = cal["bg_in"], cal["fg_in"]
                elif d == today:
                    bg, fg = cal["today_bg"], cal["fg_edge"]
                else:
                    bg, fg = cal["bg_norm"], cal["fg_norm"]
                border = f"1px solid {cal['fg_edge']}" if edge else "1px solid transparent"
                weight = "600" if edge else "400"

                btn = QPushButton(str(day))
                btn.setFixedSize(28, 21)
                btn.setFlat(True)
                btn.setCursor(Qt.CursorShape.PointingHandCursor)
                btn.setStyleSheet(
                    f"QPushButton{{background:{bg};color:{fg};"
                    f"border:{border};font-weight:{weight};"
                    f"font-size:{self._day_px}px;padding:0;}}"
                    f"QPushButton:hover{{background:{hov_bg};}}")
                btn.clicked.connect(lambda _=False, dd=d: self._click(dd))
                self.grid.addWidget(btn, r, c)
                self._cells[d] = btn

    def _click(self, d):
        if self.start is None or (self.start and self.end):
            self.start, self.end = d, None
        elif d < self.start:
            self.start, self.end = d, self.start
        else:
            self.end = d
        self.render()
        if self.on_change:
            self.on_change(self.get_range())

    def set_theme(self, pal, scale: float = 1.0):
        self._pal = pal
        self._day_px = scaled("cal_day", scale)
        self.title.setStyleSheet(
            f"font-weight:600;font-size:{scaled('cal_title', scale)}px;"
            f"color:{pal['fg']};")
        self._head_px = scaled("cal_head", scale)
        for lbl in self._head_labels:
            lbl.setStyleSheet(f"font-size:{self._head_px}px;color:{pal['muted']};")
        self.render()


# ═════════════════════════════════════════════════════════════
#  WORKER THREAD
# ═════════════════════════════════════════════════════════════
class Worker(QThread):
    log = Signal(str, str)
    status = Signal(str)
    done = Signal()
    jobs = Signal(object)      # list[dict] of completed portal jobs

    def __init__(self, fn, parent=None):
        super().__init__(parent)
        self._fn = fn

    def emit_log(self, msg, level="info"):
        self.log.emit(msg, level)

    def emit_status(self, msg):
        self.status.emit(msg)

    def emit_jobs(self, jobs):
        self.jobs.emit(jobs)

    def run(self):
        try:
            # Pass this Worker: every job handed to _start is
            # `def job(worker: Worker)` so it can emit_log/emit_status.
            self._fn(self)
        except KeyboardInterrupt:
            self.log.emit("\n--- Stopped by user ---", "warn")
            self.status.emit("Stopped by user")
        except Exception as e:
            self.log.emit(f"\nERROR: {e}", "error")
            self.status.emit("Error")
        finally:
            self.done.emit()


# ═════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ═════════════════════════════════════════════════════════════
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        # Fits a 1366x768 screen (the common 14" laptop) with room to spare.
        # 1180x660 matches the Tk build; 1000 was too narrow for the right
        # column. See UI-WORKLOG.md D-01.
        self.resize(1180, 660)
        self.setMinimumSize(960, 540)

        self._theme = DEFAULT_THEME
        self._font_step = DEFAULT_FONT_STEP
        self._cal_collapsed = False
        self._preview_collapsed = False
        self._worker: Worker | None = None
        self._stop = None
        self._presets = PresetManager()
        self._job_log = JobLog()

        default_ds = DS_KEYS[0]
        self._sel_months = [m[0] for m in MONTHS]
        self._sel_days = DAYS[:]
        self._sel_times = list(TIME_ALL.get(default_ds, []))
        self._sel_vars: list[str] = []
        self._sel_pressure: list[str] = []
        self._sel_forecast: list[str] = []
        self._init_day = "01"

        self._build_ui()
        self._refresh_dataset_fields()
        self._auto_update_target()
        self._populate_presets()
        self._load_credentials()
        self._refresh_paths()
        self._load_ui_prefs()
        self._apply_theme()
        # Apply fold state read from ui.cfg (the buttons already show ▸).
        self.cal.setVisible(not self._cal_collapsed)
        self.range_lbl.setVisible(not self._cal_collapsed)
        self.preview.setVisible(not self._preview_collapsed)
        self._update_preview()

    # ── layout ──────────────────────────────────────────────
    def _build_ui(self):
        central = QWidget()
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        tb = QFrame()
        tb.setObjectName("titleBar")
        tb.setFixedHeight(58)
        tbl = QHBoxLayout(tb)
        tbl.setContentsMargins(16, 8, 16, 8)
        box = QVBoxLayout()
        box.setSpacing(0)
        t = QLabel("NCMRWF Data Downloader  v0.5")
        t.setObjectName("titleLabel")
        s = QLabel(APP_SUBTITLE)
        s.setObjectName("subtitleLabel")
        box.addWidget(t)
        box.addWidget(s)
        tbl.addLayout(box)
        tbl.addStretch(1)

        # Theme + font-size pickers, mirroring the Tk top bar (D-10, D-13).
        tbl.addWidget(QLabel("Theme:"))
        self.theme_combo = QComboBox()
        for n in THEME_ORDER:
            self.theme_combo.addItem(n)
        self.theme_combo.setCurrentText(self._theme)
        self.theme_combo.currentTextChanged.connect(self._set_theme)
        tbl.addWidget(self.theme_combo)

        tbl.addWidget(QLabel("Text:"))
        self.font_combo = QComboBox()
        for n in FONT_STEPS:
            self.font_combo.addItem(n)
        self.font_combo.setCurrentText(self._font_step)
        self.font_combo.currentTextChanged.connect(self._set_font_step)
        tbl.addWidget(self.font_combo)
        root.addWidget(tb)

        tabs = QTabWidget()
        tabs.addTab(self._tab_download(), "  Download  ")
        tabs.addTab(self._tab_presets(), "  Presets  ")
        tabs.addTab(self._tab_settings(), "  Settings  ")
        wrap = QWidget()
        wl = QVBoxLayout(wrap)
        wl.setContentsMargins(8, 8, 8, 8)
        wl.addWidget(tabs)
        root.addWidget(wrap, 1)

        self.setCentralWidget(central)
        self.statusBar().showMessage("Ready")

    def _tab_download(self) -> QWidget:
        # Three-tier layout: the config panels scroll, but the action bar and
        # the job log are pinned below them (UI-WORKLOG.md D-14 / D-18). The
        # old single-scroll version let Submit scroll off-screen on a short
        # window, which is exactly the case this app runs in.
        outer = QWidget()
        root = QVBoxLayout(outer)
        root.setContentsMargins(4, 4, 4, 4)
        root.setSpacing(6)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        f = QWidget()
        scroll.setWidget(f)

        lay = QVBoxLayout(f)
        lay.setContentsMargins(4, 4, 8, 4)
        lay.setSpacing(6)
        lay.addStretch(0)

        cols = QHBoxLayout()
        cols.setSpacing(8)
        lay.addLayout(cols)

        left = QVBoxLayout()
        left.setSpacing(6)
        right = QVBoxLayout()
        right.setSpacing(6)
        cols.addLayout(left, 3)
        cols.addLayout(right, 2)

        # ── dataset + year strip ──
        top = QGroupBox("Dataset & Year")
        tl = QHBoxLayout(top)
        tl.setContentsMargins(9, 6, 9, 8)
        self.ds_combo = QComboBox()
        for k in DS_KEYS:
            self.ds_combo.addItem(DATASETS[k]["label"], k)
        self.ds_combo.currentIndexChanged.connect(self._on_dataset_changed)
        tl.addWidget(self.ds_combo, 1)
        tl.addWidget(QLabel("Year(s):"))
        self.year_edit = QLineEdit("2005")
        self.year_edit.setMaximumWidth(110)
        self.year_edit.textChanged.connect(lambda *_: self._auto_update_target())
        tl.addWidget(self.year_edit)
        tl.addWidget(self._btn("Pick", self._pick_years))
        lay.addWidget(top)

        # ── date range + calendar ──
        dr = QGroupBox("Date Range")
        dl = QVBoxLayout(dr)
        dl.setContentsMargins(9, 6, 9, 8)
        dl.setSpacing(4)

        # D-19: folding the calendar saves ~230px on a 768px-tall screen.
        self.cal_hdr = QPushButton("▾  Calendar")
        self.cal_hdr.setObjectName("panelButton")
        self.cal_hdr.setCursor(Qt.CursorShape.PointingHandCursor)
        self.cal_hdr.clicked.connect(self._toggle_cal)
        dl.addWidget(self.cal_hdr, 0, Qt.AlignmentFlag.AlignLeft)

        srow = QHBoxLayout()
        self.season_combo = QComboBox()
        for name in SEASON_PRESETS:
            self.season_combo.addItem(name)
        self.season_combo.setMaximumWidth(120)
        self.season_combo.currentIndexChanged.connect(lambda *_: self._apply_season())
        srow.addWidget(self.season_combo)
        srow.addWidget(self._btn("Clear", self._clear_dates))
        srow.addStretch(1)
        srow.addWidget(self._btn("Advanced months/days…", self._advanced_dates))
        dl.addLayout(srow)

        self.cal = MonthCalendar(self, year=2005)
        self.cal.on_change = self._on_cal_change
        self.cal.setFixedWidth(232)
        dl.addWidget(self.cal, 0, Qt.AlignmentFlag.AlignLeft)

        self.range_lbl = QLabel("")
        self.range_lbl.setObjectName("hint")
        self.range_lbl.setWordWrap(True)
        dl.addWidget(self.range_lbl)
        left.addWidget(dr)

        # ── variables ──
        vf = QGroupBox("Variables")
        vl = QHBoxLayout(vf)
        vl.setContentsMargins(9, 6, 9, 8)
        vl.addWidget(self._btn("Select All", self._sel_all_vars))
        vl.addWidget(self._btn("Clear", self._clear_vars))
        vl.addWidget(self._btn("Choose…", self._pick_vars))
        vl.addStretch(1)
        self.var_lbl = QLabel("None selected")
        self.var_lbl.setObjectName("hint")
        self.var_lbl.setWordWrap(True)
        vl.addWidget(self.var_lbl, 1)
        left.addWidget(vf)

        # ── pressure ──
        self.prl_box = QGroupBox("Pressure Levels")
        pl = QHBoxLayout(self.prl_box)
        pl.setContentsMargins(9, 6, 9, 8)
        self.prl_lbl = QLabel("None selected")
        self.prl_lbl.setObjectName("hint")
        self.prl_lbl.setWordWrap(True)
        pl.addWidget(self.prl_lbl, 1)
        pl.addWidget(self._btn("Choose…", self._pick_pressure))
        left.addWidget(self.prl_box)

        # ── spatial domain ──
        bb = QGroupBox("Spatial Domain")
        bg = QVBoxLayout(bb)
        bg.setContentsMargins(9, 6, 9, 8)
        bg.setSpacing(4)
        rrow = QHBoxLayout()
        rrow.addWidget(QLabel("Region:"))
        self.region_combo = QComboBox()
        for name in [*REGION_PRESETS, "Custom"]:
            self.region_combo.addItem(name)
        self.region_combo.setMaximumWidth(110)
        self.region_combo.currentTextChanged.connect(lambda *_: self._apply_region())
        rrow.addWidget(self.region_combo)
        rrow.addWidget(self._btn("Reset", self._reset_bbox))
        rrow.addStretch(1)
        bg.addLayout(rrow)

        grid = QGridLayout()
        self.bbox = {}
        for i, (key, label, ph) in enumerate([("north", "N:", "45"),
                                               ("south", "S:", "-15"),
                                               ("east", "E:", "120"),
                                               ("west", "W:", "30")]):
            grid.addWidget(QLabel(label), 0, i * 2)
            e = QLineEdit()
            e.setPlaceholderText(ph)
            e.setMaximumWidth(62)
            self.bbox[key] = e
            grid.addWidget(e, 0, i * 2 + 1)
        grid.setColumnStretch(7, 1)
        bg.addLayout(grid)
        right.addWidget(bb)
        self._apply_region()

        # ── time (hourly only) ──
        self.time_box = QGroupBox("Time (UTC)")
        tl2 = QHBoxLayout(self.time_box)
        tl2.setContentsMargins(9, 6, 9, 8)
        self.time_lbl = QLabel("All")
        self.time_lbl.setObjectName("hint")
        tl2.addWidget(self.time_lbl, 1)
        tl2.addWidget(self._btn("Choose…", self._pick_times))
        right.addWidget(self.time_box)

        # ── forecast lead (S2S only) ──
        self.fc_box = QGroupBox("Forecast Lead (S2S)")
        fl = QHBoxLayout(self.fc_box)
        fl.setContentsMargins(9, 6, 9, 8)
        fl.addWidget(QLabel("Init day:"))
        self.init_combo = QComboBox()
        self.init_combo.setMaximumWidth(60)
        self.init_combo.currentTextChanged.connect(
            lambda t: setattr(self, "_init_day", t))
        fl.addWidget(self.init_combo)
        self.fc_lbl = QLabel("")
        self.fc_lbl.setObjectName("hint")
        fl.addWidget(self.fc_lbl, 1)
        fl.addWidget(self._btn("Choose…", self._pick_forecast))
        right.addWidget(self.fc_box)

        # ── output ──
        ob = QGroupBox("Output")
        og = QVBoxLayout(ob)
        og.setContentsMargins(9, 6, 9, 8)
        og.setSpacing(4)
        og.addWidget(QLabel("Folder:"))
        drow = QHBoxLayout()
        self.dl_edit = QLineEdit(str(self._default_dl_dir()))
        drow.addWidget(self.dl_edit, 1)
        drow.addWidget(self._btn("Browse", self._browse_dir))
        og.addLayout(drow)
        og.addWidget(QLabel("Target:"))
        self.tgt_edit = QLineEdit()
        self.tgt_edit.textEdited.connect(lambda *_: self._update_target_hint())
        og.addWidget(self.tgt_edit)
        self.tgt_hint = QLabel("")
        self.tgt_hint.setObjectName("hint")
        self.tgt_hint.setWordWrap(True)
        og.addWidget(self.tgt_hint)
        right.addWidget(ob)

        # ── request preview (D-06, collapsible D-19) ──
        # Empty group title: the fold button below IS the header (D-19).
        pv = QGroupBox("")
        pg = QVBoxLayout(pv)
        pg.setContentsMargins(9, 6, 9, 8)
        pg.setSpacing(4)
        self.pv_hdr = QPushButton("▾  Request preview")
        self.pv_hdr.setObjectName("panelButton")
        self.pv_hdr.setCursor(Qt.CursorShape.PointingHandCursor)
        self.pv_hdr.clicked.connect(self._toggle_preview)
        pg.addWidget(self.pv_hdr, 0, Qt.AlignmentFlag.AlignLeft)
        self.preview = QTextEdit()
        self.preview.setObjectName("previewView")
        self.preview.setReadOnly(True)
        self.preview.setMinimumHeight(90)
        # wrap=word, not none: none clipped long payload lines mid-token.
        self.preview.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        pg.addWidget(self.preview)
        right.addWidget(pv)

        # ── actions ──
        bar = QHBoxLayout()
        self.run_btn = QPushButton("Submit & Download")
        self.run_btn.setObjectName("runButton")
        self.run_btn.clicked.connect(self._run)
        bar.addWidget(self.run_btn)
        self.stop_btn = QPushButton("Stop")
        self.stop_btn.setObjectName("stopButton")
        self.stop_btn.setEnabled(False)
        self.stop_btn.clicked.connect(self._stop_clicked)
        bar.addWidget(self.stop_btn)
        self.exist_btn = QPushButton("Download Existing")
        self.exist_btn.setObjectName("existingButton")
        self.exist_btn.clicked.connect(self._run_existing)
        bar.addWidget(self.exist_btn)
        bar.addStretch(1)
        bar.addWidget(self._btn("Generate Request", self._generate_request))
        bar.addWidget(self._btn("Save as Preset", self._save_preset))
        # ── log ──
        lf = QGroupBox("Job Log")
        ll = QVBoxLayout(lf)
        ll.setContentsMargins(9, 6, 9, 8)
        ll.setSpacing(4)
        lt = QHBoxLayout()
        lt.addStretch(1)
        lt.addWidget(self._btn("Copy", self._copy_log))
        lt.addWidget(self._btn("Clear", self._clear_log))
        ll.addLayout(lt)
        self.log_view = QTextEdit()
        self.log_view.setObjectName("logView")
        self.log_view.setReadOnly(True)
        self.log_view.setMinimumHeight(170)
        self.log_view.setSizePolicy(QSizePolicy.Policy.Expanding,
                                    QSizePolicy.Policy.Expanding)
        ll.addWidget(self.log_view)

        # Three-tier assembly: config scrolls, bar and log are pinned.
        root.addWidget(scroll, 1)
        root.addLayout(bar, 0)
        root.addWidget(lf, 0)

        return outer

    def _tab_presets(self) -> QWidget:
        f = QWidget()
        lay = QVBoxLayout(f)
        t = QLabel("Save and load your download configurations")
        t.setObjectName("hint")
        lay.addWidget(t)
        self.preset_list = QWidget()
        self.preset_layout = QVBoxLayout(self.preset_list)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(self.preset_list)
        lay.addWidget(scroll, 1)
        bar = QHBoxLayout()
        lb = QPushButton("Load Selected")
        lb.setObjectName("existingButton")
        lb.clicked.connect(lambda: self._load_preset())
        bar.addWidget(lb)
        db = QPushButton("Delete Selected")
        db.setObjectName("stopButton")
        db.clicked.connect(self._delete_preset)
        bar.addWidget(db)
        bar.addStretch(1)
        lay.addLayout(bar)
        return f

    def _tab_settings(self) -> QWidget:
        f = QWidget()
        lay = QVBoxLayout(f)

        cf = QGroupBox("Credentials")
        cg = QGridLayout(cf)
        cg.addWidget(QLabel("Email:"), 0, 0)
        self.email_edit = QLineEdit()
        self.email_edit.setPlaceholderText("your@email.com")
        cg.addWidget(self.email_edit, 0, 1)
        cg.addWidget(QLabel("Password:"), 1, 0)
        self.pass_edit = QLineEdit()
        self.pass_edit.setEchoMode(QLineEdit.EchoMode.Password)
        cg.addWidget(self.pass_edit, 1, 1)
        sb = QPushButton("Save")
        sb.setObjectName("existingButton")
        sb.clicked.connect(self._save_credentials)
        cg.addWidget(sb, 0, 2)
        cg.setColumnStretch(1, 1)
        lay.addWidget(cf)

        of = QGroupBox("Existing Jobs Folder")
        oh = QHBoxLayout(of)
        self.existing_edit = QLineEdit(str(self._default_dl_dir() / "existing"))
        oh.addWidget(self.existing_edit, 1)
        oh.addWidget(self._btn("Browse", self._browse_existing))
        lay.addWidget(of)

        lf = QGroupBox("Local Files")
        lv = QVBoxLayout(lf)
        self.path_lbl = QLabel("")
        self.path_lbl.setObjectName("hint")
        self.path_lbl.setWordWrap(True)
        self.path_lbl.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse)
        lv.addWidget(self.path_lbl)
        lv.addWidget(self._btn("Open Config Folder", self._open_config_dir),
                     0, Qt.AlignmentFlag.AlignLeft)
        lay.addWidget(lf)

        af = QGroupBox("About")
        al = QVBoxLayout(af)
        al.addWidget(QLabel(
            "NCMRWF RDS Downloader v0.4 (Windows / Qt)\n"
            "Copyright Subhrajit Rath\n\n"
            "The download engine is built in — bash, curl and jq are NOT\n"
            "required on this machine.\n\n"
            f"Config & presets : {config_dir()}\n"
            f"Credentials      : {Path.home() / '.ncmrwfapirc'}\n"
            f"Job log          : {config_dir() / 'submitted_jobs.log'}"))
        lay.addWidget(af)
        lay.addStretch(1)
        return f

    @staticmethod
    def _btn(text, slot) -> QPushButton:
        b = QPushButton(text)
        b.clicked.connect(slot)
        return b

    # ── state ──────────────────────────────────────────────
    @staticmethod
    def _default_dl_dir() -> Path:
        # In a frozen build __file__ lives in PyInstaller's temporary extraction
        # directory, so the sibling "downloads" heuristic would resolve to
        # %TEMP%\downloads.  Only a source-tree run should use it at all; an
        # installed package is not writable there either, hence the test.
        if not getattr(sys, "frozen", False):
            local = Path(__file__).resolve().parent.parent / "downloads"
            if local.is_dir() and os.access(local, os.W_OK):
                return local
        return Path.home() / "Downloads" / "rds_data"

    def _ds_key(self) -> str:
        return self.ds_combo.currentData() or DS_KEYS[0]

    def _on_dataset_changed(self, *_):
        self._refresh_dataset_fields()
        self._auto_update_target()

    def _refresh_dataset_fields(self):
        ds = self._ds_key()
        cfg = DATASETS[ds]
        self.time_box.setVisible(bool(cfg["time"]))
        self.prl_box.setVisible(bool(cfg["pressure"]))
        self.fc_box.setVisible(bool(cfg.get("forecast")))
        years = list(cfg["years"])
        self.cal.set_year_range(min(years), max(years))
        self._sel_vars = []
        self._sel_pressure = []
        self._sel_times = list(TIME_ALL.get(ds, []))
        fc = FORECAST_DAYS.get(ds) or []
        self._sel_forecast = fc[:1]
        self._init_day = (INIT_DAYS.get(ds) or ["01"])[0]
        self.init_combo.clear()
        self.init_combo.addItems(INIT_DAYS.get(ds) or ["01"])
        self.init_combo.setCurrentText(self._init_day)
        self._reset_bbox_to_dataset()
        self._update_tags()
        self._update_range_hint(None, None)

    def _reset_bbox_to_dataset(self):
        """Adopt the dataset's natural domain (ocean is 0-360, S2S global,
        MERA India-only) whenever the dataset changes."""
        d = DATASETS[self._ds_key()]["bbox"]
        self.region_combo.blockSignals(True)
        self.region_combo.setCurrentText("Custom")
        self.region_combo.blockSignals(False)
        for k in ("north", "south", "east", "west"):
            self.bbox[k].setText(str(d[k]))

    def _update_tags(self):
        nv = len(self._sel_vars)
        self.var_lbl.setText("None selected" if nv == 0 else
                             (", ".join(self._sel_vars) if nv <= 5
                              else f"{nv} variables selected"))
        npv = len(self._sel_pressure)
        self.prl_lbl.setText("None selected" if npv == 0 else
                             (", ".join(self._sel_pressure) if npv <= 5
                              else f"{npv} levels selected"))
        all_t = TIME_ALL.get(self._ds_key(), [])
        nt = len(self._sel_times)
        self.time_lbl.setText("All" if nt == len(all_t) else
                              (", ".join(self._sel_times) if nt <= 8
                               else f"{nt} hours"))
        nf = len(self._sel_forecast)
        self.fc_lbl.setText("none" if nf == 0 else
                            (", ".join(self._sel_forecast) if nf <= 4
                             else f"{nf} lead days"))
        # Every selection path funnels through here, so refreshing the
        # preview here keeps it honest without a dozen extra call sites.
        self._update_preview()

    # ── calendar ───────────────────────────────────────────
    def _cal_year(self) -> int:
        years = parse_years(self.year_edit.text())
        if years:
            return int(years[0])
        return min(DATASETS[self._ds_key()]["years"])

    def _sync_cal(self, a, b=None):
        self.cal.set_range(a, b)

    def _on_cal_change(self, rng):
        a, b = rng
        if a is None:
            self._sel_months = [m[0] for m in MONTHS]
            self._sel_days = DAYS[:]
        else:
            try:
                self._sel_months, self._sel_days = dates_to_months_days(a, b)
            except ValueError as e:
                self._log(str(e), "warn")
                self.cal.clear()
                return
        self._update_tags()
        self._update_range_hint(a, b)

    def _apply_season(self):
        months = SEASON_PRESETS.get(self.season_combo.currentText())
        if not months:
            return
        self._sel_months = list(months)
        self._sel_days = DAYS[:]
        a, b = months_to_dates_anchor(self._cal_year(), months)
        max_year = max(DATASETS[self._ds_key()]["years"])
        if b is not None and b.year > max_year:
            b = date(max_year, b.month, b.day)
        self.cal.set_range(a, b)
        self._update_tags()
        self._update_range_hint(a, b)

    def _clear_dates(self):
        self.cal.clear()
        self._sel_months = [m[0] for m in MONTHS]
        self._sel_days = DAYS[:]
        self._update_tags()
        self._update_range_hint(None, None)

    def _advanced_dates(self):
        res = SelectAllDialog.ask(
            self, "Select Months", [m[0] for m in MONTHS], self._sel_months,
            6, {v: f"{v} {n[:3]}" for v, n in MONTHS})
        if res is None:
            return
        self._sel_months = res or [m[0] for m in MONTHS]
        res = SelectAllDialog.ask(self, "Select Days", DAYS,
                                  self._sel_days, 8)
        if res is not None:
            self._sel_days = res or DAYS[:]
        self._sync_cal(None)
        self._update_tags()
        self._update_range_hint(None, None)

    def _update_range_hint(self, a=None, b=None):
        m, d = len(self._sel_months), len(self._sel_days)
        mtxt = "all 12 months" if m == 12 else f"{m} month(s)"
        dtxt = "all 31 days" if d == 31 else f"{d} day(s)"
        if a and b and a != b:
            self.range_lbl.setText(
                f"{a:%d %b %Y} → {b:%d %b %Y}   |   requesting {mtxt} × {dtxt}")
        elif a and b:
            self.range_lbl.setText(
                f"{a:%d %b %Y}   |   requesting {mtxt} × {dtxt}")
        else:
            self.range_lbl.setText(f"requesting {mtxt} × {dtxt}")
        if not DATASETS[self._ds_key()].get("day", True):
            self.range_lbl.setText(
                self.range_lbl.text() +
                "\n(this dataset has no day-of-month — whole months are used)")

    # ── pickers ────────────────────────────────────────────
    def _pick_years(self):
        dlg = YearPicker(self, list(DATASETS[self._ds_key()]["years"]),
                         self.year_edit.text())
        if dlg.exec() == QDialog.DialogCode.Accepted and dlg.result_text is not None:
            self.year_edit.setText(dlg.result_text)
            self._apply_season()

    def _pick_times(self):
        avail = TIME_ALL.get(self._ds_key(), [])
        res = SelectAllDialog.ask(self, "Select Times (UTC)", avail,
                                  self._sel_times, 6)
        if res is not None:
            self._sel_times = res
            self._update_tags()

    def _pick_vars(self):
        avail = VARIABLES_BY_DATASET.get(self._ds_key(), [])
        res = SelectAllDialog.ask(self, "Select Variables", avail,
                                  self._sel_vars, 3)
        if res is not None:
            self._sel_vars = res
            self._update_tags()

    def _pick_forecast(self):
        avail = FORECAST_DAYS.get(self._ds_key(), [])
        labels = {d: ("T" if d == "day00" else f"T+{int(d[3:])}")
                  for d in avail}
        res = SelectAllDialog.ask(self, "Select Forecast Lead Days", avail,
                                  self._sel_forecast, 6, labels)
        if res is not None:
            self._sel_forecast = res
            self._update_tags()

    def _pick_pressure(self):
        avail = PRESSURE_LEVELS_BY_DATASET.get(self._ds_key(), [])
        res = SelectAllDialog.ask(self, "Select Pressure Levels", avail,
                                  self._sel_pressure, 3)
        if res is not None:
            self._sel_pressure = res
            self._update_tags()

    def _sel_all_vars(self):
        self._sel_vars = list(VARIABLES_BY_DATASET.get(self._ds_key(), []))
        self._update_tags()

    def _clear_vars(self):
        self._sel_vars = []
        self._update_tags()

    def _apply_region(self):
        name = self.region_combo.currentText()
        if name in REGION_PRESETS:
            n, s, e, w = REGION_PRESETS[name]
            self.bbox["north"].setText(str(n))
            self.bbox["south"].setText(str(s))
            self.bbox["east"].setText(str(e))
            self.bbox["west"].setText(str(w))

    def _reset_bbox(self):
        self.region_combo.setCurrentText("India")
        self._apply_region()

    def _set_theme(self, name: str):
        if name not in THEMES:
            return
        self._theme = name
        self._apply_theme()
        self._save_ui_prefs()

    def _set_font_step(self, step: str):
        if step not in FONT_STEPS:
            return
        self._font_step = step
        self._apply_theme()
        self._save_ui_prefs()

    # ── collapsible panels (D-19) ──────────────────────────
    def _toggle_cal(self):
        self._set_cal_collapsed(not self._cal_collapsed)

    def _set_cal_collapsed(self, collapsed: bool):
        self._cal_collapsed = bool(collapsed)
        self.cal.setVisible(not self._cal_collapsed)
        self.range_lbl.setVisible(not self._cal_collapsed)
        self.cal_hdr.setText("▸  Calendar" if self._cal_collapsed
                             else "▾  Calendar")
        self._save_ui_prefs()

    def _toggle_preview(self):
        self._set_preview_collapsed(not self._preview_collapsed)

    def _set_preview_collapsed(self, collapsed: bool):
        self._preview_collapsed = bool(collapsed)
        self.preview.setVisible(not self._preview_collapsed)
        self.pv_hdr.setText("▸  Request preview" if self._preview_collapsed
                            else "▾  Request preview")
        self._save_ui_prefs()

    def _update_preview(self):
        """Show the exact request_payload that will be submitted.

        Built with the engine's own build_payload(), so what is displayed is
        what is sent -- including dataset-specific quirks (no `day` for S2S,
        bare-number pressure levels). Never raises: a broken field shows as a
        note rather than taking down the UI.
        """
        if not hasattr(self, "preview"):
            return
        ds = self._ds_key()
        try:
            bbox = {k: float(v.text().strip()) if v.text().strip()
                    else float(DATASETS[ds]["bbox"][k])
                    for k, v in self.bbox.items()}
            years = parse_years(self.year_edit.text()) or ["?"]
            _label, payload = build_payload(
                ds, years[0], self._sel_months, self._sel_days,
                self._sel_times if DATASETS[ds]["time"] else None,
                bbox, self._sel_vars, self._sel_pressure,
                init_day=self._init_day, forecast_days=self._sel_forecast)
            rp = dict(payload["request_payload"])
        except Exception as exc:
            self.preview.setPlainText(f"(preview unavailable: {exc})")
            return

        def short(v):
            if isinstance(v, list) and len(v) > 8:
                return f"[{len(v)} values: {v[0]} … {v[-1]}]"
            return v

        parts = ["request_payload\n"]
        for k, v in rp.items():
            parts.append(f'  "{k}": ')
            parts.append(repr(short(v)).replace("'", '"') + "\n")
        self.preview.setPlainText("".join(parts))

    def _apply_theme(self):
        """Repaint everything from the current palette + font scale."""
        pal = palette(self._theme)
        scale = FONT_STEPS.get(self._font_step, FONT_STEPS[DEFAULT_FONT_STEP])
        QApplication.instance().setStyleSheet(build_qss(pal, scale))
        if hasattr(self, "cal"):
            self.cal.set_theme(pal, scale)
        if hasattr(self, "theme_combo") and self.theme_combo.currentText() != self._theme:
            self.theme_combo.setCurrentText(self._theme)
        if hasattr(self, "font_combo") and self.font_combo.currentText() != self._font_step:
            self.font_combo.setCurrentText(self._font_step)

    def _save_ui_prefs(self):
        try:
            (config_dir() / "ui.cfg").write_text(
                f"theme={self._theme}\nfont={self._font_step}\n"
                # NB: must be written as 0/1 -- str(True) is "True", which
                # the loader (and any hand edit) would not read back.
                f"calendar={int(bool(self._cal_collapsed))}\n"
                f"preview={int(bool(self._preview_collapsed))}\n",
                encoding="utf-8")
        except OSError:
            pass

    def _load_ui_prefs(self):
        """Read theme + font step + fold state, tolerating a missing file."""
        theme, step = DEFAULT_THEME, DEFAULT_FONT_STEP
        cal_c = pv_c = False
        try:
            raw = (config_dir() / "ui.cfg").read_text(encoding="utf-8")
            for line in raw.splitlines():
                k, _, v = line.partition("=")
                k, v = k.strip(), v.strip()
                if k == "theme" and v in THEMES:
                    theme = v
                elif k == "font" and v in FONT_STEPS:
                    step = v
                elif k == "calendar" and v in ("0", "1"):
                    cal_c = v == "1"
                elif k == "preview" and v in ("0", "1"):
                    pv_c = v == "1"
        except OSError:
            pass
        # Back-compat shim: earlier builds wrote a bare theme name.
        if theme == DEFAULT_THEME:
            try:
                name = (config_dir() / "theme.cfg").read_text(
                    encoding="utf-8").strip()
                if name in THEMES:
                    theme = name
            except OSError:
                pass
        self._theme, self._font_step = theme, step
        self._cal_collapsed, self._preview_collapsed = cal_c, pv_c

    # ── target ─────────────────────────────────────────────
    def _auto_update_target(self, *_):
        ds = self._ds_key()
        years = parse_years(self.year_edit.text())
        dl = self.dl_edit.text().strip() or str(self._default_dl_dir())
        if len(years) > 1:
            tgt = f"{ds}_{years[0]}-{years[-1]}_{{year}}.zip"
        else:
            tgt = f"{ds}_{years[0] if years else '{year}'}.zip"
        self.tgt_edit.setText(tgt)
        self._update_target_hint()

    def _update_target_hint(self):
        tgt = self.tgt_edit.text().strip()
        dl = self.dl_edit.text().strip() or str(self._default_dl_dir())
        years = parse_years(self.year_edit.text())
        if len(years) > 1:
            names = [str(Path(dl) / tgt.replace("{year}", y)) for y in years[:5]]
            more = f"\n… +{len(years) - 5} more" if len(years) > 5 else ""
            self.tgt_hint.setText(f"{len(years)} files:\n" + "\n".join(names) + more)
        else:
            self.tgt_hint.setText(str(Path(dl) / tgt))

    # ── browse ─────────────────────────────────────────────
    def _browse_dir(self):
        p = QFileDialog.getExistingDirectory(
            self, "Choose download directory",
            self.dl_edit.text() or str(Path.home()))
        if p:
            self.dl_edit.setText(p)
            self._update_target_hint()

    def _browse_existing(self):
        p = QFileDialog.getExistingDirectory(
            self, "Choose folder for existing jobs", self.existing_edit.text())
        if p:
            self.existing_edit.setText(p)

    def _open_config_dir(self):
        # Platform-neutral: os.startfile/explorer exist only on Windows.
        d = str(config_dir())
        try:
            if os.name == "nt":
                os.startfile(d)               # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", d])
            else:
                subprocess.Popen(["xdg-open", d],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
        except Exception:
            pass

    # ── credentials ────────────────────────────────────────
    def _load_credentials(self):
        email, password = read_credentials()
        self.email_edit.setText(email)
        self.pass_edit.setText(password)

    def _save_credentials(self):
        try:
            write_credentials(self.email_edit.text().strip(),
                              self.pass_edit.text().strip())
            self._log("Credentials saved", "ok")
            self.statusBar().showMessage("Credentials saved")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Could not save credentials:\n{e}")

    # ── presets ────────────────────────────────────────────
    def _populate_presets(self):
        while self.preset_layout.count():
            it = self.preset_layout.takeAt(0)
            if it.widget():
                it.widget().setParent(None)
        names = self._presets.names()
        if not names:
            lbl = QLabel("No presets saved yet.")
            lbl.setObjectName("hint")
            self.preset_layout.addWidget(lbl)
            self.preset_layout.addStretch(1)
            return
        for name in names:
            data = self._presets.load_one(name) or {}
            b = QPushButton(name)
            b.setToolTip(f"{data.get('dataset','')}  •  {data.get('year','')}\n"
                         f"{', '.join(data.get('variables', [])) or 'no variables'}")
            b.clicked.connect(lambda _=False, n=name: self._load_preset(n))
            self.preset_layout.addWidget(b)
        self.preset_layout.addStretch(1)

    def _current_config(self):
        return {
            "dataset": self._ds_key(), "year": self.year_edit.text().strip(),
            "months": self._sel_months, "days": self._sel_days,
            "times": self._sel_times, "variables": self._sel_vars,
            "pressure": self._sel_pressure, "forecast": self._sel_forecast,
            "init_day": self._init_day,
            "north": self.bbox["north"].text().strip(),
            "south": self.bbox["south"].text().strip(),
            "east": self.bbox["east"].text().strip(),
            "west": self.bbox["west"].text().strip(),
            "download_dir": self.dl_edit.text().strip(),
            "target_file": self.tgt_edit.text().strip(),
        }

    def _save_preset(self):
        name, ok = QInputDialog.getText(self, "Save Preset", "Preset name:")
        if not ok or not name.strip():
            return
        self._presets.save(name.strip(), self._current_config())
        self._log(f"Preset '{name.strip()}' saved", "ok")
        self._populate_presets()

    def _load_preset(self, name: str | None = None):
        if name is None:
            names = self._presets.names()
            if not names:
                QMessageBox.information(self, "Presets", "No presets saved yet.")
                return
            name, ok = QInputDialog.getItem(self, "Load Preset", "Preset:",
                                            names, 0, False)
            if not ok:
                return
        cfg = self._presets.load_one(name)
        if not cfg:
            return
        ds = cfg.get("dataset", "")
        if ds in DATASETS:
            self.ds_combo.blockSignals(True)
            self.ds_combo.setCurrentIndex(DS_KEYS.index(ds))
            self.ds_combo.blockSignals(False)
            self._refresh_dataset_fields()
        self.year_edit.setText(cfg.get("year", ""))
        self._sel_months = cfg.get("months") or [m[0] for m in MONTHS]
        self._sel_days = cfg.get("days") or DAYS[:]
        self._sel_times = cfg.get("times") or list(TIME_ALL.get(ds, []))
        self._sel_vars = cfg.get("variables", [])
        self._sel_pressure = cfg.get("pressure", [])
        _fc = FORECAST_DAYS.get(ds) or []
        self._sel_forecast = cfg.get("forecast") or _fc[:1]
        self._init_day = cfg.get("init_day") or (INIT_DAYS.get(ds) or ["01"])[0]
        self.init_combo.setCurrentText(self._init_day)
        for k in ("north", "south", "east", "west"):
            self.bbox[k].setText(cfg.get(k, ""))
        self.dl_edit.setText(cfg.get("download_dir", ""))
        self._sync_cal(None)
        self.tgt_edit.setText(cfg.get("target_file", ""))
        self._update_tags()
        self._update_range_hint(None, None)
        self._update_target_hint()
        self._log(f"Preset '{name}' loaded", "ok")
        self.statusBar().showMessage(f"Loaded preset: {name}")

    def _delete_preset(self):
        names = self._presets.names()
        if not names:
            QMessageBox.information(self, "Presets", "No presets saved yet.")
            return
        name, ok = QInputDialog.getItem(self, "Delete Preset", "Preset:",
                                        names, 0, False)
        if not ok or not name:
            return
        if QMessageBox.question(self, "Delete preset",
                                f"Delete preset '{name}'?") == \
                QMessageBox.StandardButton.Yes:
            self._presets.delete(name)
            self._populate_presets()
            self._log(f"Preset '{name}' deleted", "warn")

    def _refresh_paths(self):
        rows = self._job_log.rows()[-5:][::-1]
        if not rows:
            self.path_lbl.setText("No jobs logged yet.")
            return
        txt = "\n".join(f"  {r['year']:<10} {r['status']:<17} {r['target']}"
                        for r in rows)
        self.path_lbl.setText(f"Recent jobs:\n{txt}")

    # ── request ────────────────────────────────────────────
    def _gather(self):
        ds = self._ds_key()
        # strict=True: the year text flows into the job log and the output
        # filename, so reject anything that is not a 4-digit year.
        years = parse_years(self.year_edit.text(), strict=True)
        if not years:
            raise ValueError("No year selected. Use 2005, 2000,2005 or 2000-2010.")
        valid = set(DATASETS[ds]["years"])
        bad = [y for y in years if int(y) not in valid]
        if bad:
            raise ValueError(
                f"Year(s) {', '.join(bad)} are outside the range for "
                f"{DATASETS[ds]['label']} ({min(valid)}-{max(valid)}).")

        bbox = {}
        for k, w in self.bbox.items():
            raw = w.text().strip()
            try:
                bbox[k] = float(raw) if raw else float(DATASETS[ds]["bbox"][k])
            except ValueError:
                bbox[k] = float(DATASETS[ds]["bbox"][k])
        if bbox["south"] >= bbox["north"]:
            raise ValueError("South must be lower than North.")
        if bbox["west"] >= bbox["east"]:
            raise ValueError("West must be lower than East.")

        target = self.tgt_edit.text().strip()
        validate_target_template(target)

        return {
            "dataset": ds, "years": years,
            "months": self._sel_months, "days": self._sel_days,
            "times": self._sel_times if DATASETS[ds]["time"] else [],
            "bbox": bbox, "variables": list(self._sel_vars),
            "pressure": list(self._sel_pressure),
            "forecast": list(self._sel_forecast),
            "init_day": self._init_day,
            "target": target,
            "download_dir": self.dl_edit.text().strip() or str(self._default_dl_dir()),
        }

    def _generate_request(self):
        try:
            g = self._gather()
        except ValueError as e:
            QMessageBox.critical(self, "Invalid request", str(e))
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save request.txt", "request.txt", "Text files (*.txt)")
        if not path:
            return
        Path(path).write_text(
            build_request_text(g["dataset"], g["years"], g["months"], g["days"],
                               g["times"], g["bbox"], g["variables"],
                               g["pressure"], g["download_dir"], g["target"]),
            encoding="utf-8")
        self._log(f"Request file saved: {path}", "ok")

    # ── log ────────────────────────────────────────────────
    _COLORS = {"ok": "#8fce6a", "warn": "#e8af34",
               "error": "#f08a84", "info": "#cdccca"}

    def _log(self, text, tag="info"):
        color = self._COLORS.get(tag, "#cdccca")
        self.log_view.append(
            f'<span style="color:{color}">{_escape(text)}</span>')
        self.log_view.moveCursor(QTextCursor.MoveOperation.End)

    def _clear_log(self):
        self.log_view.clear()

    def _copy_log(self):
        QApplication.clipboard().setText(self.log_view.toPlainText())
        self.statusBar().showMessage("Log copied to clipboard")

    # ── run ────────────────────────────────────────────────
    def _make_client(self, worker: Worker) -> RDSClient:
        email, password = read_credentials()
        email = email or self.email_edit.text().strip()
        password = password or self.pass_edit.text().strip()
        return RDSClient(email, password, log=worker.emit_log,
                         job_log=self._job_log, stop_event=self._stop)

    def _set_running(self, running: bool):
        self.run_btn.setEnabled(not running)
        self.exist_btn.setEnabled(not running)
        self.stop_btn.setEnabled(running)

    def _start(self, fn):
        if self._worker and self._worker.isRunning():
            return
        import threading
        self._stop = threading.Event()
        self._set_running(True)
        self.statusBar().showMessage("Running...")
        self._worker = Worker(fn, self)
        self._worker.log.connect(self._log)
        self._worker.status.connect(self.statusBar().showMessage)
        self._worker.jobs.connect(self._on_jobs_fetched)
        self._worker.done.connect(self._on_worker_done)
        self._worker.start()

    def _on_worker_done(self):
        self._set_running(False)
        self._refresh_paths()

    def _run(self):
        try:
            g = self._gather()
        except ValueError as e:
            QMessageBox.critical(self, "Invalid request", str(e))
            return
        txt = build_request_text(
            g["dataset"], g["years"], g["months"], g["days"], g["times"],
            g["bbox"], g["variables"], g["pressure"],
            g["download_dir"], g["target"])
        for line in txt.splitlines():
            self._log("  " + line)
        if len(g["years"]) > 1:
            self._log(f"  → {len(g['years'])} parallel jobs", "ok")
        self._log("-" * 46)

        def job(worker: Worker):
            client = self._make_client(worker)

            def cycle(pending, final):
                worker.emit_status(f"Polling — {len(final)} done, "
                                   f"{len(pending)} pending")

            res = client.run(
                dataset=g["dataset"], years=g["years"], months=g["months"],
                days=g["days"], times=g["times"], bbox=g["bbox"],
                variables=g["variables"], pressure_levels=g["pressure"],
                target_template=g["target"], download_dir=g["download_dir"],
                on_cycle=cycle,
                init_day=g.get("init_day"),
                forecast_days=g.get("forecast"))
            worker.emit_log("-" * 46)
            worker.emit_log(
                f" SUMMARY — submitted {res['submitted']}  "
                f"downloaded {res['downloaded']}  failed {res['failed']}",
                "ok" if not res["failed"] else "warn")
            worker.emit_status("Done" if not res["failed"] else "Finished with errors")

        self._start(job)

    def _run_existing(self):
        # Phase 1 — fetch the completed-job list off the GUI thread.  The picker
        # opens from _on_jobs_fetched, so the user can take all of them or any
        # subset before a single byte is downloaded.
        def fetch(worker: Worker):
            client = self._make_client(worker)
            worker.emit_jobs(client.fetch_completed_jobs())

        self._start(fetch)

    def _on_jobs_fetched(self, jobs):
        # Defer one event-loop pass so the fetch worker's `done` (and the
        # re-enable in _on_worker_done) lands before the modal picker blocks.
        QTimer.singleShot(0, lambda: self._choose_existing(jobs))

    def _choose_existing(self, jobs):
        if not jobs:
            QMessageBox.information(self, "Download existing",
                                    "No completed jobs found on the portal.")
            self.statusBar().showMessage("No completed jobs")
            return

        ids = [str(j.get("id")) for j in jobs]
        labels = {str(j.get("id")): job_display(j) for j in jobs}
        picked = SelectAllDialog.ask(
            self, "Download existing — choose jobs", ids,
            selected=list(ids), columns=1, labels=labels)
        if picked is None:                       # Cancel pressed
            self.statusBar().showMessage("Cancelled")
            return
        chosen = [j for j in jobs if str(j.get("id")) in set(picked)]
        if not chosen:
            self.statusBar().showMessage("No jobs selected")
            self._log("No jobs selected — nothing to download.", "warn")
            return

        out = (self.existing_edit.text().strip()
               or str(self._default_dl_dir() / "existing"))
        self._log(f"Downloading {len(chosen)} of {len(jobs)} completed job(s):")
        for j in chosen:
            self._log("  " + job_display(j))

        def job(worker: Worker):
            client = self._make_client(worker)
            res = client.download_existing(out, jobs=chosen)
            worker.emit_log("-" * 46)
            worker.emit_log(
                f" SUMMARY - found {res['submitted']}  "
                f"downloaded {res['downloaded']}  failed {res['failed']}",
                "ok" if not res["failed"] else "warn")
            worker.emit_status("Done" if not res["failed"] else "Finished with errors")

        self._start(job)

    def _stop_clicked(self):
        if self._worker and self._worker.isRunning() and self._stop:
            self._stop.set()
            self.statusBar().showMessage("Stopping...")
            self._log("\nStop requested — finishing current step...", "warn")

    def closeEvent(self, event):
        if self._worker and self._worker.isRunning():
            if QMessageBox.question(
                    self, "Quit", "A job is still running.\nStop it and quit?") != \
                    QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            if self._stop:
                self._stop.set()
            self._worker.wait(5000)
        event.accept()


def _escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def main():
    if getattr(sys, "frozen", False):
        sys.path.insert(0, str(Path(sys.executable).resolve().parent))
    app = QApplication(sys.argv)
    app.setApplicationName("NCMRWF RDS Downloader")
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()