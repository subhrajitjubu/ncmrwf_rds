#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rds_themes.py — shared UI palette + font-scale tables.

Both front-ends (rds_gui_tk.py and rds_gui_qt.py) import from here so that a
theme or a font role is defined exactly once. Duplicating the table into two
GUI files guarantees the two builds drift apart the first time either changes.
See UI-WORKLOG.md D-21.

Nothing in this module imports tkinter or Qt, so it stays importable by tests
and by any future front-end without pulling in a GUI toolkit.
"""

from __future__ import annotations

import sys

# ── brand colours (used as theme accents) ───────────────────
TEAL = "#01696f"
TEAL_DARK = "#0a5a60"
PLUM = "#8b2268"
SLATE = "#006494"

TAG_COLORS_LIGHT = {"ok": "#3f7d20", "warn": "#a06d00",
                    "error": "#b3261e", "info": "#1f2328"}
TAG_COLORS_DARK = {"ok": "#8fce6a", "warn": "#e8af34",
                   "error": "#f08a84", "info": "#cdccca"}


# ═════════════════════════════════════════════════════════════
#  FONT SCALE
#
#  Every font in the app is declared as a ROLE with a base point size, then
#  scaled. Hard-coding sizes per widget means "make text bigger" turns into a
#  dozen scattered edits that drift apart. See UI-WORKLOG.md D-13.
# ═════════════════════════════════════════════════════════════
FONT_ROLES = {
    "sub": 8,          # app subtitle
    "hint": 8,         # caption / status hints
    "status": 9,       # bottom status bar
    "frame_label": 9,  # LabelFrame / QGroupBox titles
    "tool": 8,         # small tool buttons
    "action": 10,      # Submit / Stop
    "body": 9,         # default body text & dialogs
    "cal_title": 9,    # "Jan 2005"
    "cal_head": 8,     # Mo Tu We ... (was 7 -- too small next to cal_day)
    "cal_day": 8,      # day numbers
    "log": 9,          # job log (monospace)
    "preview": 8,      # request preview (monospace)
}

# Named steps, so the user can pick a comfortable size instead of us guessing.
FONT_STEPS = {"Small": 0.85, "Normal": 1.0, "Large": 1.2, "X-Large": 1.45}
DEFAULT_FONT_STEP = "Large"

# Font families differ by platform: these names exist on a stock install of
# each OS.  Tk/Qt silently substitute a default when a family is missing, which
# makes the UI look wrong rather than fail, so pick the real name per platform.
if sys.platform.startswith("win"):
    MONO_FAMILY = "Consolas"
    SANS_FAMILY = "Segoe UI"
elif sys.platform == "darwin":
    MONO_FAMILY = "Menlo"
    SANS_FAMILY = "Helvetica Neue"
else:
    MONO_FAMILY = "DejaVu Sans Mono"
    SANS_FAMILY = "DejaVu Sans"


def scaled(role: str, scale: float, minimum: int = 6) -> int:
    """Point size for a role at a given scale, floored so it stays legible."""
    return max(minimum, int(round(FONT_ROLES[role] * scale)))


# ═════════════════════════════════════════════════════════════
#  THEMES
#
#  Every colour the UI paints with lives in one palette dict, so adding a
#  theme means adding data rather than editing paint code. See UI-WORKLOG.md
#  D-09. Keys are consumed by both front-ends' apply-theme routines.
# ═════════════════════════════════════════════════════════════
THEMES = {
    "Light": dict(
        dark=False,
        bg="#f8f9fa", card="#ffffff", fg="#212529", muted="#6c757d",
        line="#e9ecef", accent=TEAL, accent_fg="#ffffff",
        stop=PLUM, exist=SLATE, disabled="#adb5bd",
        log_bg="#1e1e1e", log_fg="#d4d4d4", log_line="#e9ecef",
        pv_bg="#ffffff", pv_fg="#212529", pv_key=TEAL, pv_muted="#6c757d",
        tags=dict(TAG_COLORS_LIGHT),
        cal=dict(bg_out="#f8f9fa", bg_norm="#ffffff", bg_in="#cfe6e8",
                 fg_norm="#212529", fg_in="#ffffff", fg_edge=TEAL,
                 today_bg="#e9ecef"),
    ),
    "Dark": dict(
        dark=True,
        bg="#1a1a1a", card="#252525", fg="#e0e0e0", muted="#8a8a8a",
        line="#2d2d2d", accent="#4f98a3", accent_fg="#ffffff",
        stop="#a8367c", exist="#2a7fa8", disabled="#4a4a4a",
        log_bg="#0a0a0a", log_fg="#d4d4d4", log_line="#2d2d2d",
        pv_bg="#141414", pv_fg="#e0e0e0", pv_key="#4f98a3", pv_muted="#8a8a8a",
        tags=dict(TAG_COLORS_DARK),
        cal=dict(bg_out="#1a1a1a", bg_norm="#252525", bg_in="#0c4e54",
                 fg_norm="#e0e0e0", fg_in="#ffffff", fg_edge="#4f98a3",
                 today_bg="#3a3a3a"),
    ),
    "Midnight": dict(
        dark=True,
        bg="#0b1220", card="#111b2e", fg="#d7e0f0", muted="#7f8ea8",
        line="#1d2a42", accent="#4c8bf5", accent_fg="#ffffff",
        stop="#7b5bd6", exist="#2d7fb8", disabled="#33415c",
        log_bg="#070d18", log_fg="#c8d4e8", log_line="#1d2a42",
        pv_bg="#080e1a", pv_fg="#d7e0f0", pv_key="#4c8bf5", pv_muted="#7f8ea8",
        tags=dict(ok="#5ed17a", warn="#f0b849", error="#ff7b72", info="#c8d4e8"),
        cal=dict(bg_out="#0b1220", bg_norm="#111b2e", bg_in="#1b3a63",
                 fg_norm="#d7e0f0", fg_in="#ffffff", fg_edge="#4c8bf5",
                 today_bg="#1a2540"),
    ),
    "Solarized": dict(
        dark=False,
        bg="#fdf6e3", card="#f4ecd8", fg="#586e75", muted="#5f7373",
        line="#eee8d5", accent="#268bd2", accent_fg="#fdf6e3",
        stop="#d33682", exist="#2aa198", disabled="#b5ab91",
        log_bg="#002b36", log_fg="#93a1a1", log_line="#eee8d5",
        pv_bg="#f4ecd8", pv_fg="#586e75", pv_key="#268bd2", pv_muted="#5f7373",
        tags=dict(ok="#859900", warn="#b58900", error="#dc322f", info="#586e75"),
        cal=dict(bg_out="#fdf6e3", bg_norm="#f4ecd8", bg_in="#b8d4e8",
                 fg_norm="#586e75", fg_in="#002b36", fg_edge="#268bd2",
                 today_bg="#eee8d5"),
    ),
    "Amber": dict(
        dark=True,
        bg="#161009", card="#1f1810", fg="#ffc46b", muted="#a37c47",
        line="#2e2314", accent="#e09b2d", accent_fg="#161009",
        stop="#c46b3c", exist="#b0813a", disabled="#4a3a20",
        log_bg="#0d0906", log_fg="#ffb84d", log_line="#2e2314",
        pv_bg="#0d0906", pv_fg="#ffc46b", pv_key="#e09b2d", pv_muted="#a37c47",
        tags=dict(ok="#9fbf5a", warn="#ffd166", error="#e8703a", info="#ffc46b"),
        cal=dict(bg_out="#161009", bg_norm="#1f1810", bg_in="#4a3410",
                 fg_norm="#ffc46b", fg_in="#161009", fg_edge="#e09b2d",
                 today_bg="#2a2013"),
    ),
    "Ocean": dict(
        dark=False,
        bg="#eef5fa", card="#ffffff", fg="#123047", muted="#4a6b82",
        line="#d6e6f0", accent="#0b6fa4", accent_fg="#ffffff",
        stop="#9c3d78", exist="#0f8b8d", disabled="#a9bcc9",
        log_bg="#0d2a3a", log_fg="#bfe3f2", log_line="#d6e6f0",
        pv_bg="#f7fbfe", pv_fg="#123047", pv_key="#0b6fa4", pv_muted="#5b7c94",
        tags=dict(ok="#2f7d4f", warn="#9c6b12", error="#b3261e", info="#123047"),
        cal=dict(bg_out="#eef5fa", bg_norm="#ffffff", bg_in="#bfe0f2",
                 fg_norm="#123047", fg_in="#ffffff", fg_edge="#0b6fa4",
                 today_bg="#dcebf4"),
    ),
    "High Contrast": dict(
        dark=True,
        bg="#000000", card="#000000", fg="#ffffff", muted="#e0e0e0",
        line="#ffffff", accent="#ffd400", accent_fg="#000000",
        stop="#ff5c5c", exist="#5cc8ff", disabled="#666666",
        log_bg="#000000", log_fg="#ffffff", log_line="#ffffff",
        pv_bg="#000000", pv_fg="#ffffff", pv_key="#ffd400", pv_muted="#e0e0e0",
        tags=dict(ok="#5cff5c", warn="#ffd400", error="#ff5c5c", info="#ffffff"),
        cal=dict(bg_out="#000000", bg_norm="#000000", bg_in="#333300",
                 fg_norm="#ffffff", fg_in="#ffffff", fg_edge="#ffd400",
                 today_bg="#222222"),
    ),
}


# ═════════════════════════════════════════════════════════════
#  IMPORTED THEMES  (source tokens are verbatim, the rest are derived)
#
#  Palette values for the eight themes below are copied EXACTLY from the
#  opencode `replit-deck` design reference, which states they were sampled
#  from source PNGs -- so they are transcribed, not guessed. Only the tokens
#  that source actually specifies are stated; everything the app also needs
#  (card, log, preview, tags, calendar) is computed by _theme() from the
#  six real tokens. See UI-WORKLOG.md D-20.
#
#  The `theme-factory` skill advertises ten themes but ships no palette
#  assets (a SKILL.md stub pointing at an upstream GitHub repo), and
#  `research-presentation` themes are deck frames rather than app palettes.
#  `replit-deck` is the only reference here carrying usable token sets.
# ═════════════════════════════════════════════════════════════
def _mix(hx: str, target: str, amt: float) -> str:
    """Blend hex colour hx toward target by amt (0..1)."""
    out = []
    for i in (1, 3, 5):
        a, b = int(hx[i:i + 2], 16), int(target[i:i + 2], 16)
        out.append(round(a + (b - a) * amt))
    return "#%02x%02x%02x" % tuple(out)


def _luma(hx: str) -> float:
    r, g, b = (int(hx[i:i + 2], 16) / 255 for i in (1, 3, 5))
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def _contrast(a: str, b: str) -> float:
    la, lb = _luma(a), _luma(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def _ensure_contrast(color: str, bg: str, target: float = 4.5,
                     steps: int = 24) -> str:
    """Nudge `color` toward black or white until it clears `target` on `bg`.

    Used for TYPE colours only. An imported palette keeps its verbatim accent
    wherever the accent is a fill or marker; only the variant used as label
    text is adjusted, because e.g. World Mint's source yellow is 1.3:1 on its
    light mint surface and would be unreadable as type.
    """
    if _contrast(color, bg) >= target:
        return color
    toward = "#000000" if _luma(bg) > 0.5 else "#ffffff"
    out = color
    for i in range(1, steps + 1):
        out = _mix(color, toward, i / steps)
        if _contrast(out, bg) >= target:
            return out
    return out


def _theme(bg, fg, muted, line, accent, *, dark, accent_fg=None,
           stop=None, exist=None, tags=None, sel=None):
    """Build a full app palette from a source theme's core tokens."""
    toward = "#ffffff" if dark else "#000000"
    card = _mix(bg, toward, 0.08 if dark else 0.04)
    accent_fg = accent_fg or (bg if _luma(accent) > 0.45 else "#ffffff")
    # accent stays verbatim; accent_text is the readable-on-bg variant
    accent_text = _ensure_contrast(accent, bg)
    muted = _ensure_contrast(muted, bg)
    stop = stop or (accent if dark else "#b3261e")
    exist = exist or (accent if dark else "#0b6fa4")
    disabled = _mix(bg, toward, 0.35)
    # A log should read as a terminal, not a tint of the page. 0.55 toward
    # black left imported light themes (Helix #fafafa) with a mid-grey panel
    # that is AA-legal but looks like an unstyled box; 0.78 lands dark enough
    # to read as a log in every case.
    log_bg = _mix(bg, "#000000", 0.78 if not dark else 0.55)
    log_fg = _ensure_contrast(_mix(fg, log_bg, 0.20), log_bg)
    pv_bg = card
    sel_bg = sel or _mix(bg, accent, 0.28)
    sel_fg = "#ffffff" if dark else _mix(bg, "#000000", 0.65)
    return dict(
        dark=dark, bg=bg, card=card, fg=fg, muted=muted, line=line,
        accent=accent, accent_text=accent_text, accent_fg=accent_fg,
        stop=stop, exist=exist, disabled=disabled,
        log_bg=log_bg, log_fg=log_fg, log_line=line,
        pv_bg=pv_bg, pv_fg=fg, pv_key=accent_text, pv_muted=muted,
        tags=tags or dict(ok="#3f7d20", warn="#a06d00",
                          error="#b3261e", info=muted),
        cal=dict(bg_out=bg, bg_norm=card, bg_in=sel_bg, fg_norm=fg,
                 fg_in=sel_fg, fg_edge=accent_text,
                 today_bg=_mix(bg, toward, 0.10 if dark else 0.07)),
    )


THEMES.update({
    # helix — modern minimal (replit-deck)
    "Helix": _theme("#fafafa", "#19191c", "#6e6e73", "#e4e4e7", "#5889fe",
                    dark=False, accent_fg="#ffffff", stop="#e5484d",
                    exist="#30a46c",
                    tags=dict(ok="#30a46c", warn="#f5a524",
                              error="#e5484d", info="#6e6e73")),
    # holm — editorial serif memo (replit-deck); muted darkened to clear AA
    "Holm": _theme("#e4dfd7", "#0f0f0e", "#5f6167", "#c7c1b7", "#52311d",
                   dark=False, accent_fg="#f4efe8", stop="#8b2f2f",
                   exist="#3f5c40", sel="#d9c9b8",
                   tags=dict(ok="#3f5c40", warn="#8a6410",
                             error="#8b2f2f", info="#5f6167")),
    # vance — gallery catalog (replit-deck); source has no chromatic accent
    "Vance": _theme("#f1ede2", "#171815", "#63625c", "#d5cfc0", "#171815",
                    dark=False, accent_fg="#faf7ef", stop="#8c2f2f",
                    exist="#3a5a40", sel="#d9d3c4",
                    tags=dict(ok="#3a5a40", warn="#8a6410",
                              error="#8c2f2f", info="#63625c")),
    # bevel — Y2K editorial (replit-deck)
    "Bevel": _theme("#0d0d0b", "#eae6dd", "#a29e95", "#2a2a28", "#c8ff00",
                    dark=True, accent_fg="#0d0d0b", stop="#e34b4b",
                    exist="#4da3ff", sel="#2f3f10",
                    tags=dict(ok="#c8ff00", warn="#ffd166",
                              error="#ff6b6b", info="#eae6dd")),
    # world-dark — finance dark (replit-deck)
    "World Dark": _theme("#0d3a2b", "#bcd6cd", "#789f91", "#1d4c3c", "#e8f615",
                         dark=True, accent_fg="#0d3a2b", stop="#e0663f",
                         exist="#4bb3a0", sel="#35440f",
                         tags=dict(ok="#e8f615", warn="#f0b849",
                                   error="#ef7a5a", info="#bcd6cd")),
    # world-mint — finance light, sibling of world-dark (replit-deck)
    "World Mint": _theme("#bcd6cd", "#0d3a2b", "#4f7668", "#8fafa3", "#e8f615",
                         dark=False, accent_fg="#0d3a2b", stop="#a8452a",
                         exist="#1f6d5c", sel="#d9e85a",
                         tags=dict(ok="#3f7d20", warn="#8a6410",
                                   error="#a8452a", info="#4f7668")),
    # atlas — museum chapter (replit-deck)
    "Atlas": _theme("#111010", "#e7e6e2", "#827d78", "#2a2826", "#de3f40",
                    dark=True, accent_fg="#ffffff", stop="#de3f40",
                    exist="#b8912f", sel="#4a1616",
                    tags=dict(ok="#7aa05c", warn="#c9a227",
                              error="#de3f40", info="#e7e6e2")),
    # bluehouse — consumer card (replit-deck)
    "Bluehouse": _theme("#0b1524", "#ffffff", "#8ea0b8", "#1a2c46", "#fb675d",
                        dark=True, accent_fg="#0b1524", stop="#e8503f",
                        exist="#4a9dd6", sel="#4a2233",
                        tags=dict(ok="#3ecf8e", warn="#ffb45c",
                                  error="#fb675d", info="#dce8f5")),
})

DEFAULT_THEME = "Light"

# The seven hand-built themes first, then the eight imported ones, so the
# picker shows familiar options before the more opinionated palettes.
THEME_ORDER = [
    "Light", "Dark", "Midnight", "Solarized", "Amber", "Ocean", "High Contrast",
    "Helix", "Holm", "Vance", "Bevel", "World Dark", "World Mint",
    "Atlas", "Bluehouse",
]

assert set(THEME_ORDER) == set(THEMES), "THEME_ORDER is out of sync with THEMES"


def palette(theme) -> dict:
    """A palette with every key the front-ends index filled in.

    Accepts a theme name or a palette dict. The seven hand-built themes
    predate `accent_text`; only _theme() derives it. Indexing that key
    directly on a hand-built theme raises KeyError, and a
    `.get(key, fallback)` at each call site is exactly the drift this module
    exists to prevent -- so normalise once, here.
    """
    t = theme if isinstance(theme, dict) else (
        THEMES.get(theme) or THEMES[DEFAULT_THEME])
    if "accent_text" not in t:
        t = dict(t, accent_text=_ensure_contrast(t["accent"], t["bg"]))
    return t
