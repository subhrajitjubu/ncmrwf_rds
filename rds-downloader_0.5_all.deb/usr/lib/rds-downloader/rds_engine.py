#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rds_engine.py — NCMRWF RDS download engine (pure Python, cross-platform)

Python port of rds_client.sh + rds_config.sh. No bash / curl / jq required.
Used by rds_gui_tk.py and rds_gui_qt.py.

The dataset tables below were verified directly against the live API
(`/api/openapi.json` and `/api/datasets/{slug}`) AND confirmed with real
submitted jobs.  See README.md for the test matrix.

IMPORTANT — the API's own `download_config` publishes DISPLAY values that the
server processor does NOT accept.  Verified by submitting jobs:

  | field            | published display | WORKS            | FAILS          |
  |------------------|-------------------|------------------|----------------|
  | time             | "00:00"           | "00"             | "00:00"        |
  | pressure_level   | "500 hPa"         | "500_hpa"        | "500 hPa","500"|
  | forecast_day     | "T+1"             | "day01"          | "day1"         |
  | initialization_day| ["01","09",..]   | "01" (plain str) | ["01"] (422)   |

Fixes carried over from the shell version:
  * No top-level "job_type" in the POST body — the API forbids extra fields.
  * VAR groups are scoped PER DATASET, so APCP-sfc maps to daily_sum on
    imdaa-daily but rain_and_snow on imdaa-hourly-single.
  * Downloads are size-validated (>4 KB) so a server error JSON is never
    renamed into the target .zip and reported as a success.
"""

from __future__ import annotations

import base64
import configparser
import json
import os
import re
import subprocess
import threading
import time
from datetime import date, timedelta
from pathlib import Path

try:
    import requests
except ImportError:  # pragma: no cover
    raise SystemExit("The 'requests' package is required.  pip install requests")


# ─────────────────────────────────────────────────────────────
#  API CONSTANTS
# ─────────────────────────────────────────────────────────────
RDS_BASE_URL = "https://rds.ncmrwf.gov.in"
RDS_EXT_NAME = "ojplmecpdpgccookcobabopnaifgidhf"
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36")

DEFAULT_POLL_INTERVAL = 60
DEFAULT_MAX_WAIT = 7200
MIN_PLAUSIBLE_ZIP = 4096

# A real portal archive is a ZIP, so it begins with one of these signatures:
# a normal local file header, an empty archive, or a spanned marker.
ZIP_MAGICS = (b"PK\x03\x04", b"PK\x05\x06", b"PK\x07\x08")

# Ceiling on a single download.  TLS verification is off by default (see
# tls_verify_enabled), so a hostile or intercepted server can stream as much as
# it likes; without a cap that is a disk-fill denial of service.  Far above any
# real archive this tool produces; override with RDS_MAX_DOWNLOAD_MB (0 = off)
# if a legitimate archive is ever larger.
DEFAULT_MAX_DOWNLOAD_MB = 8192

# A job id from the API is a UUID.  Anything else is refused before it reaches
# a URL or a filename.
_JOB_ID_RE = re.compile(r"[A-Za-z0-9_-]{1,128}\Z")

ALL_MONTHS = [f"{m:02d}" for m in range(1, 13)]
ALL_DAYS = [f"{d:02d}" for d in range(1, 32)]


# ─────────────────────────────────────────────────────────────
#  VARIABLE GROUPS  (payload field -> allowed values)
#
#  Exactly what the API publishes for each dataset.  The key IS the JSON
#  field name sent inside request_payload.
# ─────────────────────────────────────────────────────────────
GROUPS: dict[str, dict[str, list[str]]] = {
    "ngfs-daily-single": {
        "daily_mean":    ["Tmean"],
        "daily_maximum": ["Tmax"],
        "daily_minimum": ["Tmin"],
    },
    "ngfs-hourly-single": {
        "soil": ["TSOIL-L1", "TSOIL-L2", "TSOIL-L3", "TSOIL-L4"],
        "wind": ["GUST-sfc", "UGRD-10m-agl", "VGRD-10m-agl"],
        "temperature_and_pressure":
            ["TMP-sfc", "PRES-sfc", "TMP-2m-agl", "PRMSL-msl"],
        "others": ["RH-2m-agl", "VIS-sfc", "LAND-sfc", "HPBL-sfc",
                   "ICEC-sfc", "ICETK-sfc", "WEASD-sfc"],
    },
    "ngfs-hourly-pressure": {
        "variables": ["UGRD-prl", "VGRD-prl", "TMP-prl", "HGT-prl", "RH-prl"],
    },
    "imdaa-daily-single": {
        "daily_sum":     ["APCP-sfc"],
        "daily_mean":    ["Tmean", "T2m_mean"],
        "daily_maximum": ["Tmax", "T2m_max"],
        "daily_minimum": ["Tmin", "T2m_min"],
    },
    "imdaa-hourly-single": {
        "soil": ["TSOIL-L1", "TSOIL-L2", "TSOIL-L3", "TSOIL-L4",
                 "CISOILM-L1", "CISOILM-L2", "CISOILM-L3", "CISOILM-L4"],
        "wind": ["GUST-10m", "UGRD-10m", "VGRD-50m", "UGRD-50m", "VGRD-50m"],
        "cloud": ["LCDC-atmc", "HCDC-atmc", "VLCDC-atmc", "MCDC-atmc",
                  "TCDCRO-atmc"],
        "rain_and_snow": ["APCP-sfc", "SNOC-sfc", "SNOL-sfc", "WEASD-sfc",
                          "CWP-sfc", "LSWP-sfc"],
        "radiation_and_heat": ["DSWRF-toa", "ULWRF-toa", "NLWRF-sfc",
                               "DLWRF-sfc", "NSWRF-sfc", "DSWRF-sfc",
                               "LHTFL-sfc", "SHTFL-sfc", "NSWRF-toa"],
        "temperature_and_pressure":
            ["TMP-sfc", "PRES-sfc", "TMP-2m", "PRMSL-msl"],
        "others": ["RH-2m", "VIS-2m", "LAND-sfc", "EVARCA-sfc",
                   "EVARSS-sfc", "HPBL-sfc", "ICEC-sfc", "ICETK-sfc",
                   "ROHLENABL-sfc"],
    },
    "imdaa-hourly-pressure": {
        "variables": ["UGRD-prl", "VGRD-prl", "TMP-prl", "HGT-prl", "RH-prl"],
    },
    "s2s-daily": {
        "instantaneous": ["UGRD-prl", "VGRD-prl", "TMP-prl", "HGT-prl",
                          "SPH-prl", "UGRD-10m", "VGRD-10m", "PRMSL-msl",
                          "PRES-sfc", "MTERH-sfc", "LAND-sfc"],
        "accumulated": ["APCP-sfc"],
        "averaged": ["DSWRF-sfc", "NLWRF-sfc", "LHTFL-sfc"],
    },
    "ocean-data": {
        "variables": ["SST-sfc", "SSS-sfc", "SSH-sfc", "MLD-sfc"],
    },
    "mera": {
        "variables": ["APCP-sfc"],
    },
}

# All 11 S2S instantaneous variables were verified working with real jobs.
# An earlier revision wrongly assumed the "*-prl" subset was a server-side
# fault; it was actually this client's bug (see _S2S_PRL below).


# ─────────────────────────────────────────────────────────────
#  DATASET DEFINITIONS
# ─────────────────────────────────────────────────────────────
_NGFS_PRL = [f"{p}_hpa" for p in (
    "1 2 3 5 7 10 20 30 50 70 100 125 150 175 200 225 250 275 300 325 350 375 "
    "400 425 450 475 500 525 550 575 600 625 650 675 700 725 750 775 800 825 "
    "850 875 900 925 950 975 1000").split()]

_IMDAA_PRL = [f"{p}_hpa" for p in (
    "10 20 30 50 70 100 150 200 250 300 400 500 600 700 800 850 925 950 1000"
).split()]

# S2S is the odd one out: its pressure levels are BARE numbers ("500"), not the
# "500_hpa" form the NGFS/IMDAA pressure datasets use. Verified against the
# live API -- "500" completes, "500_hpa" fails with "Unknown processing error".
_S2S_PRL = "10 30 50 100 200 300 400 500 700 850 925".split()


DATASETS: dict[str, dict] = {
    "ngfs-daily-single": {
        "label": "NGFS Daily Single Levels (1999-2018)",
        "type": "ngfsdaily",
        "referer": f"{RDS_BASE_URL}/datasets/ngfs-daily?tab=download",
        "years": range(1999, 2019),
        "time": None, "pressure": None, "day": True,
        "forecast": None,
        "bbox": {"north": 45, "south": -15, "east": 120, "west": 30},
    },
    "ngfs-hourly-single": {
        "label": "NGFS 6-Hourly Single Levels (1999-2018)",
        "type": "ngfs2df",
        "referer": f"{RDS_BASE_URL}/datasets/hourly-single-levels-ngfs?tab=download",
        "years": range(1999, 2019),
        "time": ["00", "06", "12", "18"], "pressure": None, "day": True,
        "forecast": None,
        "bbox": {"north": 45, "south": -15, "east": 120, "west": 30},
    },
    "ngfs-hourly-pressure": {
        "label": "NGFS 6-Hourly Pressure Levels (1999-2018)",
        "type": "ngfsprl",
        "referer": f"{RDS_BASE_URL}/datasets/hourly-pressure-ngfs?tab=download",
        "years": range(1999, 2019),
        "time": ["00", "06", "12", "18"],
        "pressure": _NGFS_PRL, "day": True, "forecast": None,
        "bbox": {"north": 45, "south": -15, "east": 120, "west": 30},
    },
    "imdaa-daily-single": {
        "label": "IMDAA Daily Single Level (1979-2020)",
        "type": "daily",
        "referer": f"{RDS_BASE_URL}/datasets/imdaa-daily?tab=download",
        "years": range(1979, 2021),
        "time": None, "pressure": None, "day": True, "forecast": None,
        "bbox": {"north": 45, "south": -15, "east": 120, "west": 30},
    },
    "imdaa-hourly-single": {
        "label": "IMDAA Hourly Single Levels (1979-2022)",
        "type": "2df",
        "referer": f"{RDS_BASE_URL}/datasets/hourly-single-levels?tab=download",
        "years": range(1979, 2023),
        "time": [f"{h:02d}" for h in range(24)],
        "pressure": None, "day": True, "forecast": None,
        "bbox": {"north": 45, "south": -15, "east": 120, "west": 30},
    },
    "imdaa-hourly-pressure": {
        "label": "IMDAA 3-Hourly Pressure Levels (1979-2022)",
        "type": "prl",
        "referer": f"{RDS_BASE_URL}/datasets/hourly-pressure?tab=download",
        "years": range(1979, 2023),
        "time": ["00", "03", "06", "09", "12", "15", "18", "21"],
        "pressure": _IMDAA_PRL, "day": True, "forecast": None,
        "bbox": {"north": 45, "south": -15, "east": 120, "west": 30},
    },
    "s2s-daily": {
        "label": "S2S Sub-seasonal Re-forecast (1993-2015)",
        "type": "s2sdaily",
        "referer": f"{RDS_BASE_URL}/datasets/s2s-daily?tab=download",
        "years": range(1993, 2016),
        # no clock time / no day-of-month — S2S selects by forecast lead
        "time": None, "pressure": _S2S_PRL, "day": False,
        "forecast": [f"day{i:02d}" for i in range(0, 37)],
        "init_days": ["01"],
        "bbox": {"north": 90, "south": -90, "east": 180, "west": -180},
    },
    "ocean-data": {
        "label": "NEMO Ocean Analysis (2016-2026)",
        "type": "ocean3hourly",
        "referer": f"{RDS_BASE_URL}/datasets/ocean-data?tab=download",
        "years": range(2016, 2027),
        "time": ["00", "03", "06", "09", "12", "15", "18", "21"],
        "pressure": None, "day": True, "forecast": None,
        # 0-360 longitude convention
        "bbox": {"north": 90, "south": -90, "east": 360, "west": 0},
    },
    "mera": {
        "label": "MERA Hourly Rainfall over India (2020-2025)",
        "type": "merahourly",
        "referer": f"{RDS_BASE_URL}/datasets/mera?tab=download",
        "years": range(2020, 2026),
        "time": [f"{h:02d}" for h in range(24)],
        "pressure": None, "day": True, "forecast": None,
        "bbox": {"north": 37.5, "south": 5.5, "east": 99, "west": 66.5},
    },
}


# ─────────────────────────────────────────────────────────────
#  DERIVED TABLES  (single source of truth for the GUIs)
# ─────────────────────────────────────────────────────────────
def _flatten(groups: dict[str, list[str]]) -> list[str]:
    out: list[str] = []
    for names in groups.values():
        for v in names:
            if v not in out:
                out.append(v)
    return out


VARIABLES_BY_DATASET = {k: _flatten(v) for k, v in GROUPS.items()}
PRESSURE_LEVELS_BY_DATASET = {
    k: v["pressure"] for k, v in DATASETS.items() if v.get("pressure")
}
TIME_ALL = {k: v["time"] for k, v in DATASETS.items() if v.get("time")}
FORECAST_DAYS = {k: v["forecast"] for k, v in DATASETS.items() if v.get("forecast")}
INIT_DAYS = {k: v["init_days"] for k, v in DATASETS.items() if v.get("init_days")}

DS_KEYS = list(DATASETS)

# variable -> payload group, per dataset (no cross-dataset collisions)
VAR_GROUPS = {
    ds: {v: g for g, names in groups.items() for v in names}
    for ds, groups in GROUPS.items()
}


# ─────────────────────────────────────────────────────────────
#  SEASONS
# ─────────────────────────────────────────────────────────────
SEASON_PRESETS = {
    "All year": list(ALL_MONTHS),
    "MAM":      ["03", "04", "05"],
    "JJAS":     ["06", "07", "08", "09"],
    "Oct-Nov":  ["10", "11"],
    "DJF":      ["12", "01", "02"],
    "Summer":   ["05", "06"],
    "Winter":   ["12", "01"],
}


# ─────────────────────────────────────────────────────────────
#  USER CONFIG
# ─────────────────────────────────────────────────────────────
def config_dir() -> Path:
    d = Path.home() / ".ncmrwf_gui"
    d.mkdir(parents=True, exist_ok=True)
    return d


def credentials_path() -> Path:
    return Path.home() / ".ncmrwfapirc"


def read_credentials() -> tuple[str, str]:
    """Read ~/.ncmrwfapirc.

    Accepts an INI with a [credentials] section (written by the GUI) and bare
    'email = ...' / 'password = ...' lines (written by the old shell config).
    """
    p = credentials_path()
    if not p.exists():
        return "", ""
    email = password = ""
    for raw in p.read_text(encoding="utf-8", errors="replace").splitlines():
        line = raw.strip()
        if not line or line[0] in "#;[":
            continue
        if "=" in line:
            key, _, val = line.partition("=")
        elif ":" in line:
            key, _, val = line.partition(":")
        elif " " in line:
            key, _, val = line.partition(" ")
        else:
            continue
        key = key.strip().lower()
        val = val.strip().strip('"').strip("'")
        if key == "email":
            email = val
        elif key in ("password", "passwd", "pass"):
            password = val
    return email, password


def write_credentials(email: str, password: str) -> Path:
    p = credentials_path()
    # Create with 0o600 *before* writing, so the plaintext password is never
    # briefly world-readable on POSIX.
    try:
        fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(f"[credentials]\nemail = {email}\npassword = {password}\n")
    except OSError:
        p.write_text(
            f"[credentials]\nemail = {email}\npassword = {password}\n",
            encoding="utf-8")
    _restrict_to_owner(p)
    return p


def _restrict_to_owner(path: Path) -> None:
    """Best-effort: make a file readable only by the current user.

    On POSIX that is `chmod 600`.  On Windows `os.chmod` only toggles the
    read-only attribute -- it does **not** restrict who may read the file -- so
    the plaintext password in `~/.ncmrwfapirc` would otherwise inherit the
    profile ACL and be readable by any other local account.  `icacls` removes
    inheritance and grants only the current user.  Called with an argument
    list (no shell), so a hostile %USERNAME% cannot inject a command.
    """
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    if os.name != "nt":
        return
    user = (os.environ.get("USERNAME") or "").strip()
    if not user:
        try:
            user = os.getlogin()
        except OSError:
            return
    if not user:
        return
    try:
        subprocess.run(
            ["icacls", str(path), "/inheritance:r", "/grant:r", f"{user}:F"],
            check=False, capture_output=True, timeout=15,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        pass


def tls_verify_enabled() -> bool:
    """Whether to require a CA-trusted TLS certificate.  Default: False.

    Verification is **off** by default because the deployment network performs
    TLS interception, so the RDS certificate does not chain to a CA the OS
    trusts and every request would fail.  The cost is real and worth stating:
    with verification off, the login (your password) and the downloaded archive
    are only as private as the network between you and `rds.ncmrwf.gov.in` --
    anyone able to intercept TLS can read the credentials.  Set the environment
    variable ``RDS_VERIFY_TLS=1`` on a network without interception to require a
    properly-trusted certificate.
    """
    return os.environ.get("RDS_VERIFY_TLS", "").strip().lower() in (
        "1", "true", "yes", "on")


# ─────────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────────
def ds_key(dataset: str) -> str:
    return dataset.replace("-", "_")


def _safe_component(value, limit: int = 64) -> str:
    """Reduce a server-supplied id to a single, safe path component.

    Job ids come back from the API and are used in local filenames (`<id>.part`)
    and download paths.  With TLS verification off (the default) a hostile
    server could return an id containing a path separator; stripping anything
    that is not word-char or hyphen keeps the write inside its directory.
    """
    return re.sub(r"[^\w\-]", "_", str(value))[:limit] or "job"


def validate_job_id(job_id) -> str:
    """Refuse a server-supplied job id that is not a plain identifier.

    The id is interpolated into the download URL
    (``/downloads/<id>/<id>.zip``) and, sanitised, into a local filename.  A
    real id is a UUID, so anything containing a path separator, a query or
    fragment character, whitespace or a scheme is not an id.  With TLS
    verification off by default (F1) a hostile server or an on-path attacker
    controls this value, and an id such as ``../../api/jobs/my`` or ``a?x=1``
    otherwise rewrites the request path.  Raises ValueError.
    """
    s = str(job_id or "").strip()
    if not _JOB_ID_RE.fullmatch(s):
        raise ValueError(
            f"Refusing malformed job id from server: {s[:60]!r}")
    return s


def max_download_bytes() -> int:
    """Ceiling on a single download in bytes; 0 disables the check.

    ``RDS_MAX_DOWNLOAD_MB`` overrides the default (a bare ``0`` or a negative
    value turns the cap off).  Unparseable values fall back to the default
    rather than silently disabling the guard.
    """
    raw = os.environ.get("RDS_MAX_DOWNLOAD_MB", "").strip()
    if raw:
        try:
            mb = int(float(raw))
        except ValueError:
            mb = DEFAULT_MAX_DOWNLOAD_MB
        return 0 if mb <= 0 else mb * 1024 * 1024
    return DEFAULT_MAX_DOWNLOAD_MB * 1024 * 1024


def check_zip_magic(prefix: bytes) -> None:
    """Reject a body that is not a ZIP archive.

    The size check alone only catches a truncated response: a >=4 KB HTML error
    page or a JSON error is otherwise renamed into place and reported as a
    successful download.  Raises RuntimeError.
    """
    if not prefix.startswith(tuple(ZIP_MAGICS)):
        raise RuntimeError(
            "Downloaded file is not a ZIP archive (starts with "
            f"{bytes(prefix[:4])!r}) — server error or blocked request")


def safe_target(download_dir: Path, filename: str) -> Path:
    """Join a user-supplied target filename to download_dir, refusing escape.

    The target template is editable in both GUIs and also lives in the shared
    presets file, so it is not a trusted value: an absolute path or a '..'
    component would otherwise write (or overwrite) a file outside the folder
    the user chose.  Raises ValueError, which both GUIs surface as "Invalid
    request".
    """
    name = str(filename).strip()
    if not name:
        raise ValueError("Empty target filename")
    p = Path(name)
    if p.is_absolute() or p.drive or p.anchor:
        raise ValueError(f"Target filename must be relative: {name!r}")
    root = download_dir.resolve()
    resolved = (download_dir / name).resolve()
    if resolved != root and root not in resolved.parents:
        raise ValueError(
            f"Target filename escapes the download folder: {name!r}")
    return download_dir / name


def validate_target_template(template: str) -> None:
    """Reject a target template that could escape the download folder.

    A cheap pre-flight for the GUIs, which can show a dialog; ``run()`` still
    enforces the same rule per file via ``safe_target`` (defence in depth,
    since the template also arrives from the shared presets file).
    """
    t = (template or "").strip() or "{dataset}_{year}.zip"
    probe = t.replace("{dataset}", "ds").replace("{year}", "2000")
    p = Path(probe)
    if p.is_absolute() or p.drive or p.anchor or ".." in p.parts:
        raise ValueError(
            "Target template must not be an absolute path or contain '..': "
            f"{template!r}")


_JOB_DATE_KEYS = ("created_at", "created", "submitted_at", "updated_at",
                  "updated", "finished_at")


def job_display(job: dict) -> str:
    """One line describing a portal job, for the 'download existing' picker.

    Shared by both GUIs so the two builds list jobs identically.  The API
    guarantees ``id``, ``job_type`` and ``status``; the date-ish and error keys
    vary between deployments, so they are included only when present.  The id
    is shortened because a full UUID is noise when scanning a list.
    """
    jt = str(job.get("job_type") or "job").strip() or "job"
    jid = str(job.get("id") or "")
    bits = [jt, jid[:8] or "\u2014"]
    for key in _JOB_DATE_KEYS:
        when = job.get(key)
        if when:
            bits.append(str(when).replace("T", " ")[:19])
            break
    line = "  \u00b7  ".join(bits)
    err = job.get("last_error")
    if err:
        line += f"   (last error: {str(err)[:40]})"
    return line


def parse_years(spec: str, strict: bool = False) -> list[str]:
    """'2005' -> ['2005'];  '2000,2005' -> [...];  '2000-2005' -> [...]

    With ``strict=True`` every token must be a 4-digit year and the whole spec
    must parse; a bad token raises ValueError.  The GUIs use strict mode for
    the field the user submits, because the raw text otherwise flows into the
    pipe-delimited job log (a value like ``2005|x`` corrupts the schema and can
    make JobLog.update rewrite the wrong row) and into the output filename (a
    value like ``..\\..\\x`` walks out of the chosen folder).  Non-strict mode
    is kept for internal callers that pre-fill a picker from whatever happens
    to be in the box at the time.
    """
    spec = (spec or "").strip()
    if not spec:
        return []
    m = re.fullmatch(r"(\d{4})\s*-\s*(\d{4})", spec)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        if a > b:
            a, b = b, a
        return [str(y) for y in range(a, b + 1)]
    tokens = [t.strip() for t in spec.split(",") if t.strip()]
    if strict:
        bad = [t for t in tokens if not re.fullmatch(r"\d{4}", t)]
        if bad:
            raise ValueError(
                "Years must be 4-digit numbers, comma-separated (e.g. "
                "2005,2007) or a range (2000-2005). Offending value(s): "
                + ", ".join(repr(b) for b in bad[:4]))
    return tokens


def expand_months(value) -> list[str]:
    if not value:
        return list(ALL_MONTHS)
    if isinstance(value, str):
        value = [value]
    vals = list(value)
    if len(vals) == 1 and str(vals[0]).strip().lower() == "all":
        return list(ALL_MONTHS)
    return [str(v).strip() for v in vals if str(v).strip()]


def expand_days(value) -> list[str]:
    if not value:
        return list(ALL_DAYS)
    if isinstance(value, str):
        value = [value]
    vals = list(value)
    if len(vals) == 1 and str(vals[0]).strip().lower() == "all":
        return list(ALL_DAYS)
    return [str(v).strip() for v in vals if str(v).strip()]


def _last_day_of_month(year: int, month: int) -> date:
    nxt = date(year + 1, 1, 1) if month == 12 else date(year, month + 1, 1)
    return nxt - timedelta(days=1)


def dates_to_months_days(start: date, end: date):
    """Contiguous date range -> (month[], day[]).

    The API takes months and days as separate lists and requests their
    cartesian product, so an exact range is not expressible.  The GUIs show
    the resulting sets so what will be fetched is never a surprise.
    """
    if start > end:
        start, end = end, start
    months, days = set(), set()
    cur = start
    while cur <= end:
        months.add(f"{cur.month:02d}")
        days.add(f"{cur.day:02d}")
        cur += timedelta(days=1)
    return sorted(months), sorted(days)


def months_to_dates_anchor(year: int, months: list[str]):
    """First and last calendar day spanned by `months` within `year`."""
    if not months:
        return None, None
    nums = sorted({int(m) for m in months})
    if 12 in nums and 1 in nums and len(nums) < 12:
        early = [m for m in nums if m <= 6]
        return (date(year, 12, 1),
                _last_day_of_month(year + 1, max(early) if early else 1))
    return date(year, nums[0], 1), _last_day_of_month(year, nums[-1])


def human_size(n: int) -> str:
    f = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if f < 1024 or unit == "TB":
            return f"{f:.0f} {unit}" if unit == "B" else f"{f:.1f} {unit}"
        f /= 1024
    return f"{f:.1f} TB"


def group_variables(dataset: str, variables: list[str], warn=None) -> dict:
    """Sort a flat variable list into the payload's per-group arrays."""
    table = VAR_GROUPS.get(dataset, {})
    buckets: dict[str, list[str]] = {}
    for var in variables:
        grp = table.get(var)
        if grp is None:
            if warn:
                warn(f"Unknown variable '{var}' for {dataset} — skipping")
            continue
        buckets.setdefault(grp, []).append(var)
    return buckets


# ─────────────────────────────────────────────────────────────
#  PAYLOAD BUILDER
# ─────────────────────────────────────────────────────────────
def build_payload(dataset: str, year: str, months, days, times, bbox,
                  variables, pressure_levels, init_day=None, forecast_days=None,
                  warn=None):
    """Return (label, payload).

    POST /api/jobs validates against a Pydantic model `JobCreateRequest` whose
    only property is `request_payload` — extra fields are forbidden, which is
    why there is no top-level "job_type" here (and no longer in rds_client.sh).
    """
    cfg = DATASETS.get(dataset)
    if cfg is None:
        raise ValueError(f"Unknown dataset '{dataset}'")

    months_e = expand_months(months)
    days_e = expand_days(days)
    times_e = [str(t).strip() for t in (times or []) if str(t).strip()]

    month_label = "_".join(months_e) if len(months_e) < 12 else "all"
    label = f"{cfg['type']}_{year}_{month_label}"

    rp: dict = {
        "dataset_type": cfg["type"],
        "year": str(year),
        "month": months_e,
    }

    # S2S selects by forecast lead and initialisation date, not clock time.
    if cfg.get("forecast"):
        rp["initialization_day"] = str(
            init_day or (cfg.get("init_days") or ["01"])[0])
        fd = [str(d) for d in (forecast_days or []) if str(d).strip()]
        if fd:
            rp["forecast_day"] = fd
    else:
        if cfg.get("day"):
            rp["day"] = days_e
        if times_e:
            rp["time"] = times_e

    rp["data_format"] = ["netcdf4_experimental"]
    rp["download_format"] = ["zip"]
    rp["area"] = {
        "north": bbox.get("north", cfg["bbox"]["north"]),
        "south": bbox.get("south", cfg["bbox"]["south"]),
        "east":  bbox.get("east",  cfg["bbox"]["east"]),
        "west":  bbox.get("west",  cfg["bbox"]["west"]),
    }

    extras = group_variables(dataset, variables, warn=warn)
    if pressure_levels and cfg.get("pressure"):
        extras["pressure_level"] = [str(p) for p in pressure_levels]
    rp.update(extras)

    return label, {"request_payload": rp}


# ─────────────────────────────────────────────────────────────
#  JOB LOG  (same pipe-delimited schema as logs/submitted_jobs.log)
# ─────────────────────────────────────────────────────────────
JOB_LOG_HEADER = "job_id|dataset_key|job_type_label|year|status|target_file"


class JobLog:
    def __init__(self, path: Path | None = None):
        self.path = path or (config_dir() / "submitted_jobs.log")

    def ensure(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self.path.write_text(JOB_LOG_HEADER + "\n", encoding="utf-8")

    def add(self, job_id, dataset, label, year, status, target):
        self.ensure()
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(f"{job_id}|{dataset}|{label}|{year}|{status}|{target}\n")

    def update(self, job_id, status):
        if not self.path.exists():
            return
        out = []
        for i, line in enumerate(self.path.read_text(
                "utf-8", errors="replace").splitlines()):
            parts = line.split("|")
            if i > 0 and line.strip() and parts[0] == job_id and len(parts) >= 5:
                parts[4] = status
                out.append("|".join(parts))
            else:
                out.append(line)
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text("\n".join(out) + "\n", encoding="utf-8")
        tmp.replace(self.path)

    def rows(self) -> list[dict]:
        if not self.path.exists():
            return []
        rows = []
        for line in self.path.read_text(
                "utf-8", errors="replace").splitlines()[1:]:
            p = line.split("|")
            if len(p) >= 6 and line.strip():
                rows.append({"job_id": p[0], "dataset": p[1], "label": p[2],
                             "year": p[3], "status": p[4], "target": p[5]})
        return rows


# ─────────────────────────────────────────────────────────────
#  CLIENT
# ─────────────────────────────────────────────────────────────
class AuthError(RuntimeError):
    pass


class RDSClient:
    def __init__(self, email: str, password: str, log=None,
                 poll_interval: int = DEFAULT_POLL_INTERVAL,
                 max_wait: int = DEFAULT_MAX_WAIT,
                 job_log: JobLog | None = None,
                 stop_event: threading.Event | None = None):
        self.email = email
        self.password = password
        self.log = log or (lambda msg, level="info": None)
        self.poll_interval = poll_interval
        self.max_wait = max_wait
        self.job_log = job_log or JobLog()
        self.stop_event = stop_event or threading.Event()

        self.token: str | None = None
        self.session = requests.Session()
        # Mirrors `curl -k`: the deployment network intercepts TLS, so a
        # CA-trusted certificate is not available by default.  Opt in with
        # RDS_VERIFY_TLS=1 on a clean network -- see tls_verify_enabled().
        self.session.verify = tls_verify_enabled()
        if self.session.verify:
            self.log("TLS certificate verification: ON", "ok")
        else:
            self.log("TLS certificate verification is OFF — credentials are "
                     "only as private as the network path to "
                     f"{RDS_BASE_URL} (set RDS_VERIFY_TLS=1 to require a "
                     "trusted certificate)", "warn")
            try:
                import urllib3
                urllib3.disable_warnings(
                    urllib3.exceptions.InsecureRequestWarning)
            except Exception:
                pass

    # ── low level ──────────────────────────────────────────
    def _headers(self, referer=None, json_body=False):
        h = {"Accept": "application/json, text/plain, */*",
             "Cache-Control": "no-cache", "User-Agent": USER_AGENT}
        if json_body:
            h["Content-Type"] = "application/json"
            h["Origin"] = RDS_BASE_URL
        if referer:
            h["Referer"] = referer
        c = f"ext_name={RDS_EXT_NAME}"
        if self.token:
            c += f"; access_token={self.token}"
        h["Cookie"] = c
        return h

    def _url(self, path: str) -> str:
        return path if path.startswith("http") else f"{RDS_BASE_URL}{path}"

    def _should_stop(self) -> bool:
        return self.stop_event.is_set()

    # ── auth ───────────────────────────────────────────────
    @staticmethod
    def _token_expiry(token: str) -> int:
        try:
            p = token.split(".")[1]
            p += "=" * (-len(p) % 4)
            return int(json.loads(
                base64.urlsafe_b64decode(p).decode("utf-8")).get("exp", 0))
        except Exception:
            return 0

    def token_valid(self) -> bool:
        if not self.token:
            return False
        exp = self._token_expiry(self.token)
        if exp <= 0:
            return False
        remaining = exp - int(time.time())
        if remaining > 0:
            h, m = divmod(remaining // 60, 60)
            self.log(f"Token valid — expires in {h}h {m}m", "ok")
            return True
        self.log("Token expired", "warn")
        return False

    def login(self):
        if not self.email or not self.password:
            raise AuthError("No credentials set. Add them in the Settings tab.")
        self.log(f"Logging in as {self.email}...")
        resp = self.session.post(
            self._url("/api/auth/login"),
            headers=self._headers(referer=f"{RDS_BASE_URL}/login", json_body=True),
            json={"email": self.email, "password": self.password}, timeout=60)
        if resp.status_code != 200:
            raise AuthError(f"Login failed — HTTP {resp.status_code}: "
                            f"{resp.text[:200]}")
        try:
            token = resp.json().get("access_token")
        except ValueError:
            token = None
        if not token:
            m = re.search(r"access_token=([^;]+)",
                          resp.headers.get("Set-Cookie", ""))
            token = m.group(1) if m else None
        if not token:
            raise AuthError("Login response contained no access_token")
        self.token = token
        self.log("Login successful — new token acquired", "ok")

    def ensure_token(self):
        if not self.token_valid():
            self.login()

    # ── submit ─────────────────────────────────────────────
    def submit(self, dataset: str, label: str, payload: dict) -> str:
        referer = DATASETS[dataset]["referer"]
        self.ensure_token()
        resp = self.session.post(
            self._url("/api/jobs"),
            headers=self._headers(referer=referer, json_body=True),
            json=payload, timeout=120)
        if resp.status_code == 401:
            self.log("HTTP 401 — re-logging in and retrying...", "warn")
            self.token = None
            self.login()
            resp = self.session.post(
                self._url("/api/jobs"),
                headers=self._headers(referer=referer, json_body=True),
                json=payload, timeout=120)
        if resp.status_code not in (200, 201):
            raise RuntimeError(f"Submit failed — HTTP {resp.status_code}: "
                               f"{resp.text[:400]}")
        try:
            body = resp.json()
        except ValueError:
            raise RuntimeError(f"Submit returned non-JSON: {resp.text[:300]}")
        job_id = body.get("id")
        if not job_id:
            raise RuntimeError(f"No job ID in response: {resp.text[:300]}")
        return job_id

    # ── poll ───────────────────────────────────────────────
    def list_jobs(self) -> list[dict]:
        self.ensure_token()
        r = self.session.get(self._url("/api/jobs/my"),
                             headers=self._headers(
                                 referer=f"{RDS_BASE_URL}/my-requests"),
                             timeout=60)
        r.raise_for_status()
        data = r.json()
        return data if isinstance(data, list) else data.get("jobs", [])

    def wait_for(self, job_ids: list[str], on_cycle=None) -> dict:
        """Poll until every id reaches a terminal state -> {id: status}."""
        pending = set(job_ids)
        final: dict[str, str] = {}
        elapsed = 0
        bad = {"FAILED", "ERROR", "CANCELLED", "CANCELED", "EXPIRED"}

        while pending and elapsed < self.max_wait:
            if self._should_stop():
                raise KeyboardInterrupt("Stopped by user")
            statuses = {str(j.get("id")): str(j.get("status", "")).upper()
                        for j in self.list_jobs()}
            done = set()
            for jid in list(pending):
                st = statuses.get(jid, "")
                if st == "COMPLETED":
                    final[jid] = "COMPLETED"
                    done.add(jid)
                elif st in bad:
                    final[jid] = st
                    done.add(jid)
                    self.log(f"Job {jid} → {st}", "error")
            pending -= done
            if on_cycle:
                on_cycle(sorted(pending), sorted(final))
            if not pending:
                break
            self.log(f"Waiting {self.poll_interval}s — "
                     f"{len(pending)} job(s) pending")
            for _ in range(self.poll_interval):      # interruptible sleep
                if self._should_stop():
                    raise KeyboardInterrupt("Stopped by user")
                time.sleep(1)
            elapsed += self.poll_interval

        for jid in pending:
            final[jid] = "TIMEOUT"
            self.log(f"Job {jid} timed out after {self.max_wait}s", "error")
        return final

    # ── download ───────────────────────────────────────────
    def download_job(self, job_id: str, target, on_progress=None) -> Path:
        target = Path(target)
        target.parent.mkdir(parents=True, exist_ok=True)
        # job_id comes from the API: refuse anything that is not a plain id
        # before it reaches the URL path or a filename.  _safe_component()
        # below remains as belt-and-braces for the filename.
        job_id = validate_job_id(job_id)
        tmp = target.parent / f"{_safe_component(job_id)}.part"
        url = self._url(f"/downloads/{job_id}/{job_id}.zip")
        self.log(f"Downloading job {job_id}")
        if self._should_stop():
            raise KeyboardInterrupt("Stopped by user")

        headers = {
            "Accept": "application/octet-stream",
            "Origin": RDS_BASE_URL,
            "Referer": f"{RDS_BASE_URL}/my-requests",
            "User-Agent": USER_AGENT,
            "Cookie": f"ext_name={RDS_EXT_NAME}; access_token={self.token}",
        }
        written = 0
        cap = max_download_bytes()
        try:
            with self.session.get(url, headers=headers, stream=True,
                                  timeout=(60, 300)) as resp:
                if resp.status_code != 200:
                    raise RuntimeError(f"HTTP {resp.status_code}: "
                                       f"{resp.text[:200]}")
                total = int(resp.headers.get("Content-Length") or 0)
                if cap and total > cap:
                    raise RuntimeError(
                        f"Refusing download: server advertises "
                        f"{human_size(total)}, above the "
                        f"{human_size(cap)} limit (raise RDS_MAX_DOWNLOAD_MB)")
                with open(tmp, "wb") as fh:
                    for chunk in resp.iter_content(1024 * 256):
                        if not chunk:
                            continue
                        if self._should_stop():
                            raise KeyboardInterrupt("Stopped by user")
                        fh.write(chunk)
                        written += len(chunk)
                        if cap and written > cap:
                            raise RuntimeError(
                                f"Download exceeded the {human_size(cap)} "
                                "limit (raise RDS_MAX_DOWNLOAD_MB)")
                        if on_progress:
                            on_progress(written, total)
            if written < MIN_PLAUSIBLE_ZIP:
                body = tmp.read_bytes()[:300]
                raise RuntimeError(f"Download too small ({written} bytes) — "
                                   f"server error: "
                                   f"{body.decode('utf-8', 'replace')}")
            with open(tmp, "rb") as fh:
                check_zip_magic(fh.read(4))
            if target.exists():
                target.unlink()
            tmp.replace(target)
        except Exception:
            tmp.unlink(missing_ok=True)
            raise
        self.log(f"Saved: {target} ({human_size(written)})", "ok")
        return target

    # ── high level ─────────────────────────────────────────
    def run(self, dataset: str, years: list[str], months, days, times,
            bbox, variables, pressure_levels, target_template: str,
            download_dir, on_cycle=None, init_day=None, forecast_days=None) -> dict:
        """Submit one job per year, poll together, download on completion."""
        target_template = target_template or "{dataset}_{year}.zip"
        download_dir = Path(download_dir)
        download_dir.mkdir(parents=True, exist_ok=True)
        months_e = expand_months(months)

        jobs: list[tuple[str, str, Path]] = []

        self.log("=" * 46)
        self.log(f" STEP 1 — Submitting {len(years)} job(s)")
        self.log("=" * 46)
        self.ensure_token()

        for year in years:
            if self._should_stop():
                raise KeyboardInterrupt("Stopped by user")
            fn = target_template.replace("{dataset}", dataset).replace(
                "{year}", year)
            target = safe_target(download_dir, fn)
            label, payload = build_payload(
                dataset, year, months_e, days, times, bbox, variables,
                pressure_levels, init_day=init_day, forecast_days=forecast_days,
                warn=lambda m: self.log(m, "warn"))
            try:
                job_id = self.submit(dataset, label, payload)
            except Exception as e:
                self.log(f"Submit failed for {year}: {e}", "error")
                continue
            jobs.append((year, job_id, target))
            self.job_log.add(job_id, dataset, label, year, "SUBMITTED", str(target))
            self.log(f"{year} → job_id {job_id}", "ok")

        if not jobs:
            raise RuntimeError("No jobs were submitted successfully.")

        self.log("")
        self.log("=" * 46)
        self.log(" STEP 2 — Polling")
        self.log("=" * 46)
        final = self.wait_for([j[1] for j in jobs], on_cycle=on_cycle)
        for year, job_id, _ in jobs:
            self.job_log.update(job_id, final.get(job_id, "UNKNOWN"))

        self.log("")
        self.log("=" * 46)
        self.log(" STEP 3 — Downloading")
        self.log("=" * 46)

        files, failed = [], 0
        for year, job_id, target in jobs:
            if final.get(job_id) != "COMPLETED":
                failed += 1
                self.log(f"{year}: job {final.get(job_id)} — skipped", "error")
                continue

            def _progress(w, t, _y=year):
                pct = int(w * 100 / t) if t else 0
                if pct % 25 == 0:
                    self.log(f"  {_y}: {human_size(w)}"
                             + (f" / {human_size(t)}" if t else ""), "info")

            try:
                p = self.download_job(job_id, target, on_progress=_progress)
                self.job_log.update(job_id, "DOWNLOADED")
                files.append(p)
            except KeyboardInterrupt:
                self.job_log.update(job_id, "DOWNLOAD_FAILED")
                raise
            except Exception as e:
                self.log(f"Download failed for {year}: {e}", "error")
                self.job_log.update(job_id, "DOWNLOAD_FAILED")
                failed += 1

        return {"submitted": len(jobs), "downloaded": len(files),
                "failed": failed, "files": files}

    def fetch_completed_jobs(self) -> list[dict]:
        """Completed jobs on the portal, newest first.

        Split out from download_existing() so a caller can show the list and
        let the user choose a subset before anything is downloaded.  Logs
        nothing itself -- the caller decides what to announce.
        """
        jobs = [j for j in self.list_jobs()
                if str(j.get("status", "")).upper() == "COMPLETED"]
        jobs.sort(
            key=lambda j: str(next((j.get(k) for k in _JOB_DATE_KEYS
                                    if j.get(k)), "")),
            reverse=True)
        return jobs

    def download_existing(self, out_dir, jobs=None) -> dict:
        """Download completed jobs.

        ``jobs`` is the subset the user picked (the dicts returned by
        ``fetch_completed_jobs``).  ``None`` means "every completed job on the
        portal", which preserves the original one-shot behaviour.
        """
        out_dir = Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        self.log("=" * 46)
        self.log(" Fetching completed jobs from portal")
        self.log("=" * 46)

        if jobs is None:
            jobs = self.fetch_completed_jobs()
        if not jobs:
            self.log("No completed jobs found on portal.")
            return {"submitted": 0, "downloaded": 0, "failed": 0, "files": []}

        self.log(f"Found {len(jobs)} completed job(s)")
        total, failed, files = len(jobs), 0, []
        for i, j in enumerate(jobs, 1):
            if self._should_stop():
                raise KeyboardInterrupt("Stopped by user")
            job_id = str(j.get("id"))
            # job_type is a human label on the live portal ("NGFS daily data
            # on single levels from 1999 to 2018" - 49 chars), so it is capped
            # before it becomes a filename: an unbounded server string plus a
            # deep download folder can blow past the Windows MAX_PATH limit.
            jt = re.sub(r"[^\w\-]+", "_", str(j.get("job_type", "job"))).strip("_")[:64]
            jt = jt or "job"
            target = out_dir / f"{jt}_{_safe_component(job_id[:8])}.zip"
            self.log(f"[{i}/{total}] {jt}")
            if target.exists() and target.stat().st_size >= MIN_PLAUSIBLE_ZIP:
                self.log("  already exists — skipping", "warn")
                files.append(target)
                continue
            try:
                files.append(self.download_job(job_id, target))
            except KeyboardInterrupt:
                raise
            except Exception as e:
                self.log(f"  FAILED: {e}", "error")
                failed += 1
        return {"submitted": total, "downloaded": len(files),
                "failed": failed, "files": files}


# ─────────────────────────────────────────────────────────────
#  PRESETS
# ─────────────────────────────────────────────────────────────
class PresetManager:
    def __init__(self):
        self.file = config_dir() / "presets.ini"
        self.load()

    def load(self):
        self.presets = configparser.ConfigParser()
        if self.file.exists():
            try:
                self.presets.read(self.file, encoding="utf-8")
            except configparser.Error:
                self.presets = configparser.ConfigParser()
        if "presets" not in self.presets:
            self.presets["presets"] = {}

    def _save(self):
        with open(self.file, "w", encoding="utf-8") as f:
            self.presets.write(f)

    def names(self) -> list[str]:
        return list(self.presets["presets"].keys())

    def save(self, name: str, config: dict):
        self.presets["presets"][name] = {
            k: (",".join(v) if isinstance(v, (list, tuple)) else str(v))
            for k, v in config.items()}
        self._save()

    def load_one(self, name: str):
        if name not in self.presets["presets"]:
            return None
        data = dict(self.presets["presets"][name])
        for key in ("months", "days", "times", "variables", "pressure",
                    "forecast"):
            data[key] = [v for v in data.get(key, "").split(",") if v]
        return data

    def delete(self, name: str):
        if name in self.presets["presets"]:
            del self.presets["presets"][name]
            self._save()


# ─────────────────────────────────────────────────────────────
#  REQUEST-FILE BRIDGE  (a request.txt the shell run_work.sh can consume)
# ─────────────────────────────────────────────────────────────
def build_request_text(dataset: str, years: list[str], months, days, times,
                       bbox, variables, pressure_levels,
                       download_dir, target_template: str) -> str:
    months_e = expand_months(months)
    days_e = expand_days(days)
    tgt = (target_template or "{dataset}_{year}.zip").replace("{dataset}", dataset)
    tgt = tgt.replace("{year}", years[0]) if len(years) == 1 else tgt
    target = str(Path(download_dir) / tgt)

    lines = [
        f"dataset = {dataset}",
        f"year    = {','.join(years)}",
        f"month   = {'all' if len(months_e) == 12 else ','.join(months_e)}",
        f"day     = {'all' if len(days_e) == 31 else ','.join(days_e)}",
    ]
    if times and DATASETS[dataset]["time"]:
        lines.append(f"time    = {','.join(str(t) for t in times)}")
    if variables:
        lines.append(f"variables = {','.join(variables)}")
    if pressure_levels and DATASETS[dataset].get("pressure"):
        lines.append(f"pressure_level = {','.join(pressure_levels)}")
    for key in ("north", "south", "east", "west"):
        if bbox.get(key) not in (None, ""):
            lines.append(f"{key:<7} = {bbox[key]}")
    lines.append(f"target  = {target}")
    return "\n".join(lines)