#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
rds_gui_tk.py — NCMRWF RDS Downloader (Windows / tkinter build)

Native Windows port of rds_gui3.py. Feature parity with the GTK version, plus:
  * an inline month-grid calendar for picking a date range / season
  * a compact two-column layout that fits a 14" laptop (1366x768) screen
  * everything wrapped in a scroll area so nothing is ever unreachable

The download engine runs IN-PROCESS via rds_engine (pure Python) — no bash,
curl or jq required.
"""

from __future__ import annotations

import calendar
import os
import subprocess
import sys
import threading
import tkinter as tk
import tkinter.simpledialog as simpledialog
import queue
from datetime import date
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

sys.path.insert(0, str(Path(__file__).resolve().parent))

from rds_engine import (  # noqa: E402
    DATASETS,
    FORECAST_DAYS,
    INIT_DAYS,
    PRESSURE_LEVELS_BY_DATASET,
    SEASON_PRESETS,
    TIME_ALL,
    VARIABLES_BY_DATASET,
    JobLog,
    PresetManager,
    RDSClient,
    build_request_text,
    build_payload,
    config_dir,
    dates_to_months_days,
    human_size,
    job_display,
    months_to_dates_anchor,
    parse_years,
    validate_target_template,
    read_credentials,
    write_credentials,
)

from rds_themes import (  # noqa: E402
    DEFAULT_FONT_STEP,
    DEFAULT_THEME,
    FONT_ROLES,
    FONT_STEPS,
    MONO_FAMILY,
    SANS_FAMILY,
    TEAL,
    THEMES,
    THEME_ORDER,
    scaled,
)

APP_TITLE = "NCMRWF Data Downloader v0.5"
APP_SUBTITLE = "IMDAA / NGFS Reanalysis  |  rds.ncmrwf.gov.in"

# Main window geometry. 1366x768 is the common 14" laptop; height is the binding
# constraint there, but width was previously clamped to 1000 which starved the
# right-hand column and clipped it off-screen. See UI-WORKLOG.md D-01.
WIN_W, WIN_H = 1180, 660
WIN_MIN_W, WIN_MIN_H = 960, 540

# Calendar geometry. CELL_W is derived from CAL_W so the grid can never be
# narrower than its columns; both scale with the font size.
def cell_w() -> int:
    return int(round(34 * _FONT_SCALE))


def cal_w() -> int:
    return cell_w() * 7 + 6


def cal_h() -> int:
    # base 190 covers: head row + weekday header + up to 6 week rows + padding
    return int(round(190 * _FONT_SCALE))


# ═════════════════════════════════════════════════════════════
#  FONT SCALE
#
#  The role/step tables live in rds_themes.py so both front-ends share one
#  definition (D-21). The scaling helpers stay here because they drive the
#  module-level _FONT_SCALE that cell_w()/cal_w() above read. D-13.
# ═════════════════════════════════════════════════════════════
_FONT_SCALE = FONT_STEPS[DEFAULT_FONT_STEP]


def font(role: str, *style):
    """Font tuple for a role at the current scale, e.g. font("tool")."""
    return (SANS_FAMILY, scaled(role, _FONT_SCALE), *style)


def mono(role: str, *style):
    """Monospace font tuple for a role at the current scale."""
    return (MONO_FAMILY, scaled(role, _FONT_SCALE), *style)


def _set_font_scale(step: str) -> str:
    """Set the global scale. Returns the step actually applied."""
    global _FONT_SCALE
    step = step if step in FONT_STEPS else DEFAULT_FONT_STEP
    _FONT_SCALE = FONT_STEPS[step]
    return step

MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"]
MONTHS = [(f"{m:02d}", name) for m, name in enumerate(MONTH_NAMES, start=1)]
DAYS = [f"{d:02d}" for d in range(1, 32)]

REGION_PRESETS = {
    "India": (45, -15, 120, 30),
    "Asia": (60, -10, 150, 20),
    "Global": (90, -90, 180, -180),
}


# ═════════════════════════════════════════════════════════════
#  SCROLL AREA  (so a short screen never hides controls)
# ═════════════════════════════════════════════════════════════
class CollapsePanel(ttk.Frame):
    """A titled section whose body can be folded away.

    Built from a Frame + a header button rather than a LabelFrame: packing a
    child into a LabelFrame to hold the toggle arrow made the frame's own
    title stop rendering. The header button doubles as the label, so the
    title is always visible and the whole strip is clickable.
    Used for the calendar and the request preview. See UI-WORKLOG.md D-19.
    """

    def __init__(self, parent, title="", collapsed=False, on_toggle=None, **kw):
        super().__init__(parent, **kw)
        self._collapsed = collapsed
        self._on_toggle = on_toggle
        header = ttk.Frame(self)
        header.pack(fill="x")
        self._btn = ttk.Button(header, text="", style="Panel.TButton",
                               command=self.toggle)
        self._btn.pack(side="left", fill="x", expand=True)
        self.inner = ttk.Frame(self)
        self._title = title
        self._sync()

    @property
    def collapsed(self) -> bool:
        return self._collapsed

    def set_collapsed(self, value: bool, notify=True):
        self._collapsed = bool(value)
        self._sync()
        if notify and self._on_toggle:
            self._on_toggle(self._collapsed)

    def toggle(self):
        self.set_collapsed(not self._collapsed)

    def _sync(self):
        if self._collapsed:
            self.inner.pack_forget()
        else:
            self.inner.pack(fill="both", expand=True)
        mark = "▸" if self._collapsed else "▾"
        self._btn.config(text=f" {mark}  {self._title}")


class ScrollFrame(ttk.Frame):
    """Vertical scroll container with an always-visible, themed scrollbar.

    The scrollbar is never packed/unpacked: it is kept in the layout and
    disabled when everything fits. Packing it out and back in used to shift
    the canvas width every time the content crossed the threshold, which
    made the scrollbar flicker and the body re-wrap.
    See UI-WORKLOG.md D-17.
    """

    def __init__(self, parent, **kw):
        super().__init__(parent, **kw)
        self._palette = THEMES[DEFAULT_THEME]
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0,
                                background=self._palette["bg"])
        # NB: ttk.Scrollbar has no -width option; the visible thickness comes
        # from the style's `arrowsize`, which is set in _style_scrollbar().
        self.vbar = ttk.Scrollbar(self, orient="vertical",
                                  command=self.canvas.yview)
        self.body = ttk.Frame(self.canvas)
        self._win = self.canvas.create_window((0, 0), window=self.body,
                                              anchor="nw")
        self.canvas.configure(yscrollcommand=self._on_scroll_set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.vbar.pack(side="right", fill="y")

        self.body.bind("<Configure>", self._on_body_configure)
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        for w in (self.canvas, self.body):
            w.bind("<MouseWheel>", self._on_wheel)
        self._style_scrollbar()

    def _style_scrollbar(self):
        t = self._palette
        s = ttk.Style(self)          # ttk.Frame has no .style of its own
        s.configure("RDS.Vertical.TScrollbar",
                    troughcolor=t["card"], background=t["accent"],
                    bordercolor=t["line"], darkcolor=t["card"],
                    lightcolor=t["card"], arrowcolor=t["muted"],
                    borderwidth=0, relief="flat", arrowsize=15)
        s.map("RDS.Vertical.TScrollbar",
              background=[("disabled", t["line"]), ("pressed", t["accent"])],
              troughcolor=[("disabled", t["bg"]), ("!disabled", t["card"])],
              arrowcolor=[("disabled", t["line"]), ("!disabled", t["muted"])])
        self.vbar.configure(style="RDS.Vertical.TScrollbar")

    def set_theme(self, palette: dict):
        """Follow the app theme: canvas background + scrollbar colours."""
        self._palette = palette
        self.canvas.configure(background=palette["bg"])
        self._style_scrollbar()

    def _on_scroll_set(self, first, last):
        # Keep the bar in the layout and just disable it when everything fits.
        self.vbar.set(first, last)
        try:
            if float(first) <= 0.0 and float(last) >= 1.0:
                self.vbar.state(["disabled"])
            else:
                self.vbar.state(["!disabled"])
        except tk.TclError:
            pass

    def _on_body_configure(self, _e=None):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))

    def _on_canvas_configure(self, e):
        self.canvas.itemconfigure(self._win, width=e.width)

    def _on_wheel(self, e):
        if self.canvas.bbox("all"):
            self.canvas.yview_scroll(int(-1 * (e.delta / 120)), "units")


# ═════════════════════════════════════════════════════════════
#  MONTH-GRID CALENDAR  (range selection, no external deps)
# ═════════════════════════════════════════════════════════════
class MonthCalendar(ttk.Frame):
    """Compact inline calendar. Click once = start, click again = end."""

    def __init__(self, parent, year=2005, on_change=None, **kw):
        super().__init__(parent, **kw)
        self.year = year
        self.month = 1
        self.start: date | None = None
        self.end: date | None = None
        self.on_change = on_change
        self.min_year, self.max_year = 1979, 2020
        self._dark = False
        self._palette = THEMES[DEFAULT_THEME]["cal"]
        self._head_labels: list = []
        self._cells: dict[date, tk.Label] = {}
        self._build()

    # ── chrome ──────────────────────────────────────────
    def _build_geometry(self):
        """Re-measure the calendar for the current font scale."""
        self.configure(width=cal_w(), height=cal_h())
        # Called once from _build() before grid_frame exists, and again from
        # _set_font_step() after it does.
        gf = getattr(self, "grid_frame", None)
        if gf is None:
            return
        for col in range(7):
            gf.columnconfigure(col, minsize=cell_w(), weight=0)
        # These two are built once, so a font change has to re-point them --
        # only the day cells are rebuilt by render().
        if getattr(self, "title_lbl", None) is not None:
            self.title_lbl.config(font=font("cal_title", "bold"))
        for lbl in getattr(self, "_head_labels", []):
            lbl.config(font=font("cal_head", "bold"))

    def _build(self):
        self.pack_propagate(False)
        self._build_geometry()

        head = ttk.Frame(self)
        head.pack(fill="x", padx=2, pady=(0, 3))
        ttk.Button(head, text="‹", width=3,
                   command=lambda: self.shift(-1)).pack(side="left")
        self.title_lbl = ttk.Label(head, text="", anchor="center",
                                   font=font("cal_title", "bold"))
        self.title_lbl.pack(side="left", fill="x", expand=True)
        ttk.Button(head, text="›", width=3,
                   command=lambda: self.shift(1)).pack(side="right")

        # The weekday header and the day cells live in the SAME grid frame, so
        # every header is guaranteed to sit directly above its column.
        # Previously the headers were placed in a parent frame and the cells in
        # a child frame, and the column sizing was applied to only one of them
        # -- which is why "Su" drifted away from its column while Mo-Sa bunched
        # up on the left. See UI-WORKLOG.md D-03.
        self.grid_frame = tk.Frame(self)
        self.grid_frame.pack(fill="both", expand=True)

        self.grid_frame.rowconfigure(0, weight=0)          # weekday header
        for r in range(1, 7):                              # 6 week rows
            self.grid_frame.rowconfigure(r, weight=0)

        for col, name in enumerate(["Mo", "Tu", "We", "Th",
                                    "Fr", "Sa", "Su"]):
            lbl = ttk.Label(self.grid_frame, text=name,
                            font=font("cal_head", "bold"),
                            anchor="center")
            lbl.grid(row=0, column=col, sticky="ew")
            self._head_labels.append(lbl)

        self.render()

    # ── state ───────────────────────────────────────────
    def set_year_range(self, lo: int, hi: int):
        self.min_year, self.max_year = lo, hi
        self.year = max(lo, min(hi, self.year))
        self.render()

    def shift(self, delta: int):
        m = self.month + delta
        y = self.year
        while m < 1:
            m += 12
            y -= 1
        while m > 12:
            m -= 12
            y += 1
        self.year = max(self.min_year, min(self.max_year, y))
        self.month = m
        self.render()

    def get_range(self):
        if self.start and self.end:
            a, b = sorted((self.start, self.end))
            return a, b
        if self.start:
            return self.start, self.start
        return None, None

    def set_range(self, a: date | None, b: date | None = None):
        if a is None:
            self.start = self.end = None
        else:
            self.start, self.end = a, b
        if a:
            self.year, self.month = a.year, a.month
        self.render()

    def clear(self):
        self.set_range(None)

    def _changed(self):
        if self.on_change:
            self.on_change(self.get_range())

    # ── painting ────────────────────────────────────────
    def render(self):
        for w in self._cells.values():
            w.destroy()
        self._cells.clear()

        self.title_lbl.config(text=f"{MONTH_NAMES[self.month - 1][:3]} {self.year}")

        c = self._palette or THEMES[DEFAULT_THEME]["cal"]
        bg_out = c["bg_out"]
        bg_norm = c["bg_norm"]
        bg_in = c["bg_in"]
        fg_norm = c["fg_norm"]
        fg_in = c["fg_in"]
        fg_edge = c["fg_edge"]
        today_bg = c["today_bg"]

        weeks = calendar.monthcalendar(self.year, self.month)
        a, b = self.get_range()

        for r, week in enumerate(weeks):
            for c, day in enumerate(week):
                if day == 0:
                    tk.Label(self.grid_frame, text="", bg=bg_out).grid(
                        row=r + 1, column=c, sticky="nsew")
                    continue
                d = date(self.year, self.month, day)
                in_range = bool(a and b and a <= d <= b)
                edge = d in (a, b)
                bg = bg_in if in_range else (
                    today_bg if d == date.today() else bg_norm)
                fg = fg_in if in_range else (
                    fg_edge if d == date.today() else fg_norm)

                cell = tk.Label(
                    self.grid_frame, text=str(day), bg=bg, fg=fg,
                    font=font("cal_day", "bold" if edge else "normal"),
                    width=4, height=1, cursor="hand2",
                    highlightthickness=1,
                    highlightbackground=fg_edge if edge else bg_out,
                )
                cell.grid(row=r + 1, column=c, sticky="nsew", padx=0, pady=0)
                cell.bind("<Button-1>", lambda _e, dd=d: self._click(dd))
                self._cells[d] = cell

    def _click(self, d: date):
        if self.start is None or (self.start and self.end):
            self.start, self.end = d, None
        elif d < self.start:
            self.start, self.end = d, self.start
        else:
            self.end = d
        self.render()
        self._changed()

    def set_theme(self, palette: dict | None):
        """Apply a theme palette (from THEMES) to the calendar."""
        self._palette = palette
        self._dark = bool(palette and palette.get("dark"))
        self.render()


# ═════════════════════════════════════════════════════════════
#  SELECT-ALL DIALOG  (used for advanced month/day/time/var picking)
# ═════════════════════════════════════════════════════════════
class SelectAllDialog(tk.Toplevel):
    def __init__(self, parent, title, items, selected=None, columns=3,
                 labels=None):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.resizable(True, True)
        self.geometry("440x500")
        self.result = None
        self._columns = columns
        self.items = list(items)
        self.labels = labels or {}

        body = ttk.Frame(self, padding=12)
        body.pack(fill="both", expand=True)

        self.search = ttk.Entry(body)
        self.search.pack(fill="x")
        self.search.bind("<KeyRelease>", lambda e: self._filter())

        bar = ttk.Frame(body)
        bar.pack(fill="x", pady=(8, 4))
        self.count_lbl = ttk.Label(bar, text=f"Total: {len(items)}")
        self.count_lbl.pack(side="left")
        ttk.Button(bar, text="Invert", command=self._invert).pack(side="right")
        ttk.Button(bar, text="Clear All",
                   command=lambda: self._set_all(False)).pack(side="right", padx=4)
        ttk.Button(bar, text="Select All",
                   command=lambda: self._set_all(True)).pack(side="right")

        wrap = ttk.Frame(body)
        wrap.pack(fill="both", expand=True, pady=4)
        sb = ttk.Scrollbar(wrap)
        sb.pack(side="right", fill="y")
        cv = tk.Canvas(wrap, highlightthickness=0, bd=0, yscrollcommand=sb.set)
        cv.pack(side="left", fill="both", expand=True)
        sb.config(command=cv.yview)
        self.gf = ttk.Frame(cv)
        cv.create_window((0, 0), window=self.gf, anchor="nw")
        self.gf.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))

        self.checks: dict[str, tk.BooleanVar] = {}
        sel = set(selected or [])
        for item in self.items:
            var = tk.BooleanVar(value=item in sel)
            self.checks[item] = var
        self._filter()

        btns = ttk.Frame(body)
        btns.pack(fill="x", pady=(8, 0))
        ttk.Button(btns, text="Cancel", command=self._cancel).pack(side="right")
        ttk.Button(btns, text="OK", command=self._ok).pack(side="right", padx=6)

        self.bind("<Escape>", lambda e: self._cancel())
        self.bind("<Return>", lambda e: self._ok())
        self.grab_set()
        self.focus_set()

    def _visible(self):
        q = self.search.get().strip().lower()
        return [i for i in self.items if not q or q in i.lower()]

    def _filter(self):
        for w in self.gf.winfo_children():
            w.grid_remove()
        vis = self._visible()
        for i, item in enumerate(vis):
            cb = ttk.Checkbutton(self.gf, text=self.labels.get(item, item),
                                 variable=self.checks[item])
            cb.grid(row=i // self._columns, column=i % self._columns,
                    sticky="w", padx=6, pady=2)
        self.count_lbl.config(text=f"Showing {len(vis)} / {len(self.items)}")

    def _set_all(self, active):
        for item in self._visible():
            self.checks[item].set(active)

    def _invert(self):
        for item in self._visible():
            self.checks[item].set(not self.checks[item].get())

    def _ok(self):
        self.result = [k for k, v in self.checks.items() if v.get()]
        self.destroy()

    def _cancel(self):
        self.result = None
        self.destroy()

    @staticmethod
    def ask(parent, title, items, selected=None, columns=3, labels=None):
        dlg = SelectAllDialog(parent, title, items, selected, columns, labels)
        parent.wait_window(dlg)
        return dlg.result


# ═════════════════════════════════════════════════════════════
#  YEAR PICKER
# ═════════════════════════════════════════════════════════════
class YearPicker(tk.Toplevel):
    def __init__(self, parent, years, current=""):
        super().__init__(parent)
        self.title("Select Years")
        self.transient(parent)
        self.geometry("320x450")
        self.result = None
        self.years = list(years)

        cur = {y.strip() for y in str(current).split(",") if y.strip()}
        cur |= set(parse_years(str(current)))

        wrap = ttk.Frame(self, padding=12)
        wrap.pack(fill="both", expand=True)
        inner = ttk.Frame(wrap)
        sb = ttk.Scrollbar(inner)
        sb.pack(side="right", fill="y")
        cv = tk.Canvas(inner, highlightthickness=0, bd=0, yscrollcommand=sb.set)
        cv.pack(side="left", fill="both", expand=True)
        sb.config(command=cv.yview)
        gf = ttk.Frame(cv)
        cv.create_window((0, 0), window=gf, anchor="nw")
        gf.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))

        self.checks = {}
        for i, y in enumerate(self.years):
            var = tk.BooleanVar(value=str(y) in cur)
            self.checks[y] = var
            ttk.Checkbutton(gf, text=str(y), variable=var).grid(
                row=i // 4, column=i % 4, sticky="w", padx=6, pady=2)

        bar = ttk.Frame(wrap)
        bar.pack(fill="x", pady=8)
        ttk.Button(bar, text="All", command=lambda: self._set_all(True)).pack(side="left")
        ttk.Button(bar, text="None", command=lambda: self._set_all(False)).pack(side="left", padx=4)
        ttk.Button(bar, text="Range...", command=self._range).pack(side="left")

        btns = ttk.Frame(wrap)
        btns.pack(fill="x")
        ttk.Button(btns, text="Cancel", command=self.destroy).pack(side="right")
        ttk.Button(btns, text="OK", command=self._ok).pack(side="right", padx=6)
        self.grab_set()

    def _set_all(self, active):
        for v in self.checks.values():
            v.set(active)

    def _range(self):
        nums = sorted(self.years)
        dlg = tk.Toplevel(self)
        dlg.title("Select Year Range")
        dlg.transient(self)
        f = ttk.Frame(dlg, padding=12)
        f.pack(fill="both", expand=True)
        start = tk.StringVar(value=str(nums[0]))
        end = tk.StringVar(value=str(nums[-1]))
        ttk.Label(f, text="Start:").grid(row=0, column=0, sticky="e", pady=4)
        ttk.Combobox(f, textvariable=start, values=[str(n) for n in nums],
                     state="readonly", width=9).grid(row=0, column=1, padx=6)
        ttk.Label(f, text="End:").grid(row=1, column=0, sticky="e", pady=4)
        ttk.Combobox(f, textvariable=end, values=[str(n) for n in nums],
                     state="readonly", width=9).grid(row=1, column=1, padx=6)
        ttk.Button(f, text="Apply", command=dlg.destroy).grid(
            row=2, column=0, columnspan=2, pady=(10, 0))
        dlg.grab_set()
        self.wait_window(dlg)
        try:
            a, b = int(start.get()), int(end.get())
        except ValueError:
            return
        if a > b:
            a, b = b, a
        for y, v in self.checks.items():
            v.set(a <= y <= b)

    def _ok(self):
        sel = [str(y) for y, v in self.checks.items() if v.get()]
        if not sel:
            self.result = ""
        elif all(int(sel[i]) + 1 == int(sel[i + 1]) for i in range(len(sel) - 1)):
            self.result = f"{sel[0]}-{sel[-1]}"
        else:
            self.result = ",".join(sel)
        self.destroy()


# ═════════════════════════════════════════════════════════════
#  MAIN WINDOW
# ═════════════════════════════════════════════════════════════
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        # 1366x768 is the common 14" laptop. Height was the binding constraint
        # in v0.4, but clamping width to 1000 starved the right column and
        # clipped it off-screen (the W: longitude field disappeared entirely).
        # See UI-WORKLOG.md D-01.
        self.geometry(f"{WIN_W}x{WIN_H}")
        self.minsize(WIN_MIN_W, WIN_MIN_H)

        self._q: queue.Queue = queue.Queue()
        self._thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        # Completed jobs fetched by "Download Existing", waiting for the user to
        # choose.  Held here so the picker opens only after the fetch worker has
        # fully finished (see _drain).
        self._pending_existing: list | None = None
        self._theme, self._font_step, self._cal_collapsed, self._preview_collapsed = \
            self._load_ui_prefs()
        _set_font_scale(self._font_step)
        self._dark = THEMES[self._theme]["dark"]
        self._presets = PresetManager()
        self._job_log = JobLog()
        self._scrollframes: list[ScrollFrame] = []

        default_ds = list(DATASETS)[0]
        self._sel_months = [m[0] for m in MONTHS]
        self._sel_days = DAYS[:]
        self._sel_times = list(TIME_ALL.get(default_ds, []))
        self._sel_vars: list[str] = []
        self._sel_pressure: list[str] = []
        self._sel_forecast: list[str] = []
        self._init_day = "01"

        self._build_style()
        self._build_ui()
        # Re-apply: _build_style ran before the tabs existed, so the
        # ScrollFrames' canvases and scrollbars were created with the default
        # theme instead of the restored one. See UI-WORKLOG.md D-17.
        self._apply_theme()
        self._refresh_dataset_fields()
        self._auto_update_target()
        self._populate_presets()
        self._load_credentials()

        self._drain_job = self.after(60, self._drain)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── styling ────────────────────────────────────────────
    def _build_style(self):
        self.style = ttk.Style(self)
        try:
            self.style.theme_use("clam")
        except tk.TclError:
            pass
        self._apply_theme()

    def _apply_theme(self):
        t = THEMES.get(self._theme, THEMES[DEFAULT_THEME])
        self._dark = t["dark"]
        bg, card, fg = t["bg"], t["card"], t["fg"]
        line, accent, muted = t["line"], t["accent"], t["muted"]
        accent_text = t.get("accent_text", accent)

        self.configure(bg=bg)
        s = self.style
        s.configure(".", background=bg, foreground=fg, fieldbackground=card,
                    bordercolor=line, darkcolor=card, lightcolor=line,
                    focuscolor=accent, font=font("body"))
        s.configure("TFrame", background=bg)
        s.configure("TLabel", background=bg, foreground=fg)
        # Title.TLabel is no longer used (the banner was removed, D-02) and
        # Sub.TLabel now sits on the normal panel background, so it must use
        # the muted foreground rather than the old on-teal colours.
        s.configure("Sub.TLabel", background=bg, foreground=accent_text,
                    font=font("sub"))
        s.configure("Hint.TLabel", background=bg, foreground=muted,
                    font=font("hint"))
        s.configure("Status.TLabel", background=bg, foreground=muted,
                    font=font("status"), padding=(10, 4))
        s.configure("TLabelframe", background=bg, bordercolor=line,
                    relief="solid", borderwidth=1)
        s.configure("TLabelframe.Label", background=bg, foreground=accent_text,
                    font=font("frame_label", "bold"))
        s.configure("TButton", padding=(8, 4))
        s.configure("Tool.TButton", padding=(8, 3), font=font("tool"))
        # Section header for CollapsePanel: looks like a field label but
        # is a button, so the title doubles as the expand/collapse control.
        s.configure("Panel.TButton", background=bg, foreground=accent_text,
                    font=font("frame_label", "bold"),
                    padding=(4, 3), relief="flat", borderwidth=0)
        s.map("Panel.TButton",
              background=[("active", t["card"]), ("pressed", t["card"])],
              foreground=[("disabled", muted)])
        s.configure("Run.TButton", background=accent,
                    foreground=t["accent_fg"],
                    font=font("action", "bold"), padding=(16, 8))
        s.map("Run.TButton", background=[("disabled", t["disabled"]),
                                         ("active", accent)])
        s.configure("Stop.TButton", background=t["stop"],
                    foreground=t["accent_fg"],
                    font=font("action", "bold"), padding=(12, 8))
        s.configure("Exist.TButton", background=t["exist"],
                    foreground=t["accent_fg"],
                    font=font("tool"), padding=(10, 6))
        s.configure("TNotebook", background=bg, bordercolor=line)
        s.configure("TNotebook.Tab", padding=(14, 6))
        s.configure("TEntry", fieldbackground=card, foreground=fg,
                    insertcolor=fg, bordercolor=line, padding=4)
        s.configure("TCombobox", fieldbackground=card, foreground=fg,
                    bordercolor=line, padding=3)
        # The `clam` theme paints a readonly combobox through the Combobox.field
        # element, which ignores the plain `fieldbackground` option above and
        # kept the default (near-black) -- leaving dark-on-dark text in every
        # theme except Light. The readonly state has to be mapped explicitly.
        s.map("TCombobox",
              fieldbackground=[("readonly", card), ("disabled", card)],
              foreground=[("readonly", fg), ("disabled", muted)],
              selectbackground=[("readonly", card)],
              selectforeground=[("readonly", fg)],
              bordercolor=[("focus", accent), ("!focus", line)],
              arrowcolor=[("readonly", fg), ("disabled", muted)])
        s.map("TEntry",
              fieldbackground=[("disabled", card)],
              foreground=[("disabled", muted)],
              bordercolor=[("focus", accent), ("!focus", line)])
        s.configure("TCheckbutton", background=bg, foreground=fg)
        s.map("TCheckbutton", background=[("active", bg)])
        self.option_add("*TCombobox*Listbox.background", card)
        self.option_add("*TCombobox*Listbox.foreground", fg)

        if hasattr(self, "log"):
            self.log.config(bg=t["log_bg"], fg=t["log_fg"],
                            highlightbackground=t["log_line"],
                            insertbackground=t["log_fg"])
            for tag, col in t["tags"].items():
                self.log.tag_configure(tag, foreground=col)
        if hasattr(self, "preview"):
            self.preview.config(bg=t["pv_bg"], fg=t["pv_fg"])
            self.preview.tag_configure("k", foreground=t["pv_key"])
            self.preview.tag_configure("s", foreground=t["pv_muted"])
            self.preview.tag_configure("v", foreground=t["pv_fg"])
        if hasattr(self, "cal"):
            self.cal.set_theme(t["cal"])
        for sf in getattr(self, "_scrollframes", []):
            sf.set_theme(t)

    def _set_font_step(self, step: str):
        """Change the global font scale and repaint every widget.

        ttk styles refresh automatically once _apply_theme() re-runs, but the
        tk.Text widgets and the calendar's day cells were handed a concrete
        font tuple at construction, so they are re-pointed here too.
        See UI-WORKLOG.md D-13.
        """
        step = _set_font_scale(step)
        self._font_step = step
        self._apply_theme()                    # refreshes all ttk styles
        if hasattr(self, "preview"):
            self.preview.config(font=mono("preview"))
        if hasattr(self, "log"):
            self.log.config(font=mono("log"))
        if hasattr(self, "cal"):
            self.cal._build_geometry()          # re-measure for the new size
            self.cal.render()
        if hasattr(self, "hint1"):
            self.hint1.config(wraplength=cal_w())
        if hasattr(self, "hint2"):
            self.hint2.config(wraplength=cal_w() + 150)
        self.update_idletasks()
        if hasattr(self, "font_var"):
            self.font_var.set(step)
        self._save_ui_prefs()
        return step

    def _load_ui_prefs(self):
        """Read theme + font step, tolerating a missing or corrupt file."""
        theme, step = DEFAULT_THEME, DEFAULT_FONT_STEP
        cal_c = pv_c = False
        try:
            raw = (config_dir() / "ui.cfg").read_text(encoding="utf-8")
            for line in raw.splitlines():
                k, _, v = line.partition("=")
                v = v.strip()
                if k.strip() == "theme" and v in THEMES:
                    theme = v
                elif k.strip() == "font" and v in FONT_STEPS:
                    step = v
                elif k.strip() == "calendar" and v in ("0", "1"):
                    cal_c = v == "1"
                elif k.strip() == "preview" and v in ("0", "1"):
                    pv_c = v == "1"
        except OSError:
            pass
        return theme, step, cal_c, pv_c

    def _save_ui_prefs(self):
        try:
            (config_dir() / "ui.cfg").write_text(
                f"theme={self._theme}\nfont={self._font_step}\n"
                # NB: must be written as 0/1 -- str(True) is "True", which
                # the loader (and any hand edit) would not read back.
                f"calendar={int(bool(self._cal_collapsed))}\n"
                f"preview={int(bool(self._preview_collapsed))}\n",
                encoding="utf-8")
        except OSError:
            pass

    def _on_panel_toggle(self, _collapsed):
        """A collapse/expand changed the layout -- re-save and repaint."""
        self._save_ui_prefs()
        self.update_idletasks()

    def _sync_topbar(self):
        """Reflect a change made in Settings back into the top-bar pickers."""
        if hasattr(self, "theme_var"):
            self.theme_var.set(self._theme)
        if hasattr(self, "font_var"):
            self.font_var.set(self._font_step)
        if hasattr(self, "_set_theme_combo"):
            self._set_theme_combo.set(self._theme)
        if hasattr(self, "_set_font_combo"):
            self._set_font_combo.set(self._font_step)

    def _toggle_dark(self):
        """Cycle to the next theme in THEMES order."""
        names = list(THEME_ORDER)
        i = names.index(self._theme) if self._theme in names else 0
        self._set_theme(names[(i + 1) % len(names)])

    @staticmethod
    def _load_theme() -> str:
        """Back-compat shim: older installs stored just a theme name."""
        try:
            p = config_dir() / "theme.cfg"
            name = p.read_text(encoding="utf-8").strip()
            if name in THEMES:
                return name
        except OSError:
            pass
        return DEFAULT_THEME

    def _set_theme(self, name: str):
        if name not in THEMES:
            return
        self._theme = name
        self._apply_theme()
        if hasattr(self, "theme_var"):
            self.theme_var.set(name)
        self._save_ui_prefs()

    # ── layout ─────────────────────────────────────────────
    def _build_ui(self):
        root = ttk.Frame(self)
        root.pack(fill="both", expand=True)

        # NOTE: v0.4 drew a large teal banner repeating the window title, which
        # cost roughly 90px of vertical space -- the axis this layout is short
        # on. The title bar already carries the name, so the banner is gone.
        # See UI-WORKLOG.md D-02.
        top = ttk.Frame(root, padding=(10, 7))
        top.pack(fill="x")
        ttk.Label(top, text=APP_SUBTITLE, style="Sub.TLabel").pack(side="left")

        # Theme picker. A dropdown rather than the old single Dark/Light
        # toggle, because a toggle cannot express "more than two themes" and
        # hides what is available. See UI-WORKLOG.md D-09.
        ttk.Label(top, text="Theme:").pack(side="right", padx=(10, 4))
        self.theme_var = tk.StringVar(value=self._theme)
        tcb = ttk.Combobox(top, textvariable=self.theme_var, state="readonly",
                           width=15, values=list(THEME_ORDER))
        tcb.pack(side="right")
        tcb.bind("<<ComboboxSelected>>",
                 lambda e: self._set_theme(self.theme_var.get()))
        self.dark_btn = ttk.Button(top, text="Cycle", style="Tool.TButton",
                                   command=self._toggle_dark)
        self.dark_btn.pack(side="right", padx=(0, 8))

        # Font size picker. "Bigger" is not one number -- it depends on the
        # user's DPI and screen, so the size is a setting rather than a guess.
        # See UI-WORKLOG.md D-13.
        ttk.Label(top, text="Text:").pack(side="right", padx=(10, 4))
        self.font_var = tk.StringVar(value=self._font_step)
        fcb = ttk.Combobox(top, textvariable=self.font_var, state="readonly",
                           width=8, values=list(FONT_STEPS))
        fcb.pack(side="right")
        fcb.bind("<<ComboboxSelected>>",
                 lambda e: self._set_font_step(self.font_var.get()))

        body = ttk.Frame(root, padding=(10, 0, 10, 6))
        body.pack(fill="both", expand=True)
        nb = ttk.Notebook(body)
        self.nb = nb
        nb.pack(fill="both", expand=True)
        nb.add(self._tab_download(), text="  Download  ")
        nb.add(self._tab_presets(), text="  Presets  ")
        nb.add(self._tab_settings(), text="  Settings  ")

        self.status = ttk.Label(root, text="Ready", style="Status.TLabel",
                                anchor="w")
        self.status.pack(fill="x", side="bottom")

    def _tab_download(self):
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True)

        # The action bar is packed FIRST and lives OUTSIDE the scroll area, so
        # it keeps its space no matter how large the text is. It used to sit
        # inside the scrolling body, which meant at the "Large" font step the
        # content overflowed and Submit was scrolled out of sight -- the one
        # control that must never be hidden. See UI-WORKLOG.md D-14.
        bar = ttk.Frame(outer)
        bar.pack(side="bottom", fill="x", padx=10, pady=(2, 6))
        self.run_btn = ttk.Button(bar, text="Submit & Download",
                                  style="Run.TButton", command=self._run)
        self.run_btn.pack(side="left")
        self.stop_btn = ttk.Button(bar, text="Stop", style="Stop.TButton",
                                   command=self._stop, state="disabled")
        self.stop_btn.pack(side="left", padx=6)
        self.exist_btn = ttk.Button(bar, text="Download Existing",
                                    style="Exist.TButton",
                                    command=self._run_existing)
        self.exist_btn.pack(side="left")
        ttk.Button(bar, text="Save as Preset", style="Tool.TButton",
                   command=self._save_preset).pack(side="right")
        ttk.Button(bar, text="Generate Request", style="Tool.TButton",
                   command=self._generate_request).pack(side="right", padx=4)

        sf = ScrollFrame(outer)
        sf.pack(fill="both", expand=True)
        self._scrollframes.append(sf)
        f = sf.body
        # NOTE: these two lines previously read
        #     f.columnconfigure(0, weight=3, uniform="c")
        #     f.columnconfigure(1, weight=2, uniform="c")
        # With the same `uniform` group, tkinter forces the columns EQUAL and
        # ignores `weight` entirely -- so the intended 3:2 split silently
        # became 1:1, which is what starved the right-hand column. Now only
        # `minsize` constrains each column and `weight` does the dividing.
        f.columnconfigure(0, weight=5, minsize=520)   # left  : calendar + vars
        f.columnconfigure(1, weight=3, minsize=400)   # right : spatial + output

        # ── row 0: dataset + year (single compact strip) ──
        top = ttk.LabelFrame(f, text="Dataset & Year", padding=8)
        top.grid(row=0, column=0, columnspan=2, sticky="ew", pady=(0, 6))
        self.ds_combo = ttk.Combobox(top, state="readonly",
                                     values=[DATASETS[k]["label"] for k in DATASETS])
        self.ds_combo.current(0)
        self.ds_combo.bind("<<ComboboxSelected>>", self._on_dataset_changed)
        self.ds_combo.pack(side="left", fill="x", expand=True, padx=(0, 12))
        ttk.Label(top, text="Year(s):").pack(side="left")
        self.year_var = tk.StringVar(value="2005")
        ye = ttk.Entry(top, textvariable=self.year_var, width=13)
        ye.pack(side="left", padx=5)
        self.year_var.trace_add("write", lambda *_: self._auto_update_target())
        ttk.Button(top, text="Pick", style="Tool.TButton",
                   command=self._pick_years).pack(side="left")

        # ── left column ──
        left = ttk.Frame(f)
        left.grid(row=1, column=0, sticky="nsew", padx=(0, 6))

        # date range + calendar
        dr = ttk.LabelFrame(left, text="Date Range", padding=8)
        self.dr_frame = dr
        dr.pack(fill="x", pady=(0, 6))

        cbar = ttk.Frame(dr)
        cbar.pack(fill="x", pady=(0, 4))
        # Labelled + preselected: as an unlabelled combo with no default it
        # rendered blank and its purpose was invisible. See UI-WORKLOG.md D-04.
        ttk.Label(cbar, text="Season:").pack(side="left", padx=(0, 4))
        self.season_var = tk.StringVar(value="All year")
        sc = ttk.Combobox(cbar, textvariable=self.season_var, state="readonly",
                          width=11, values=list(SEASON_PRESETS))
        sc.pack(side="left")
        sc.bind("<<ComboboxSelected>>", lambda e: self._apply_season())
        ttk.Button(cbar, text="Apply", style="Tool.TButton",
                   command=self._apply_season).pack(side="left", padx=4)
        ttk.Button(cbar, text="Clear", style="Tool.TButton",
                   command=self._clear_dates).pack(side="left")
        ttk.Button(cbar, text="Advanced months/days...",
                   style="Tool.TButton",
                   command=self._advanced_dates).pack(side="right")

        # Two columns inside the Date Range panel. The calendar needs only
        # ~244px while the left column is far wider, and that leftover width
        # used to be dead space. It now carries a request preview built from
        # the engine's own build_payload(), so it shows exactly what will be
        # submitted and cannot drift from reality.
        #
        # Both sides are collapsible (D-19): the calendar is only needed while
        # picking dates, and the preview only while composing a request.
        drow = ttk.Frame(dr)
        drow.pack(fill="x", pady=(2, 0))

        lcol = ttk.Frame(drow)
        lcol.pack(side="left", fill="y")

        self.cal_panel = CollapsePanel(
            lcol, "Calendar", collapsed=self._cal_collapsed,
            on_toggle=self._on_panel_toggle)
        self.cal_panel.pack(side="left", fill="y")
        self.cal = MonthCalendar(self.cal_panel.inner, year=2005,
                                 on_change=self._on_cal_change)
        self.cal.pack(anchor="w")
        self.range_lbl = ttk.Label(lcol, text="", style="Hint.TLabel",
                                   wraplength=cal_w() + 60)
        self.range_lbl.pack(anchor="w", pady=(4, 0))
        self.hint1 = self.range_lbl

        pv = CollapsePanel(drow, "Request preview",
                           collapsed=self._preview_collapsed,
                           on_toggle=self._on_panel_toggle)
        self._pv_panel = pv
        pv.pack(side="left", fill="both", expand=True, padx=(12, 0))
        pvw = ttk.Frame(pv.inner)
        pvw.pack(fill="both", expand=True)
        # wrap="word": at larger font steps a payload line is wider than the
        # panel, and wrap="none" silently clipped it mid-token.
        self.preview = tk.Text(pvw, height=9, wrap="word", relief="flat",
                               font=mono("preview"), borderwidth=0,
                               background=THEMES[self._theme]["pv_bg"],
                               foreground=THEMES[self._theme]["pv_fg"],
                               highlightthickness=0,
                               insertbackground=THEMES[self._theme]["pv_fg"])
        self.preview.pack(side="left", fill="both", expand=True)
        self._pv_sb = ttk.Scrollbar(pvw, orient="vertical",
                                    command=self.preview.yview)
        self._pv_sb.pack(side="right", fill="y")
        self.preview.configure(yscrollcommand=self._pv_sb.set)
        self.preview.tag_configure("k", foreground="#0a5a60")
        self.preview.tag_configure("s", foreground="#6c757d")
        self.preview.tag_configure("v", foreground="#212529")

        # variables
        vf = ttk.LabelFrame(left, text="Variables", padding=8)
        self.var_frame = vf
        vf.pack(fill="x", pady=(0, 6))
        vrow = ttk.Frame(vf)
        vrow.pack(fill="x")
        ttk.Button(vrow, text="Select All", style="Tool.TButton",
                   command=self._sel_all_vars).pack(side="left")
        ttk.Button(vrow, text="Clear", style="Tool.TButton",
                   command=self._clear_vars).pack(side="left", padx=4)
        ttk.Button(vrow, text="Choose...", style="Tool.TButton",
                   command=self._pick_vars).pack(side="left")
        self.var_lbl = ttk.Label(vf, text="None selected", style="Hint.TLabel",
                                 wraplength=cal_w() + 150)
        self.var_lbl.pack(anchor="w", pady=(3, 0))
        self.hint2 = self.var_lbl

        # pressure
        self.prl_frame = ttk.LabelFrame(left, text="Pressure Levels", padding=8)
        self.prl_frame.pack(fill="x")
        prow = ttk.Frame(self.prl_frame)
        prow.pack(fill="x")
        self.prl_lbl = ttk.Label(prow, text="None selected",
                                 style="Hint.TLabel")
        self.prl_lbl.pack(side="left")
        ttk.Button(prow, text="Choose Levels...", style="Tool.TButton",
                   command=self._pick_pressure).pack(side="right")

        # ── right column ──
        right = ttk.Frame(f)
        right.grid(row=1, column=1, sticky="nsew")

        bb = ttk.LabelFrame(right, text="Spatial Domain", padding=8)
        self.bbox_frame = bb
        bb.pack(fill="x", pady=(0, 6))
        top2 = ttk.Frame(bb)
        top2.pack(fill="x", pady=(0, 4))
        ttk.Label(top2, text="Region:").pack(side="left")
        self.region_var = tk.StringVar(value="India")
        rc = ttk.Combobox(top2, textvariable=self.region_var, state="readonly",
                          width=9, values=[*REGION_PRESETS, "Custom"])
        rc.pack(side="left", padx=5)
        rc.bind("<<ComboboxSelected>>", lambda e: self._apply_region())
        ttk.Button(top2, text="Reset", style="Tool.TButton",
                   command=self._reset_bbox).pack(side="left")

        brow = ttk.Frame(bb)
        brow.pack(fill="x")
        self.bbox = {}
        # Laid out 2x2 rather than 1x4. A single row of label+entry pairs set
        # the right column's minimum width high enough that the whole grid
        # overflowed the window and W: was pushed off-screen entirely.
        # See UI-WORKLOG.md D-01.
        for i, (key, lbl, ph) in enumerate([("north", "N:", "45"),
                                            ("south", "S:", "-15"),
                                            ("east", "E:", "120"),
                                            ("west", "W:", "30")]):
            r, c = divmod(i, 2)
            ttk.Label(brow, text=lbl).grid(row=r, column=c * 2,
                                           sticky="w", padx=(8, 2), pady=2)
            var = tk.StringVar()
            self.bbox[key] = var
            ttk.Entry(brow, textvariable=var, width=9).grid(
                row=r, column=c * 2 + 1, sticky="ew", pady=2)
            brow.columnconfigure(c * 2 + 1, weight=1)

        # time (hourly datasets only)
        self.time_frame = ttk.LabelFrame(right, text="Time (UTC)", padding=8)
        self.time_frame.pack(fill="x", pady=(0, 6))
        self.time_lbl = ttk.Label(self.time_frame, text="All",
                                  style="Hint.TLabel")
        self.time_lbl.pack(side="left")
        ttk.Button(self.time_frame, text="Choose...", style="Tool.TButton",
                   command=self._pick_times).pack(side="right")

        # forecast lead (S2S only)
        self.fc_frame = ttk.LabelFrame(right, text="Forecast Lead (S2S)",
                                       padding=8)
        self.fc_frame.pack(fill="x", pady=(0, 6))
        frow = ttk.Frame(self.fc_frame)
        frow.pack(fill="x")
        ttk.Label(frow, text="Init day").pack(side="left")
        self._fc_var = tk.StringVar(value="01")
        self._fc_combo = ttk.Combobox(frow, state="readonly", width=4,
                                      values=["01"],
                                      textvariable=self._fc_var)
        self._fc_combo.pack(side="left", padx=(4, 12))
        self.fc_lbl = ttk.Label(frow, text="", style="Hint.TLabel")
        self.fc_lbl.pack(side="left")
        ttk.Button(frow, text="Choose Leads...", style="Tool.TButton",
                   command=self._pick_forecast).pack(side="right")

        # output
        ob = ttk.LabelFrame(right, text="Output", padding=8)
        self.output_frame = ob
        ob.pack(fill="x")
        ttk.Label(ob, text="Folder:").pack(anchor="w")
        drow = ttk.Frame(ob)
        drow.pack(fill="x")
        self.dl_var = tk.StringVar(value=str(self._default_dl_dir()))
        ttk.Entry(drow, textvariable=self.dl_var).pack(side="left", fill="x",
                                                      expand=True)
        ttk.Button(drow, text="...", width=3, style="Tool.TButton",
                   command=self._browse_dir).pack(side="left", padx=(4, 0))
        ttk.Label(ob, text="Target:").pack(anchor="w", pady=(4, 0))
        self.tgt_var = tk.StringVar()
        ttk.Entry(ob, textvariable=self.tgt_var).pack(fill="x")
        self.tgt_hint = ttk.Label(ob, text="", style="Hint.TLabel",
                                  wraplength=250)
        self.tgt_hint.pack(anchor="w", pady=(3, 0))

        # The log is pinned BELOW the action bar, outside the scroll area, so it is
        # always visible at full size. Inside the scroll area a 16-row log was
        # pushed below the fold -- a large log that cannot be seen is not large.
        # It also packs before the scroll frame so it keeps its height.
        # See UI-WORKLOG.md D-18.
        lf = ttk.LabelFrame(outer, text="Job Log", padding=8)
        lf.pack(side="bottom", fill="x", padx=10, pady=(0, 6))
        lt = ttk.Frame(lf)
        lt.pack(fill="x", pady=(0, 3))
        ttk.Button(lt, text="Copy", style="Tool.TButton",
                   command=self._copy_log).pack(side="right")
        ttk.Button(lt, text="Clear", style="Tool.TButton",
                   command=self._clear_log).pack(side="right", padx=4)

        wrap = tk.Frame(lf)
        wrap.pack(fill="both", expand=True)
        t = THEMES[self._theme]
        self._log_sb = ttk.Scrollbar(wrap, style="RDS.Vertical.TScrollbar")
        self._log_sb.pack(side="right", fill="y")
        self.log = tk.Text(wrap, height=6, wrap="word", state="disabled",
                           font=mono("log"),
                           bg=t["log_bg"], fg=t["log_fg"], relief="flat",
                           highlightthickness=1,
                           highlightbackground=t["log_line"],
                           insertbackground=t["log_fg"])
        self.log.pack(side="left", fill="both", expand=True)
        self._log_sb.config(command=self.log.yview)
        self.log.configure(yscrollcommand=self._log_sb.set)
        for tag, col in t["tags"].items():
            self.log.tag_configure(tag, foreground=col)
        return outer

    def _tab_presets(self):
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True)
        # Scrollable: at the larger font steps this page can exceed the
        # notebook area, and without this its lower controls would be
        # unreachable. See UI-WORKLOG.md D-15.
        sf = ScrollFrame(outer)
        sf.pack(fill="both", expand=True)
        self._scrollframes.append(sf)
        f = sf.body
        ttk.Label(f, text="Save and load your download configurations",
                  style="Hint.TLabel").pack(anchor="w", pady=(0, 8))
        lf = ttk.LabelFrame(f, text="Saved Presets", padding=8)
        lf.pack(fill="both", expand=True)
        cols = ("name", "dataset", "years", "variables")
        self.preset_tree = ttk.Treeview(lf, columns=cols, show="headings",
                                        selectmode="browse", height=12)
        for c, t, w in zip(cols, ("Preset Name", "Dataset", "Years", "Variables"),
                           (170, 180, 140, 250)):
            self.preset_tree.heading(c, text=t)
            self.preset_tree.column(c, width=w, anchor="w")
        sb = ttk.Scrollbar(lf, command=self.preset_tree.yview)
        self.preset_tree.configure(yscrollcommand=sb.set)
        self.preset_tree.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=8)
        ttk.Button(bar, text="Load Selected", style="Exist.TButton",
                   command=self._load_preset).pack(side="left")
        ttk.Button(bar, text="Delete Selected", style="Stop.TButton",
                   command=self._delete_preset).pack(side="left", padx=6)
        return outer

    def _tab_settings(self):
        outer = ttk.Frame(self)
        outer.pack(fill="both", expand=True)
        # Scrollable for the same reason as the Presets tab (D-15).
        sf = ScrollFrame(outer)
        sf.pack(fill="both", expand=True)
        self._scrollframes.append(sf)
        pad = ttk.Frame(sf.body, padding=10)
        pad.pack(fill="both", expand=True)
        f = pad

        # Appearance -- mirrored from the Download tab's top bar so the
        # settings are discoverable in both places.
        af = ttk.LabelFrame(f, text="Appearance", padding=10)
        af.pack(fill="x", pady=(0, 8))
        ttk.Label(af, text="Theme:").grid(row=0, column=0, sticky="w", pady=4)
        s_theme = tk.StringVar(value=self._theme)
        self._set_theme_combo = ttk.Combobox(
            af, textvariable=s_theme, state="readonly", width=16,
            values=list(THEME_ORDER))
        self._set_theme_combo.grid(row=0, column=1, sticky="w", padx=8)
        self._set_theme_combo.bind(
            "<<ComboboxSelected>>",
            lambda e: (self._set_theme(s_theme.get()), self._sync_topbar()))

        ttk.Label(af, text="Text size:").grid(row=1, column=0, sticky="w",
                                              pady=4)
        s_font = tk.StringVar(value=self._font_step)
        self._set_font_combo = ttk.Combobox(
            af, textvariable=s_font, state="readonly", width=16,
            values=list(FONT_STEPS))
        self._set_font_combo.grid(row=1, column=1, sticky="w", padx=8)
        self._set_font_combo.bind(
            "<<ComboboxSelected>>",
            lambda e: (self._set_font_step(s_font.get()), self._sync_topbar()))

        ttk.Label(af, style="Hint.TLabel",
                  text="Changes apply immediately and are remembered.").grid(
            row=2, column=0, columnspan=2, sticky="w", pady=(6, 0))

        cf = ttk.LabelFrame(f, text="Credentials", padding=10)
        cf.pack(fill="x", pady=(0, 8))
        ttk.Label(cf, text="Email:").grid(row=0, column=0, sticky="w", pady=4)
        self.email_var = tk.StringVar()
        ttk.Entry(cf, textvariable=self.email_var).grid(row=0, column=1,
                                                       sticky="ew", padx=8)
        ttk.Label(cf, text="Password:").grid(row=1, column=0, sticky="w", pady=4)
        self.pass_var = tk.StringVar()
        ttk.Entry(cf, textvariable=self.pass_var, show="*").grid(
            row=1, column=1, sticky="ew", padx=8)
        ttk.Button(cf, text="Save", style="Exist.TButton",
                   command=self._save_credentials).grid(row=0, column=2,
                                                        rowspan=2, padx=8)
        cf.columnconfigure(1, weight=1)

        of = ttk.LabelFrame(f, text="Existing Jobs Folder", padding=10)
        of.pack(fill="x", pady=(0, 8))
        self.existing_var = tk.StringVar(
            value=str(self._default_dl_dir() / "existing"))
        ttk.Entry(of, textvariable=self.existing_var).pack(
            side="left", fill="x", expand=True)
        ttk.Button(of, text="Browse", style="Tool.TButton",
                   command=self._browse_existing).pack(side="left", padx=6)

        lf = ttk.LabelFrame(f, text="Local Files", padding=10)
        lf.pack(fill="x", pady=(0, 8))
        self.path_lbl = ttk.Label(lf, text="", style="Hint.TLabel",
                                  wraplength=760)
        self.path_lbl.pack(anchor="w")
        ttk.Button(lf, text="Open Config Folder", style="Tool.TButton",
                   command=self._open_config_dir).pack(anchor="w", pady=(6, 0))

        af = ttk.LabelFrame(f, text="About", padding=10)
        af.pack(fill="x")
        ttk.Label(af, wraplength=760, anchor="w", justify="left",
                  text=("NCMRWF RDS Downloader v0.5 (Windows / tkinter)\n"
                        "Copyright Subhrajit Rath\n\n"
                        "The download engine is built in — bash, curl and jq are\n"
                        "NOT required on this machine.\n\n"
                        f"Theme            : {self._theme} (change it top-right)\n\n"
                        f"Config & presets : {config_dir()}\n"
                        f"Credentials      : {Path.home() / '.ncmrwfapirc'}\n"
                        f"Job log          : {config_dir() / 'submitted_jobs.log'}")
                  ).pack(anchor="w")
        self._refresh_paths()
        return outer

    # ── helpers ────────────────────────────────────────────
    @staticmethod
    def _default_dl_dir() -> Path:
        # From the source tree the sibling "downloads" folder is the natural
        # default.  In a frozen build __file__ lives in PyInstaller's temporary
        # extraction directory, so that heuristic would resolve to
        # %TEMP%\downloads -- never what anyone wants.  An installed package
        # (e.g. /usr/lib/rds-downloader) is not writable there either, hence the
        # writability test.
        if not getattr(sys, "frozen", False):
            local = Path(__file__).resolve().parent.parent / "downloads"
            if local.is_dir() and os.access(local, os.W_OK):
                return local
        return Path.home() / "Downloads" / "rds_data"

    def _ds_key(self) -> str:
        # current() is -1 when nothing is selected; `-1 or 0` is -1, which would
        # silently index the LAST dataset. Clamp instead.
        idx = self.ds_combo.current()
        return list(DATASETS)[idx if idx >= 0 else 0]

    # ── dataset / tags ─────────────────────────────────────
    def _on_dataset_changed(self, _e=None):
        self._refresh_dataset_fields()
        self._auto_update_target()

    def _refresh_dataset_fields(self):
        ds = self._ds_key()
        cfg = DATASETS[ds]

        # Re-pack both columns in a fixed, deterministic order so switching
        # datasets can never scramble the layout.
        for w in (self.prl_frame, self.time_frame, self.fc_frame):
            w.pack_forget()

        self.dr_frame.pack(fill="x", pady=(0, 6))
        self.var_frame.pack(fill="x", pady=(0, 6))
        if cfg["pressure"]:
            self.prl_frame.pack(fill="x", pady=(0, 6))
        self.bbox_frame.pack(fill="x", pady=(0, 6))
        if cfg["time"]:
            self.time_frame.pack(fill="x", pady=(0, 6))
        if cfg.get("forecast"):
            self.fc_frame.pack(fill="x", pady=(0, 6))
        self.output_frame.pack(fill="x")

        years = list(cfg["years"])
        self.cal.set_year_range(min(years), max(years))
        self._sel_vars = []
        self._sel_pressure = []
        self._sel_times = list(TIME_ALL.get(ds, []))
        fc = FORECAST_DAYS.get(ds) or []
        self._sel_forecast = fc[:1]
        self._init_day = (INIT_DAYS.get(ds) or ["01"])[0]
        if self._fc_combo.winfo_exists():
            self._fc_combo["values"] = (INIT_DAYS.get(ds) or ["01"])
            self._fc_combo.set(self._init_day)
        self._reset_bbox_to_dataset()
        self._update_tags()
        self._update_range_hint()

    def _reset_bbox_to_dataset(self):
        """Each dataset ships its own natural domain (ocean is 0-360, S2S is
        global, MERA is India-only). Adopt it whenever the dataset changes."""
        d = DATASETS[self._ds_key()]["bbox"]
        self.region_var.set("Custom")
        for k in ("north", "south", "east", "west"):
            self.bbox[k].set(str(d[k]))

    def _update_tags(self):
        nv = len(self._sel_vars)
        self.var_lbl.config(text="None selected" if nv == 0 else
                            (", ".join(self._sel_vars) if nv <= 5
                             else f"{nv} variables selected"))
        npv = len(self._sel_pressure)
        self.prl_lbl.config(text="None selected" if npv == 0 else
                            (", ".join(self._sel_pressure) if npv <= 5
                             else f"{npv} levels selected"))
        all_t = TIME_ALL.get(self._ds_key(), [])
        nt = len(self._sel_times)
        self.time_lbl.config(text="All" if nt == len(all_t) else
                             (", ".join(self._sel_times) if nt <= 8
                              else f"{nt} hours"))
        nf = len(self._sel_forecast)
        self.fc_lbl.config(text="none" if nf == 0 else
                           (", ".join(self._sel_forecast) if nf <= 4
                            else f"{nf} lead days"))
        self._update_preview()

    def _update_preview(self):
        """Show the exact request_payload that will be submitted.

        Built with the engine's own build_payload(), so what is displayed is
        what is sent -- including the dataset-specific quirks (no `day` for
        S2S, bare-number pressure levels, etc.). Formatting is compacted so
        long month/day lists stay readable.
        """
        if not hasattr(self, "preview"):
            return
        ds = self._ds_key()
        try:
            bbox = {k: float(v.get().strip())
                    if v.get().strip() else float(DATASETS[ds]["bbox"][k])
                    for k, v in self.bbox.items()}
            years = parse_years(self.year_var.get()) or ["?"]
            _label, payload = build_payload(
                ds, years[0], self._sel_months, self._sel_days,
                self._sel_times if DATASETS[ds]["time"] else None,
                bbox, self._sel_vars, self._sel_pressure,
                init_day=self._init_day, forecast_days=self._sel_forecast)
            rp = dict(payload["request_payload"])
        except Exception as exc:                      # never break the UI
            self.preview.delete("1.0", "end")
            self.preview.insert("1.0", f"(preview unavailable: {exc})", "s")
            return

        # collapse long parallel arrays so the preview stays a readable size
        def short(v):
            if isinstance(v, list) and len(v) > 8:
                return f"[{len(v)} values: {v[0]} … {v[-1]}]"
            return v

        lines = []
        for k, v in rp.items():
            lines.append((f'  "{k}":', short(v)))
        self.preview.delete("1.0", "end")
        self.preview.insert("1.0", "request_payload\n", "k")
        for k, v in lines:
            self.preview.insert("end", k, "k")
            self.preview.insert("end", " " + repr(v).replace("'", '"') + "\n", "v")

    def _update_range_hint(self):
        a, b = self.cal.get_range()
        m, d = len(self._sel_months), len(self._sel_days)
        mtxt = "all 12 months" if m == 12 else f"{m} month(s)"
        dtxt = "all 31 days" if d == 31 else f"{d} day(s)"
        if a and b and a != b:
            self.range_lbl.config(
                text=f"{a:%d %b %Y} → {b:%d %b %Y}   |   "
                     f"requesting {mtxt} × {dtxt}")
        elif a and b:
            self.range_lbl.config(
                text=f"{a:%d %b %Y}   |   requesting {mtxt} × {dtxt}")
        else:
            self.range_lbl.config(text=f"requesting {mtxt} × {dtxt}")

        if not DATASETS[self._ds_key()].get("day", True):
            self.range_lbl.config(text=self.range_lbl.cget("text") +
                                  "\n(this dataset has no day-of-month — "
                                  "whole months are requested)")

    # ── calendar / dates ───────────────────────────────────
    def _calendar_year(self) -> int:
        years = parse_years(self.year_var.get())
        if years:
            return int(years[0])
        cfg = DATASETS[self._ds_key()]["years"]
        return min(cfg)

    def _on_cal_change(self, rng):
        a, b = rng
        if a is None:
            self._sel_months = [m[0] for m in MONTHS]
            self._sel_days = DAYS[:]
        else:
            try:
                self._sel_months, self._sel_days = dates_to_months_days(a, b)
            except ValueError as e:
                self._log(str(e), "warn")
                self.cal.clear()
                return
        self._update_tags()
        self._update_range_hint()

    def _apply_season(self):
        months = SEASON_PRESETS.get(self.season_var.get())
        if not months:
            return
        self._sel_months = list(months)
        self._sel_days = DAYS[:]
        a, b = months_to_dates_anchor(self._calendar_year(), months)
        self.cal.set_range(a, b)
        self._update_tags()
        self._update_range_hint()

    def _clear_dates(self):
        self.cal.clear()
        self._sel_months = [m[0] for m in MONTHS]
        self._sel_days = DAYS[:]
        self._update_tags()
        self._update_range_hint()

    def _advanced_dates(self):
        res = SelectAllDialog.ask(
            self, "Select Months", [m[0] for m in MONTHS], self._sel_months,
            columns=6, labels={v: f"{v} {n[:3]}" for v, n in MONTHS})
        if res is None:
            return
        self._sel_months = res or [m[0] for m in MONTHS]
        res = SelectAllDialog.ask(self, "Select Days", DAYS,
                                  self._sel_days, columns=8)
        if res is not None:
            self._sel_days = res or DAYS[:]
        self.cal.clear()
        self._update_tags()
        self._update_range_hint()

    # ── pickers ────────────────────────────────────────────
    def _pick_years(self):
        dlg = YearPicker(self, list(DATASETS[self._ds_key()]["years"]),
                         self.year_var.get())
        self.wait_window(dlg)
        if dlg.result is not None:
            self.year_var.set(dlg.result)
            self.cal.year = self._calendar_year()
            self.cal.render()
            self._apply_season()

    def _pick_times(self):
        avail = TIME_ALL.get(self._ds_key(), [])
        res = SelectAllDialog.ask(self, "Select Times (UTC)", avail,
                                  self._sel_times, columns=6)
        if res is not None:
            self._sel_times = res
            self._update_tags()

    def _pick_vars(self):
        avail = VARIABLES_BY_DATASET.get(self._ds_key(), [])
        res = SelectAllDialog.ask(self, "Select Variables", avail,
                                  self._sel_vars, columns=3)
        if res is not None:
            self._sel_vars = res
            self._update_tags()

    def _pick_forecast(self):
        avail = FORECAST_DAYS.get(self._ds_key(), [])
        labels = {d: ("T" if d == "day00" else f"T+{int(d[3:])}")
                  for d in avail}
        res = SelectAllDialog.ask(self, "Select Forecast Lead Days", avail,
                                  self._sel_forecast, columns=6, labels=labels)
        if res is not None:
            self._sel_forecast = res
            self._update_tags()

    def _pick_pressure(self):
        avail = PRESSURE_LEVELS_BY_DATASET.get(self._ds_key(), [])
        res = SelectAllDialog.ask(self, "Select Pressure Levels", avail,
                                  self._sel_pressure, columns=3)
        if res is not None:
            self._sel_pressure = res
            self._update_tags()

    def _sel_all_vars(self):
        self._sel_vars = list(VARIABLES_BY_DATASET.get(self._ds_key(), []))
        self._update_tags()

    def _clear_vars(self):
        self._sel_vars = []
        self._update_tags()

    def _apply_region(self):
        name = self.region_var.get()
        if name in REGION_PRESETS:
            n, s, e, w = REGION_PRESETS[name]
            self.bbox["north"].set(str(n))
            self.bbox["south"].set(str(s))
            self.bbox["east"].set(str(e))
            self.bbox["west"].set(str(w))

    def _reset_bbox(self):
        self.region_var.set("India")
        self._apply_region()

    def _auto_update_target(self, *_):
        ds = self._ds_key()
        years = parse_years(self.year_var.get())
        dl = self.dl_var.get().strip() or str(self._default_dl_dir())
        if len(years) > 1:
            tgt = f"{ds}_{years[0]}-{years[-1]}_{{year}}.zip"
            self.tgt_hint.config(
                text=f"{len(years)} files:\n" +
                     "\n".join(self._elide_path(
                         str(Path(dl) / tgt.replace("{year}", y)))
                         for y in years[:6]) +
                     ("\n\u2026" if len(years) > 6 else ""))
        else:
            tgt = f"{ds}_{years[0] if years else '{year}'}.zip"
            self.tgt_hint.config(
                text=self._elide_path(str(Path(dl) / tgt)))
        self.tgt_var.set(tgt)

    @staticmethod
    def _elide_path(p: str, keep: int = 18) -> str:
        """Shorten a long path from the MIDDLE.

        A wrapped path used to break mid-token ("...\\rds_test\\downlo
        ads\\file.zip"), which is hard to read and easy to misread. Eliding
        the middle keeps the drive root and the filename both legible.
        """
        if len(p) <= keep + 26:
            return p
        return f"{p[:keep]} \u2026 {p[-26:]}"

    # ── browse ─────────────────────────────────────────────
    def _browse_dir(self):
        p = filedialog.askdirectory(title="Choose download directory",
                                    initialdir=self.dl_var.get() or str(Path.home()))
        if p:
            self.dl_var.set(p)
            self._auto_update_target()

    def _browse_existing(self):
        p = filedialog.askdirectory(title="Choose folder for existing jobs",
                                    initialdir=self.existing_var.get())
        if p:
            self.existing_var.set(p)

    def _open_config_dir(self):
        # Platform-neutral: os.startfile/explorer exist only on Windows, and on
        # Linux (the .deb build) both would raise.
        d = str(config_dir())
        try:
            if os.name == "nt":
                os.startfile(d)               # noqa: S606
            elif sys.platform == "darwin":
                subprocess.Popen(["open", d])
            else:
                subprocess.Popen(["xdg-open", d],
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL)
        except Exception:
            pass

    # ── credentials ────────────────────────────────────────
    def _load_credentials(self):
        email, password = read_credentials()
        self.email_var.set(email)
        self.pass_var.set(password)

    def _save_credentials(self):
        try:
            write_credentials(self.email_var.get().strip(),
                              self.pass_var.get().strip())
            self._log("Credentials saved", "ok")
            self.status.config(text="Credentials saved")
        except Exception as e:
            messagebox.showerror("Error", f"Could not save credentials:\n{e}")

    # ── presets ────────────────────────────────────────────
    def _current_config(self):
        return {
            "dataset": self._ds_key(), "year": self.year_var.get().strip(),
            "months": self._sel_months, "days": self._sel_days,
            "times": self._sel_times, "variables": self._sel_vars,
            "pressure": self._sel_pressure,
            "forecast": self._sel_forecast,
            "init_day": self._fc_var.get().strip() or "01",
            "north": self.bbox["north"].get().strip(),
            "south": self.bbox["south"].get().strip(),
            "east": self.bbox["east"].get().strip(),
            "west": self.bbox["west"].get().strip(),
            "download_dir": self.dl_var.get().strip(),
            "target_file": self.tgt_var.get().strip(),
        }

    def _save_preset(self):
        name = simpledialog.askstring("Save Preset", "Preset name:",
                                      parent=self)
        if not name:
            return
        self._presets.save(name.strip(), self._current_config())
        self._log(f"Preset '{name.strip()}' saved", "ok")
        self._populate_presets()

    def _populate_presets(self):
        for i in self.preset_tree.get_children():
            self.preset_tree.delete(i)
        for name in self._presets.names():
            data = self._presets.load_one(name) or {}
            self.preset_tree.insert("", "end", values=(
                name, data.get("dataset", ""), data.get("year", ""),
                (", ".join(data.get("variables", [])) or "—")[:46]))

    def _selected_preset(self):
        sel = self.preset_tree.selection()
        if not sel:
            messagebox.showinfo("Presets", "Select a preset first.")
            return None
        return self.preset_tree.item(sel[0])["values"][0]

    def _load_preset(self):
        name = self._selected_preset()
        if not name:
            return
        cfg = self._presets.load_one(name)
        if not cfg:
            return
        ds = cfg.get("dataset", "")
        if ds in DATASETS:
            self.ds_combo.current(list(DATASETS).index(ds))
            self._refresh_dataset_fields()
        self.year_var.set(cfg.get("year", ""))
        self._sel_months = cfg.get("months") or [m[0] for m in MONTHS]
        self._sel_days = cfg.get("days") or DAYS[:]
        self._sel_times = cfg.get("times") or list(TIME_ALL.get(ds, []))
        self._sel_vars = cfg.get("variables", [])
        self._sel_pressure = cfg.get("pressure", [])
        fc = FORECAST_DAYS.get(ds) or []
        self._sel_forecast = cfg.get("forecast") or fc[:1]
        self._fc_var.set(cfg.get("init_day") or (INIT_DAYS.get(ds) or ["01"])[0])
        for k in ("north", "south", "east", "west"):
            self.bbox[k].set(cfg.get(k, ""))
        self.dl_var.set(cfg.get("download_dir", ""))
        self.tgt_var.set(cfg.get("target_file", ""))
        self.cal.clear()
        self._update_tags()
        self._update_range_hint()
        self._log(f"Preset '{name}' loaded", "ok")

    def _delete_preset(self):
        name = self._selected_preset()
        if not name:
            return
        if messagebox.askyesno("Delete preset", f"Delete preset '{name}'?"):
            self._presets.delete(name)
            self._populate_presets()
            self._log(f"Preset '{name}' deleted", "warn")

    # ── request ────────────────────────────────────────────
    def _gather(self):
        ds = self._ds_key()
        # strict=True: the year text flows into the job log and the output
        # filename, so reject anything that is not a 4-digit year.
        years = parse_years(self.year_var.get(), strict=True)
        if not years:
            raise ValueError("No year selected. Use 2005, 2000,2005 or 2000-2010.")
        valid = set(DATASETS[ds]["years"])
        bad = [y for y in years if int(y) not in valid]
        if bad:
            raise ValueError(
                f"Year(s) {', '.join(bad)} are outside the range for "
                f"{DATASETS[ds]['label']} ({min(valid)}-{max(valid)}).")

        bbox = {}
        for k, v in self.bbox.items():
            raw = v.get().strip()
            try:
                bbox[k] = float(raw) if raw else float(DATASETS[ds]["bbox"][k])
            except ValueError:
                bbox[k] = float(DATASETS[ds]["bbox"][k])
        if bbox["south"] >= bbox["north"]:
            raise ValueError("South must be lower than North.")
        if bbox["west"] >= bbox["east"]:
            raise ValueError("West must be lower than East.")

        target = self.tgt_var.get().strip()
        validate_target_template(target)

        return {
            "dataset": ds, "years": years,
            "months": self._sel_months, "days": self._sel_days,
            "times": self._sel_times if DATASETS[ds]["time"] else [],
            "bbox": bbox, "variables": list(self._sel_vars),
            "pressure": list(self._sel_pressure),
            "forecast": list(self._sel_forecast),
            "init_day": self._fc_var.get().strip() or "01",
            "target": target,
            "download_dir": self.dl_var.get().strip() or str(self._default_dl_dir()),
        }

    def _generate_request(self):
        try:
            g = self._gather()
        except ValueError as e:
            messagebox.showerror("Invalid request", str(e))
            return
        path = filedialog.asksaveasfilename(
            title="Save request.txt", defaultextension=".txt",
            initialfile="request.txt", filetypes=[("Text files", "*.txt")])
        if not path:
            return
        Path(path).write_text(self._request_text(g), encoding="utf-8")
        self._log(f"Request file saved: {path}", "ok")

    def _request_text(self, g):
        return build_request_text(
            g["dataset"], g["years"], g["months"], g["days"], g["times"],
            g["bbox"], g["variables"], g["pressure"],
            g["download_dir"], g["target"])

    # ── logging ────────────────────────────────────────────
    def _log(self, text, tag="info"):
        self._q.put(("log", text, tag))

    def _clear_log(self):
        self.log.config(state="normal")
        self.log.delete("1.0", "end")
        self.log.config(state="disabled")

    def _copy_log(self):
        self.clipboard_clear()
        self.clipboard_append(self.log.get("1.0", "end"))
        self.status.config(text="Log copied to clipboard")

    def _drain(self):
        try:
            while True:
                item = self._q.get_nowait()
                if item[0] == "log":
                    _, text, tag = item
                    self.log.config(state="normal")
                    self.log.insert("end", text + "\n", tag)
                    self.log.see("end")
                    self.log.config(state="disabled")
                elif item[0] == "status":
                    self.status.config(text=item[1])
                elif item[0] == "existing":
                    # Hold the fetched list; the picker opens on "done" so the
                    # fetch worker has fully returned before a new one starts.
                    self._pending_existing = item[1]
                elif item[0] == "done":
                    self._set_running(False)
                    self._open_pending_existing()
        except queue.Empty:
            pass
        self._drain_job = self.after(60, self._drain)

    # ── run ────────────────────────────────────────────────
    def _set_running(self, running: bool):
        state = "disabled" if running else "normal"
        self.run_btn.config(state=state)
        self.exist_btn.config(state=state)
        self.stop_btn.config(state="normal" if running else "disabled")

    def _make_client(self) -> RDSClient:
        email, password = read_credentials()
        email = email or self.email_var.get().strip()
        password = password or self.pass_var.get().strip()
        return RDSClient(email, password, log=self._log,
                         job_log=self._job_log, stop_event=self._stop_event)

    def _start(self, fn):
        if self._thread and self._thread.is_alive():
            return
        self._stop_event = threading.Event()
        self._set_running(True)
        self.status.config(text="Running...")

        def worker():
            try:
                fn()
            except KeyboardInterrupt:
                self._log("\n--- Stopped by user ---", "warn")
                self._q.put(("status", "Stopped by user"))
            except Exception as e:
                self._log(f"\nERROR: {e}", "error")
                self._q.put(("status", "Error"))
            finally:
                self._q.put(("done",))

        self._thread = threading.Thread(target=worker, daemon=True)
        self._thread.start()

    def _run(self):
        try:
            g = self._gather()
        except ValueError as e:
            messagebox.showerror("Invalid request", str(e))
            return

        for line in self._request_text(g).splitlines():
            self._log("  " + line)
        if len(g["years"]) > 1:
            self._log(f"  → {len(g['years'])} parallel jobs", "ok")
        self._log("-" * 46)

        def job():
            client = self._make_client()

            def cycle(pending, final):
                self._q.put(("status",
                             f"Polling — {len(final)} done, {len(pending)} pending"))

            res = client.run(
                dataset=g["dataset"], years=g["years"], months=g["months"],
                days=g["days"], times=g["times"], bbox=g["bbox"],
                variables=g["variables"], pressure_levels=g["pressure"],
                target_template=g["target"], download_dir=g["download_dir"],
                on_cycle=cycle,
                init_day=g.get("init_day"), forecast_days=g.get("forecast"))
            self._log("-" * 46)
            self._log(f" SUMMARY — submitted {res['submitted']}  "
                      f"downloaded {res['downloaded']}  failed {res['failed']}",
                      "ok" if not res["failed"] else "warn")
            self._q.put(("status", "Done" if not res["failed"]
                         else "Finished with errors"))

        self._start(job)

    def _run_existing(self):
        # Phase 1 — fetch the completed-job list off the UI thread.  The picker
        # opens from _drain when the list arrives, so the user can take all of
        # them or any subset before a single byte is downloaded.
        def fetch():
            client = self._make_client()
            self._q.put(("existing", client.fetch_completed_jobs()))

        self._start(fetch)

    def _open_pending_existing(self):
        jobs = self._pending_existing
        self._pending_existing = None
        if jobs is not None:
            # Deferring one event-loop pass guarantees the fetch thread is gone.
            self.after(0, lambda: self._choose_existing(jobs))

    def _choose_existing(self, jobs):
        if not jobs:
            messagebox.showinfo("Download existing",
                                "No completed jobs found on the portal.")
            self.status.config(text="No completed jobs")
            return

        ids = [str(j.get("id")) for j in jobs]
        labels = {str(j.get("id")): job_display(j) for j in jobs}
        picked = SelectAllDialog.ask(
            self, "Download existing — choose jobs", ids,
            selected=list(ids), columns=1, labels=labels)
        if picked is None:                       # Cancel pressed
            self.status.config(text="Cancelled")
            return
        chosen = [j for j in jobs if str(j.get("id")) in set(picked)]
        if not chosen:
            self.status.config(text="No jobs selected")
            self._log("No jobs selected — nothing to download.", "warn")
            return

        out = (self.existing_var.get().strip()
               or str(self._default_dl_dir() / "existing"))
        self._log(f"Downloading {len(chosen)} of {len(jobs)} completed job(s):")
        for j in chosen:
            self._log("  " + job_display(j))

        def job():
            client = self._make_client()
            res = client.download_existing(out, jobs=chosen)
            self._log("-" * 46)
            self._log(f" SUMMARY — found {res['submitted']}  "
                      f"downloaded {res['downloaded']}  failed {res['failed']}",
                      "ok" if not res["failed"] else "warn")
            self._q.put(("status", "Done" if not res["failed"]
                         else "Finished with errors"))

        self._start(job)

    def _stop(self):
        if self._thread and self._thread.is_alive():
            self._stop_event.set()
            self.status.config(text="Stopping...")
            self._log("\nStop requested — finishing current step...", "warn")

    def _refresh_paths(self):
        rows = self._job_log.rows()[-5:][::-1]
        if not rows:
            self.path_lbl.config(text="No jobs logged yet.")
            return
        txt = "\n".join(f"  {r['year']:<10} {r['status']:<17} {r['target']}"
                        for r in rows)
        self.path_lbl.config(text=f"Recent jobs:\n{txt}")

    def destroy(self):
        # Cancel the pending _drain reschedule first: if it fires after the
        # widget tree is gone, Tk prints 'invalid command name "..._drain"' to
        # stderr on every quit.
        job = getattr(self, "_drain_job", None)
        if job is not None:
            try:
                self.after_cancel(job)
            except Exception:
                pass
            self._drain_job = None
        super().destroy()

    def _on_close(self):
        if self._thread and self._thread.is_alive():
            if not messagebox.askyesno("Quit",
                                       "A job is still running.\nStop it and quit?"):
                return
            self._stop_event.set()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()